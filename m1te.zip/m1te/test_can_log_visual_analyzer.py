"""Targeted regression coverage for the offline ARIA/CAN visual analyzer."""

from __future__ import annotations

import json
import textwrap
from pathlib import Path

import pytest

from tools.can_log_visual_analyzer.analysis import analyze, calculate_timing, decode_frame
from tools.can_log_visual_analyzer.configuration_audit import (
    audit_configuration,
    import_canc_case_configuration,
    import_canc_configuration,
    import_edr_configuration,
)
from tools.can_log_visual_analyzer.copilot_bridge import build_sanitized_prompt
from tools.can_log_visual_analyzer.dbc import DbcDatabase, attribute_frame, import_dbc_json
from tools.can_log_visual_analyzer.faults import FAULT_OPTIONS, recorded_dtc_status
from tools.can_log_visual_analyzer.guidance import build_message_guidance
from tools.can_log_visual_analyzer.models import (
    AnalysisSettings,
    Attribution,
    CanFrame,
    CaptureDirection,
    DbcMessage,
    IdentifierType,
    ParseResult,
)
from tools.can_log_visual_analyzer.parser import parse_aria_text
from tools.can_log_visual_analyzer.onfail_policy import import_onfail_policy
from tools.can_log_visual_analyzer.server import ImportJob, Workspace


def write_text(tmp_path: Path, name: str, body: str) -> Path:
    path = tmp_path / name
    path.write_text(textwrap.dedent(body).strip() + "\n", encoding="utf-8")
    return path


def write_dbc(tmp_path: Path, messages: list[dict]) -> Path:
    path = tmp_path / "network.json"
    path.write_text(json.dumps({"messages": messages}), encoding="utf-8")
    return path


def frame(
    timestamp: float,
    payload: tuple[int, ...] = (0,),
    *,
    channel: str = "2",
    direction: CaptureDirection = CaptureDirection.RX,
    can_id: int = 0x2C0,
) -> CanFrame:
    return CanFrame(
        source_name="capture.log",
        source_line=int(timestamp * 1_000) + 1,
        source_order=int(timestamp * 1_000) + 1,
        raw_line="recorded source",
        timestamp=timestamp,
        bus="Can",
        channel=channel,
        capture_direction=direction,
        can_id=can_id,
        can_id_hex=f"0x{can_id:03X}",
        identifier_type=IdentifierType.UNKNOWN,
        declared_length=len(payload),
        payload=payload,
    )


def periodic_message(**overrides: object) -> dict:
    return {
        "name": "SRS_Status",
        "frame_id": "0x2C0",
        "is_extended_frame": False,
        "length": 2,
        "senders": ["SRS"],
        "receivers": ["BCM"],
        "cycle_time": 10,
        "signals": [],
        **overrides,
    }


def test_parser_accepts_aria_whitespace_hex_and_fd_payloads(tmp_path: Path) -> None:
    payload = " ".join(f"{number:02x}" for number in range(64))
    parsed = parse_aria_text(
        write_text(
            tmp_path,
            "capture.log",
            f"""
            45.649387   Can  2  tX  l=8, id=000002CC, 00 00 00 00 00 00 00 00
            45.662322 Can 2 RX l = 0, id = 0x000002c0,
            45.700000 CAN 10 rx l=64, id=01abcdef, {payload}
            """,
        )
    )

    assert [record.can_id for record in parsed.frames] == [0x2CC, 0x2C0, 0x1ABCDEF]
    assert parsed.frames[0].can_id_hex == "0x2CC"
    assert parsed.frames[1].payload == ()
    assert len(parsed.frames[2].payload) == 64
    assert parsed.frames[2].identifier_type is IdentifierType.EXTENDED


def test_parser_retains_malformed_lines_length_mismatches_and_timestamp_evidence(tmp_path: Path) -> None:
    parsed = parse_aria_text(
        write_text(
            tmp_path,
            "bad.log",
            """
            1.000 Can 2 RX l=2, id=0x2C0, 00 ZZ
            0.900 Can 2 NORTH l=1, id=2c0, 01 trailing
            bad-time Can 2 RX l=1, id=2c0, 01
            2.000 Can 2 RX l=1, id=not-an-id, 01
            """,
        )
    )

    warning_codes = {warning.code for warning in parsed.warnings}
    assert len(parsed.frames) == 2
    assert len(parsed.rejected_lines) == 2
    assert {"invalid-payload-byte", "declared-length-mismatch", "non-monotonic-timestamp", "malformed-direction"} <= warning_codes
    assert parsed.rejected_lines[0].reason.startswith("Malformed timestamp")
    assert parsed.rejected_lines[1].reason.startswith("Malformed CAN identifier")


def test_parser_accepts_utf8_bom_exports(tmp_path: Path) -> None:
    path = tmp_path / "bom-capture.log"
    path.write_bytes(b"\xef\xbb\xbf1.000 Can 2 RX l=1, id=2c0, 01\n")

    parsed = parse_aria_text(path)

    assert len(parsed.frames) == 1


def test_dbc_matching_attribution_unknown_and_standard_extended_ambiguity(tmp_path: Path) -> None:
    definitions = [
        periodic_message(),
        periodic_message(name="Body_Status", senders=["BCM"], receivers=["SRS"], frame_id="0x2C1"),
        periodic_message(name="Extended_2C0", is_extended_frame=True, frame_id="0x2C0"),
    ]
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, definitions))])

    assert attribute_frame(frame(0, can_id=0x2C1), database, "SRS").classification is Attribution.ECU_RX_CANDIDATE
    assert attribute_frame(frame(0, can_id=0x777), database, "SRS").classification is Attribution.UNKNOWN_ID
    ambiguous = attribute_frame(frame(0, can_id=0x2C0), database, "SRS")
    assert ambiguous.classification is Attribution.AMBIGUOUS_DBC
    assert "standard and extended" in ambiguous.rationale
    assert attribute_frame(frame(0, can_id=0x2C0), database, "SRS", IdentifierType.STANDARD).classification is Attribution.ECU_TX_CANDIDATE
    assert attribute_frame(frame(0, can_id=0x2C0), database, "SRS", IdentifierType.EXTENDED).classification is Attribution.ECU_TX_CANDIDATE


def test_dbc_non_association_and_validation_collisions_are_visible(tmp_path: Path) -> None:
    definitions = [
        periodic_message(name="Not_SRS", senders=["BCM"], receivers=["IPC"]),
        periodic_message(name="Duplicate", signals=[
            {"name": "Same", "start_bit": 0, "length": 8, "byte_order": "intel"},
            {"name": "Same", "start_bit": 24, "length": 8, "byte_order": "invalid"},
        ]),
    ]
    imported = import_dbc_json(write_dbc(tmp_path, definitions))
    database = DbcDatabase([imported])

    result = attribute_frame(frame(0), database, "SRS")
    assert result.classification is Attribution.AMBIGUOUS_DBC
    assert database.collisions
    assert any("Duplicate signal name" in warning for warning in imported.warnings)
    assert any("extends beyond" in warning or "Unsupported byte order" in warning for warning in imported.warnings)
    non_associated = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [definitions[0]]))])
    assert attribute_frame(frame(0), non_associated, "SRS").classification is Attribution.DBC_KNOWN_NON_ASSOCIATED


def test_dbc_import_accepts_utf8_bom_from_windows_exports(tmp_path: Path) -> None:
    path = tmp_path / "bom-network.json"
    path.write_bytes(b"\xef\xbb\xbf" + json.dumps({"messages": [periodic_message()]}).encode("utf-8"))

    imported = import_dbc_json(path)

    assert imported.messages[0].name == "SRS_Status"


def test_timing_is_separate_per_channel_direction_and_detects_gap_burst_and_repeat(tmp_path: Path) -> None:
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [periodic_message()]))])
    frames = [
        frame(0.000, (1, 0)),
        frame(0.010, (1, 0)),
        frame(0.024, (2, 0)),
        frame(0.064, (2, 0)),
        frame(0.067, (2, 0)),
        frame(0.000, channel="3"),
        frame(0.010, channel="3"),
        frame(0.000, direction=CaptureDirection.TX),
        frame(0.010, direction=CaptureDirection.TX),
    ]
    result = analyze(frames, database, "SRS")
    categories = {finding.category for finding in result.findings}

    assert len(result.streams) == 3
    assert {
        "Potential stopped or missing periodic message",
        "Timing deviation / late frame",
        "Burst / early frame",
        "Repeated frame burst",
    } <= categories
    primary = next(stream for stream in result.streams if stream.frames[0].channel == "2" and stream.frames[0].capture_direction is CaptureDirection.RX)
    assert primary.metrics.long_gap_count == 1
    assert primary.metrics.estimated_missed_cycles == 3


def test_stable_periodic_traffic_has_zero_jitter_and_full_tolerance() -> None:
    metrics = calculate_timing(
        "stream",
        [frame(0), frame(0.01), frame(0.02)],
        10,
        AnalysisSettings(),
    )

    assert metrics.mean_interval_ms == pytest.approx(10)
    assert metrics.jitter_ms == pytest.approx(0)
    assert metrics.within_tolerance_percent == 100


def test_event_driven_message_without_cycle_is_not_marked_stopped(tmp_path: Path) -> None:
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [periodic_message(cycle_time=None)]))])
    result = analyze([frame(0), frame(5)], database, "SRS")

    assert result.streams[0].metrics.expected_cycle_ms is None
    assert not any(finding.category == "Potential stopped or missing periodic message" for finding in result.findings)


def test_intel_motorola_signed_scaled_enumerated_and_multiplexed_decoding(tmp_path: Path) -> None:
    definition = periodic_message(
        length=2,
        signals=[
            {"name": "SignedIntel", "start_bit": 0, "length": 8, "byte_order": "intel", "is_signed": True, "factor": 0.5, "offset": -1, "unit": "V"},
            {"name": "Motorola", "start_bit": 15, "length": 8, "byte_order": "motorola", "is_signed": False, "factor": 1, "offset": 0, "unit": ""},
            {"name": "Mode", "start_bit": 0, "length": 4, "byte_order": "intel", "is_multiplexer": True},
            {"name": "ValueForModeOne", "start_bit": 8, "length": 8, "byte_order": "intel", "multiplexer_signal": "Mode", "multiplexer_ids": [1]},
            {"name": "Enum", "start_bit": 4, "length": 4, "byte_order": "intel", "value_descriptions": {"1": "On"}},
        ],
    )
    message = import_dbc_json(write_dbc(tmp_path, [definition])).messages[0]
    decoded = {signal.name: signal for signal in decode_frame(frame(0, (0xFE, 0x12)), message)}

    assert decoded["SignedIntel"].raw_value == -2
    assert decoded["SignedIntel"].physical_value == -2
    assert decoded["Motorola"].raw_value == 0x12
    assert decoded["ValueForModeOne"].status == "Unavailable"
    assert decoded["Enum"].status == "Unmapped enumeration value"
    mux_decoded = {signal.name: signal for signal in decode_frame(frame(0, (0x01, 0x2A)), message)}
    assert mux_decoded["ValueForModeOne"].raw_value == 0x2A


def test_multiplexing_range_and_insufficient_payload_findings(tmp_path: Path) -> None:
    definition = periodic_message(
        signals=[
            {"name": "Mode", "start_bit": 0, "length": 4, "byte_order": "intel", "is_multiplexer": True},
            {"name": "Active", "start_bit": 8, "length": 8, "byte_order": "intel", "multiplexer_signal": "Mode", "multiplexer_ids": [1], "min": 0, "max": 20},
        ],
    )
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [definition]))])
    decoded = {signal.name: signal for signal in decode_frame(frame(0, (1, 25)), database.messages[0])}
    findings = analyze([frame(0, (1,)), frame(0.01, (1, 25))], database, "SRS").findings

    assert decoded["Active"].status == "Potential DBC-range deviation"
    assert {"Potential DBC-range deviation", "DLC or payload-length discrepancy"} <= {finding.category for finding in findings}


def test_workspace_exposes_exact_timeline_and_stream_detail(tmp_path: Path) -> None:
    log = write_text(
        tmp_path,
        "recording.log",
        """
        1.000 Can 2 RX l=2, id=2C0, 01 10
        1.010 Can 2 RX l=2, id=2C0, 01 12
        """,
    )
    dbc = write_dbc(tmp_path, [periodic_message()])
    workspace = Workspace(tmp_path / "runtime")
    workspace.runtime_directory.mkdir()
    try:
        workspace.parse_results.append(parse_aria_text(log))
        workspace.dbc_imports.append(import_dbc_json(dbc))
        workspace.target_ecu = "SRS"
        workspace.revision += 1
        workspace.reanalyse()
        assert workspace.result is not None
        stream = workspace.result.streams[0]
        timeline = workspace.timeline({})
        detail = workspace.stream_detail(stream.stream_id)

        assert timeline["mode"] == "exact"
        assert timeline["lanes"][0]["frames"][0]["payload_hex"] == "01 10"
        assert detail is not None
        assert detail["decoded_samples"][0]["signals"] == []
    finally:
        workspace.close()


def test_workspace_uses_density_bins_without_discarding_frames(tmp_path: Path) -> None:
    workspace = Workspace(tmp_path / "runtime")
    workspace.runtime_directory.mkdir()
    try:
        workspace.parse_results.append(
            ParseResult(
                "large.log",
                [frame(index * 0.01, (index % 256,)) for index in range(10_001)],
            )
        )
        workspace.revision += 1
        workspace.reanalyse()

        timeline = workspace.timeline({})

        assert timeline["mode"] == "binned"
        assert sum(timeline["lanes"][0]["bins"]) == 10_001
        assert "every source frame" in timeline["notice"]
    finally:
        workspace.close()


def test_timeout_qualification_and_recovery_times_use_configured_monitor_model(tmp_path: Path) -> None:
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [periodic_message()]))])
    result = analyze(
        [frame(0, (1, 0)), frame(0.01, (1, 0)), frame(0.04, (1, 0)), frame(0.05, (1, 0))],
        database,
        "SRS",
        AnalysisSettings(timeout_qualification_ms=25, timeout_recovery_ms=10),
    )

    event = next(event for event in result.fault_events if event.monitor_scope == "message")
    assert event.qualification_timestamp == pytest.approx(0.035)
    assert event.recovery_observed_timestamp == pytest.approx(0.04)
    assert event.dequalification_timestamp == pytest.approx(0.05)
    assert any(finding.category == "Potential message-timeout qualification" for finding in result.findings)


def test_node_absence_requires_overlapping_timeout_windows_on_multiple_sender_streams(tmp_path: Path) -> None:
    database = DbcDatabase(
        [
            import_dbc_json(
                write_dbc(
                    tmp_path,
                    [
                        periodic_message(name="EMS_A", frame_id="0x2C0", senders=["EMS"]),
                        periodic_message(name="EMS_B", frame_id="0x2C1", senders=["EMS"]),
                    ],
                )
            )
        ]
    )
    result = analyze(
        [
            frame(0, can_id=0x2C0), frame(0.01, can_id=0x2C0), frame(0.06, can_id=0x2C0),
            frame(0, can_id=0x2C1), frame(0.01, can_id=0x2C1), frame(0.07, can_id=0x2C1),
        ],
        database,
        "SRS",
    )

    event = next(event for event in result.fault_events if event.monitor_scope == "sender-node")
    assert event.sender_node == "EMS"
    assert event.qualification_timestamp == pytest.approx(0.04)
    assert event.recovery_observed_timestamp == pytest.approx(0.06)
    assert "does not identify a configured node key message" in event.rule


def test_recorded_uds_dtc_status_requires_isotp_and_decodes_standard_status_bits() -> None:
    single = frame(1, (0x07, 0x59, 0x02, 0xFF, 0x12, 0x34, 0x56, 0x0B))
    first = frame(2, (0x10, 0x0B, 0x59, 0x02, 0xFF, 0x12, 0x34, 0x56), can_id=0x700)
    consecutive = frame(2.001, (0x21, 0x0B, 0xA1, 0xB2, 0xC3, 0x08, 0, 0), can_id=0x700)
    non_isotp = frame(3, (0x59, 0x02, 0xFF, 0x12, 0x34, 0x56, 0x0B))

    records = recorded_dtc_status([single, first, consecutive, non_isotp])

    assert [(record.dtc, record.status_byte) for record in records] == [
        ("123456", 0x0B),
        ("123456", 0x0B),
        ("A1B2C3", 0x08),
    ]
    assert {"testFailed", "testFailedThisOperationCycle", "confirmedDTC"} <= set(records[0].status_flags)
    assert "confirmedDTC" in records[-1].status_flags


def test_policy_context_is_imported_but_not_treated_as_observed_fault(tmp_path: Path) -> None:
    policy_file = tmp_path / "onfail-policy.json"
    policy_file.write_text(
        json.dumps(
            {
                "generic": {"message_timeout": {"reaction": "last_valid"}},
                "records": [{
                    "system": "SRS", "message": "SRS_Status", "signal": "Value",
                    "source_row": 12, "on_fail_applicable": True,
                    "faults": {"message_timeout": {"reaction": "last_valid"}},
                }],
            }
        ),
        encoding="utf-8",
    )
    policy = import_onfail_policy(policy_file)
    database = DbcDatabase([import_dbc_json(write_dbc(tmp_path, [periodic_message()]))])
    result = analyze([frame(0), frame(0.01), frame(0.05)], database, "SRS", onfail_policy=policy)

    event = next(event for event in result.fault_events if event.monitor_scope == "message")
    assert event.policy_context[0]["expected_reaction"] == "last_valid"
    assert result.policy_source == "onfail-policy.json"
    assert any(option.name == "bus_off" and option.capture_support == "not-observable" for option in FAULT_OPTIONS)


def test_static_canc_configuration_audit_checks_dbc_routes_and_fault_eligibility(tmp_path: Path) -> None:
    configuration = write_text(
        tmp_path,
        "canc_config.py",
        """
        DTC = {"NODE": "D1 00 00"}
        CAN_TX_MESSAGE_CONFIG = {
          "Key": {"signals": []},
          "Carrier": {"signals": ["Value", "CRC"]},
          "Other": {"signals": []},
        }
        KEY_TX_FRAMES = {"Key": True, "Carrier": False, "Other": False}
        CAN_VALUE = {
          "frame": "Carrier", "signal": "Value", "Factor": 0.5, "Offset": 1,
          "TestCase_Values": [10, 20],
          "TestCase_Invalid_Values": [255],
          "TestCase_OutofRange_Values": [220],
          "fault_logic": {
            "key_message": "Key", "non_key_timeout_frame": "Other",
            "node_absent_dtc": DTC.get("NODE"), "message_timeout_dtc": DTC.get("NODE"),
            "signal_content_failure_dtc": DTC.get("NODE"),
            "message_content_failure_dtcs": {"CRC": DTC.get("NODE")},
          },
        }
        raise RuntimeError("This must never execute.")
        """,
    )
    definitions = [
        {"name": "Key", "frame_id": "0x100", "length": 1, "senders": ["NODE"], "signals": []},
        {
            "name": "Carrier", "frame_id": "0x101", "length": 1, "senders": ["NODE"],
            "signals": [
                {"name": "Value", "start_bit": 0, "length": 8, "byte_order": "intel", "factor": 0.5, "offset": 1, "min": 0, "max": 100, "value_descriptions": {"255": "Invalid"}},
                {"name": "CRC", "start_bit": 0, "length": 8, "byte_order": "intel"},
            ],
        },
        {"name": "Other", "frame_id": "0x102", "length": 1, "senders": ["NODE"], "signals": []},
    ]
    canc = import_canc_configuration(configuration)
    audit = audit_configuration(canc, None, DbcDatabase([import_dbc_json(write_dbc(tmp_path, definitions))]))
    summaries = [check.summary for check in audit.checks]

    assert canc.messages["Carrier"]["signals"] == ["Value", "CRC"]
    assert any("normal-simulation raw value" in summary for summary in summaries)
    assert any("differs from signal-carrying frame" in summary for summary in summaries)
    assert any("Configured integrity signal 'CRC' is present" in summary for summary in summaries)
    assert any("EDR configuration source is imported" in summary for summary in summaries)


def test_edr_configuration_audit_distinguishes_snapshot_and_invalid_interval(tmp_path: Path) -> None:
    configuration = write_text(
        tmp_path,
        "edr_config.py",
        """
        EDR_PARAMETERS = [
          {"name": "Odometer", "recording_model": "snapshot", "sample_range": None, "scaling_factor": 1.0, "offset": 0.0},
          {"name": "Broken interval", "recording_model": "interval", "sample_range": None, "scaling_factor": None, "offset": 0.0},
        ]
        """,
    )
    edr = import_edr_configuration(configuration)
    audit = audit_configuration(None, edr, DbcDatabase())
    summaries = [check.summary for check in audit.checks]

    assert len(edr.parameters) == 2
    assert any("snapshot with no recording range" in summary for summary in summaries)
    assert any("declared as interval but has no sample range" in summary for summary in summaries)
    assert any("non-finite or missing scaling/offset" in summary for summary in summaries)


def test_generated_canc_cases_check_scope_conversion_dtc_and_action_order(tmp_path: Path) -> None:
    configuration = write_text(
        tmp_path,
        "canc_c_config.py",
        """
        CANC_C_CASES = [
          {
            "name": "Normal invalid DTC", "fault_mode": None, "timing_scope": "full",
            "frame": "Carrier", "signal": "Value", "factor": 1, "offset": 0,
            "dtc_codes": ["D0 00 00"], "dtc_status": None,
            "points": [{"t_s": 0, "in_hex": "0xFF", "in_phys": 255, "state": "normal"}],
            "steps": [{"action": "Read DTC"}, {"action": "Drive recording interval"}],
          },
          {
            "name": "SNR pre", "fault_mode": "signal_never_received", "timing_scope": "pre",
            "frame": "Carrier", "signal": "Value", "factor": 0.5, "offset": 1,
            "dtc_codes": ["D0 00 00"], "dtc_status": "0B", "points": [],
          },
          {
            "name": "UV wrong status", "fault_mode": "uv_ov", "timing_scope": "full",
            "frame": "Carrier", "signal": "Value", "factor": 0.5, "offset": 1,
            "dtc_codes": ["D0 00 00"], "dtc_status": "0B", "points": [],
          },
          {
            "name": "Healed no ignition evidence", "fault_mode": "message_timeout", "timing_scope": "pre",
            "frame": "Carrier", "signal": "Value", "factor": 0.5, "offset": 1,
            "dtc_codes": ["D0 00 00"], "dtc_status": "08", "points": [],
          },
        ]
        """,
    )
    definitions = [{
        "name": "Carrier", "frame_id": "0x101", "length": 1,
        "signals": [{"name": "Value", "start_bit": 0, "length": 8, "byte_order": "intel", "factor": 0.5, "offset": 1, "min": 0, "max": 100}],
    }]
    case_configuration = import_canc_case_configuration(configuration)
    audit = audit_configuration(None, None, DbcDatabase([import_dbc_json(write_dbc(tmp_path, definitions))]), case_configuration)
    categories = {check.category for check in audit.checks}

    assert len(case_configuration.cases) == 4
    assert {
        "Full-only fault scope",
        "Generated-case DBC conversion",
        "Generated normal/on-fail value comparison",
        "Generated normal simulation",
        "Normal-simulation DTC expectation",
        "UV/OV DTC status",
        "Post-crash-healed DTC status",
        "Read-DTC ordering",
    } <= categories


def test_copilot_prompt_is_aggregate_only_and_excludes_raw_engineering_evidence() -> None:
    prompt = build_sanitized_prompt(
        "Which local evidence should I review?",
        {"total_parsed_frames": 12, "capture_duration_ms": 100},
        [{
            "category": "Timing deviation / late frame",
            "evidence": {
                "payload_hex": "DE AD BE EF",
                "source_name": "sensitive-capture.txt",
                "raw_line": "1.0 Can 2 RX l=4, id=2C0, DE AD BE EF",
            },
        }],
        2,
        0,
        {"check_count": 4, "warning_count": 1, "review_count": 3},
    )

    assert "Which local evidence should I review?" in prompt
    assert "Timing deviation / late frame (1)" in prompt
    assert "DE AD BE EF" not in prompt
    assert "sensitive-capture.txt" not in prompt
    assert "id=2C0" not in prompt


def test_copilot_bridge_requires_confirmation_and_surfaces_only_response(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    workspace = Workspace(tmp_path / "runtime")
    workspace.runtime_directory.mkdir()
    captured: dict[str, str] = {}

    def fake_copilot(prompt: str, runtime_directory: Path) -> str:
        captured["prompt"] = prompt
        assert runtime_directory == workspace.runtime_directory
        return "Review the timing summary in the local workspace."

    monkeypatch.setattr("tools.can_log_visual_analyzer.server.run_copilot_prompt", fake_copilot)
    try:
        with pytest.raises(ValueError, match="Confirm"):
            workspace.queue_copilot_query("Review this.", False)

        job = ImportJob("copilot-job", "copilot-analysis", "Sanitized Copilot analysis")
        workspace._run_copilot_query(job, workspace.copilot_preview("Review this.").get("prompt"))

        assert job.state == "completed"
        assert job.result == {"response": "Review the timing summary in the local workspace."}
        assert "Review this." in captured["prompt"]
    finally:
        workspace.close()


def test_guided_message_content_check_reports_counter_qualification_recovery_and_stop_status(tmp_path: Path) -> None:
    configuration = write_text(
        tmp_path,
        "canc_config.py",
        """
        DTC = {"counter": "0xE4 0x71 0x00"}
        CAN_TX_MESSAGE_CONFIG = {
          "EMS21_10": {"signals": ["EMS21_MSG_CNT", "EMS21_CRC"]}
        }
        KEY_TX_FRAMES = {"EMS3_10": True, "EMS21_10": False}
        CAN_EMS21_MSG_CNT = {
          "frame": "EMS21_10", "signal": "EMS21_MSG_CNT", "periodicity": 10,
          "fault_logic": {
            "key_message": "EMS3_10",
            "non_key_timeout_frame": "EMS21_10",
            "message_content_failure_dtcs": {
              "EMS21_MSG_CNT": DTC.get("counter"),
              "EMS21_CRC": DTC.get("counter")
            }
          }
        }
        U171_CAN_FAULT_QUALI_DEQUALI_CONFIG = {
          "mapping_state": "REVIEW_REQUIRED",
          "timing": {"startup_delay_ms": 2000, "default_counts": {"message_content": (3, 2)}}
        }
        """,
    )
    definitions = [{
        "name": "EMS21_10", "frame_id": "0x127", "length": 2, "cycle_time": 10,
        "signals": [
            {"name": "EMS21_MSG_CNT", "start_bit": 0, "length": 4, "byte_order": "intel"},
            {"name": "EMS21_CRC", "start_bit": 8, "length": 8, "byte_order": "intel"},
        ],
    }]
    frames = [
        frame(0.00, (0, 1), can_id=0x127), frame(0.01, (1, 2), can_id=0x127),
        frame(0.02, (1, 3), can_id=0x127), frame(0.03, (1, 4), can_id=0x127),
        frame(0.04, (1, 5), can_id=0x127), frame(0.05, (2, 6), can_id=0x127),
        frame(0.06, (3, 7), can_id=0x127),
    ]
    guide = build_message_guidance(
        "0x127",
        "message_content",
        "EMS21_MSG_CNT",
        frames,
        DbcDatabase([import_dbc_json(write_dbc(tmp_path, definitions))]),
        import_canc_configuration(configuration),
        None,
        AnalysisSettings(),
    )

    assert guide["focus"]["selected_message"] == "EMS21_10"
    assert guide["qualification"]["derived_qualification_ms"] == 30
    assert guide["qualification"]["derived_recovery_ms"] == 20
    assert guide["frame_stop_check"]["stopped_gap_count"] == 0
    assert guide["alive_counter_check"]["mismatch_count"] == 3
    assert [event["kind"] for event in guide["alive_counter_check"]["configured_events"]] == [
        "configured-qualification candidate",
        "configured-recovery candidate",
    ]
    assert guide["configured_message_content"]["integrity_signals"][0]["dtc"] == "0xE4 0x71 0x00"
