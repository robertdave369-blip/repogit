# Tests Output Policy

New generated executable test files belong directly in this folder and use the
`test_<feature>.py` naming pattern. When a generated test needs multiple
supporting files, keep its folder inside `tests/`, for example
`tests/<feature>/`.

Generated test validation and dependency-lifecycle artifacts belong in
`tests/dependency_management/`. Do not create new top-level output folders for
test-related skill output.

Existing project module scripts and configuration-controlled runtime
`test_results/` and `test_logs/` paths are not relocated by this policy.