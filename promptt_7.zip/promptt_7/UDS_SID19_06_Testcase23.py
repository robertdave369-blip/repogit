# Author: Christy, Krishna
# Test Case : SID19 06_Testcase23
# Folder    : Extended Snapshot Data Record ($19_06)
# Service   : 0x19 ReadDTCInformation
# Intention : 1. Test on Physical Request ID ($730) 2.Check the snapshot record when the DTC is Active and Historic
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 06_Testcase23"
    tc_desc = "1. Test on Physical Request ID ($730) 2.Check the snapshot record when the DTC is Active and Historic"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_06_Testcase23")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: create CAN fault")
        RESULT.LogAction("MANUAL / precondition step", "create CAN fault")

        RESULT.InsertComment("Step 4: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 19 06 D1 11 00 01 '59 06 D1 11 00 8B 01 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

        RESULT.InsertComment("Step 5: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 20 06 D1 11 00 02 '59 06 D1 11 00 8B 02 00")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

        RESULT.InsertComment("Step 6: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 19 06 D1 11 00 FF '59 06 D1 11 00 08 01 01 02 00")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

        RESULT.InsertComment("Step 7: Toggle IGN")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 8: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 19 06 D1 11 00 01 '59 06 D1 11 00 08 01 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 19 06 D1 11 00 02 '59 06 D1 11 00 08 02 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")
        RESULT.InsertComment("Expected: 19 06 D1 11 00 FF '59 06 D1 11 00 08 01 01 02 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) to request information for DTC:D1 11 00")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
