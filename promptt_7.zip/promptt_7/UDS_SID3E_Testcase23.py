# Author: Christy, Krishna
# Test Case : SID3E_Testcase23
# Folder    : Tester Present Service (SID $3E)
# Service   : 0x3E TesterPresent
# Intention : To Verify Vehicle Speed is greater than or equal to 5 doesn't impact tester present ($3E) in Physical mode.
# Verifies  : ISSUE:33629773, ISSUE:33629785, ISSUE:33629886

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_SESSION_DEFAULT,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_SESSION_PROGRAMMING,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_50_01_00_32_13_88,
    UDS_RESP_50_02_00_C8_01_F4,
    UDS_RESP_50_03_00_32_13_88,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID3E_Testcase23"
    tc_desc = "To Verify Vehicle Speed is greater than or equal to 5 doesn't impact tester present ($3E) in Physical mode."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID3E_Testcase23")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x3E TesterPresent")
        RESULT.InsertComment("Requirements verified: ISSUE:33629773, ISSUE:33629785, ISSUE:33629886")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Verify 2C0 message and confirm communication")
        RESULT.InsertComment("Expected: 2C0 msg present")
        RESULT.InsertComment("Bus communication confirmed by read_software_version() above.")

        RESULT.InsertComment("Step 4: Set Vehicle Speed >= 5")
        RESULT.InsertComment("Expected: Vehcile speed set to 6")
        RESULT.LogAction("MANUAL / precondition step", "Set Vehicle Speed >= 5")

        RESULT.InsertComment("Step 5: Send Request for extended Session 730: 02 10 01")
        RESULT.InsertComment("Expected: 738: 06 50 01 00 32 13 88 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_01_00_32_13_88)

        RESULT.InsertComment("Step 6: Send request 730: 02 3E 00")
        RESULT.InsertComment("Expected: 738: 02 7E 00 FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 7: Send Request for extended Session 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 13 88 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 8: Send request 730: 02 3E 00")
        RESULT.InsertComment("Expected: 738: 02 7E 00 FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 9: Unlock Level 3 security, Send Request 730: 02 10 02")
        RESULT.InsertComment("Expected: 738: 06 50 02 00 C8 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_PROGRAMMING)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_02_00_C8_01_F4)

        RESULT.InsertComment("Step 10: Send request 730: 02 3E 00")
        RESULT.InsertComment("Expected: 738: 02 7E 00 FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
