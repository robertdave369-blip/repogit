# Author: Christy, Krishna
# Test Case : SID27_Testcase25
# Folder    : Security Access Service (SID $27)
# Service   : 0x27 SecurityAccess
# Intention : To Verify NRC_ ($36) After 5 consecutive successful trials of Security Access(L3) with time gap of less than 3secs, Seed Request of 6th attempt not getting NRC_36 as response
# Verifies  : ISSUE:33629950

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_05,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_7F_27_36,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID27_Testcase25"
    tc_desc = "To Verify NRC_ ($36) After 5 consecutive successful trials of Security Access(L3) with time gap of less than 3secs, Seed Request of 6th attempt not getting NRC_36 as response"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID27_Testcase25")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x27 SecurityAccess")
        RESULT.InsertComment("Requirements verified: ISSUE:33629950")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send Tester Present Request(SID $3E, SF $00) in periodically")
        RESULT.InsertComment("Expected: 730: 02 3E 00 00 00 00 00 00 738: 02 7E 00 FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Verify no active fault is detected.")
        RESULT.InsertComment("Expected: No Fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify no active fault is detected.")

        RESULT.InsertComment("Step 4: Send Extended Session Request ID 730: 02 10 03 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 10 03 FF FF FF FF FF ID 738: 06 50 03 00 32 01 F4 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 05 FF FF FF FF FF ID 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 6: Send Request for Security Key ID 730: 06 27 06 yy yy yy yy FF FF")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF with in 3 secs from above step")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730:02 27 05 FF FF FF FF FF ID 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 8: Send Request for Security Key ID 730: 06 27 06 yy yy yy yy FF FF")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 9: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF with in 3 secs from above step")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 05 FF FF FF FF FF ID 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 10: Send Request for Security Key ID 730: 06 27 06 yy yy yy yy FF FF")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 11: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF with in 3 secs from above step")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 05 FF FF FF FF FF ID 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 12: Send Request for Security Key ID 730: 06 27 06 yy yy yy yy FF FF")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 13: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF with in 3 secs from above step")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 05 FF FF FF FF FF ID 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 14: Send Request for Security Key ID 730: 06 27 06 yy yy yy yy FF FF")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 15: Send Request for Security Seed. ID 730: 02 27 05 FF FF FF FF FF with in 3 secs from above step")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. ID 730: 02 27 05 FF FF FF FF FF ID 738: 03 7F 27 36 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_27_05)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_36)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
