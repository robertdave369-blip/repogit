# Author: Christy, Krishna
# Test Case : SID85_Testcase27
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : To Verify NRC_7F ($85) in Programming session
# Verifies  : ISSUE:33692241, ISSUE:32591243

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_85_01,
    UDS_REQ_85_02,
    UDS_REQ_85_81,
    UDS_REQ_85_82,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_SESSION_PROGRAMMING,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_7F_85_7F,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_SESSION_PROGRAMMING,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase27"
    tc_desc = "To Verify NRC_7F ($85) in Programming session"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase27")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:33692241, ISSUE:32591243")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send 3E to keep current session.(period:3s)")
        RESULT.InsertComment("Expected: Test on Physical Request ID")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 4: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: %%(color:rgb(65, 65, 65);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Send Request for Security Seed 730: 02 27 05")
        RESULT.InsertComment("Expected: 738: 06 67 05 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 6: Send Request for Security Key 730: 27 06 yy yy yy yy")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Send Programming Request 730: 02 10 02")
        RESULT.InsertComment("Expected: 738: 06 50 02 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_PROGRAMMING)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_PROGRAMMING)

        RESULT.InsertComment("Step 8: Send (SID $85, SF $01).")
        RESULT.InsertComment("Expected: 730: 08 02 85 01 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 9: Send (SID $85, SF $02).")
        RESULT.InsertComment("Expected: 730: 08 02 85 02 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 10: Send (SID $85, SF $01).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 01 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 11: Send (SID $85, SF $02).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 02 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 12: Send (SID $85, SF $81).")
        RESULT.InsertComment("Expected: 730: 08 02 85 81 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_81)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 13: Send (SID $85, SF $82).")
        RESULT.InsertComment("Expected: 730: 08 02 85 82 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_82)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 14: Send (SID $85, SF $81).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 81 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_81)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

        RESULT.InsertComment("Step 15: Send (SID $85, SF $82).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 82 00 00 00 00 00 738: 08 03 7F 85 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_82)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:3]), UDS_RESP_7F_85_7F)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
