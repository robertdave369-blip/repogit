# Author: Christy, Krishna
# Test Case : SID19 04_Testcase10
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : DID Response
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_04_5A,
    UDS_REQ_22_F1_B2,
    UDS_RESP_62_04_5A,
    UDS_RESP_62_F1_B2,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase10"
    tc_desc = "DID Response"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase10")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: 1.Simulate Signal Values for ACC_PED, VEHICLE_SPEED_VCU, VEHICLE_MODE 2. Read DID response of the Signals")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "1.Simulate Signal Values for ACC_PED, VEHICLE_SPEED_VCU, VEHICLE_MODE 2. Read DID response of the Signals")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set VEHICLE_SPEED as VEHICLE_SPEED= 55 kmph Set ACC_PED as ACC_PED= 99 Set VEHICLE_MODE as VEHICLE_MODE= 2")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "Set VEHICLE_SPEED as VEHICLE_SPEED= 55 kmph Set ACC_PED as ACC_PED= 99 Set VEHICLE_MODE as VEHICLE_MODE= 2")

        RESULT.InsertComment("Step 5: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 XX XX 00 00 00 Default Value : XX YY= 01 80")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_B2)

        RESULT.InsertComment("Step 6: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B9)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 XX XX 00 00 00 Default Value : XX YY= 00 02")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_B2)

        RESULT.InsertComment("Step 7: Send ReadDatabyIdentifier request(SID: $22). (DID: 045A)")
        RESULT.InsertComment("Expected: ID 730 :03 22 04 5A 00 00 00 00 00 738:05 62 04 5A XX XX 00 00 00 Default Value : XX YY= 63")
        response = CAN.SendDiagByValues(UDS_REQ_22_04_5A)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_04_5A)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
