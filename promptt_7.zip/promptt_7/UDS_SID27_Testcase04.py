# Author: Christy, Krishna
# Test Case : SID27_Testcase04
# Folder    : Security Access Service (SID $27)
# Service   : 0x27 SecurityAccess
# Intention : To verify Level 1 security on Default session in Physical mode - NRC 7F
# Verifies  : ISSUE:33629946, ISSUE:33630025, ISSUE:33630026, ISSUE:33630033, ISSUE:33630035, ISSUE:33634326, ISSUE:33634327, ISSUE:33634328, ISSUE:33634329

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_01,
    UDS_REQ_SESSION_DEFAULT,
    UDS_RESP_7F_27_7F,
    UDS_RESP_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID27_Testcase04"
    tc_desc = "To verify Level 1 security on Default session in Physical mode - NRC 7F"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID27_Testcase04")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x27 SecurityAccess")
        RESULT.InsertComment("Requirements verified: ISSUE:33629946, ISSUE:33630025, ISSUE:33630026, ISSUE:33630033, ISSUE:33630035, ISSUE:33634326, ISSUE:33634327, ISSUE:33634328, ISSUE:33634329")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send Extended Request 730: 02 10 01")
        RESULT.InsertComment("Expected: 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send Request for Security Seed 730: 02 27 01")
        RESULT.InsertComment("Expected: 738: 03 7F 27 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_27_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_7F)

        RESULT.InsertComment("Step 5: Send Request for Security Key 730: 27 02 yy yy yy yy")
        RESULT.InsertComment("Expected: 738: 03 7F 27 7F AA AA AA AA")
        RESULT.LogAction("MANUAL: request contains run-time value(s)", "27 02 xx xx xx xx")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
