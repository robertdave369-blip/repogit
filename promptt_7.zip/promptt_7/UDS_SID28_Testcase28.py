# Author: Christy, Krishna
# Test Case : SID28_Testcase28
# Folder    : Communication Control(SID $28)
# Service   : 0x28 CommunicationControl
# Intention : To verify $28 with SPR subfunctions and monitor communication control using periodic tester present(3E) in Physical mode.
# Verifies  : ISSUE:33634562, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33666982, ISSUE:32591247

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_28_80_01,
    UDS_REQ_28_81_01,
    UDS_REQ_28_82_01,
    UDS_REQ_28_83_01,
    UDS_REQ_READ_ACTIVE_SESSION,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_62_F1,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID28_Testcase28"
    tc_desc = "To verify $28 with SPR subfunctions and monitor communication control using periodic tester present(3E) in Physical mode."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID28_Testcase28")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x28 CommunicationControl")
        RESULT.InsertComment("Requirements verified: ISSUE:33634562, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33666982, ISSUE:32591247")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send 3E to keep current session.")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Send in extended session.(SID $28, SF $80).")
        RESULT.InsertComment("Expected: 730: 08 03 28 80 01 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_80_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 5: Wait for 5 s with SID$3E and check 2C0 App msg")
        RESULT.InsertComment("Expected: communication will be present")
        Sleep(5)

        RESULT.InsertComment("Step 6: Read DID F186 with SID $22")
        RESULT.InsertComment("Expected: 730: 08 03 22 F1 86 00 00 00 00 738: 08 02 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:2]), UDS_RESP_62_F1)

        RESULT.InsertComment("Step 7: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 8: Send in extended session.(SID $28, SF $81).")
        RESULT.InsertComment("Expected: 730: 08 03 28 81 01 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_81_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 9: Wait for 5 s with SID$3E and check 2C0 App msg")
        RESULT.InsertComment("Expected: communication will be stopped")
        Sleep(5)

        RESULT.InsertComment("Step 10: Read DID F186 with SID $22")
        RESULT.InsertComment("Expected: 730: 08 03 22 F1 86 00 00 00 00 738: 08 02 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:2]), UDS_RESP_62_F1)

        RESULT.InsertComment("Step 11: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 12: Send in extended session.(SID $28, SF $82).")
        RESULT.InsertComment("Expected: 730: 08 03 28 82 01 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_82_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 13: Wait for 5 s with SID$3E and check 2C0 App msg")
        RESULT.InsertComment("Expected: communication will be present")
        Sleep(5)

        RESULT.InsertComment("Step 14: Read DID F186 with SID $22")
        RESULT.InsertComment("Expected: 730: 08 03 22 F1 86 00 00 00 00 738: 08 02 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:2]), UDS_RESP_62_F1)

        RESULT.InsertComment("Step 15: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 16: Send in extended session.(SID $28, SF $83).")
        RESULT.InsertComment("Expected: 730: 08 03 28 83 01 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_83_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 17: Wait for 5 s with SID$3E and check 2C0 App msg")
        RESULT.InsertComment("Expected: communication will be stopped")
        Sleep(5)

        RESULT.InsertComment("Step 18: Read DID F186 with SID $22")
        RESULT.InsertComment("Expected: 730: 08 03 22 F1 86 00 00 00 00 738: 08 02 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:2]), UDS_RESP_62_F1)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
