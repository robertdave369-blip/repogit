# Author: Christy, Krishna
# Test Case : SID19 04_Testcase20
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : UNDER STRIKE EVENT CRASH_DTC Snapshot Record under default conditions and followed by change is parameter values.
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699422, ISSUE:34699424, ISSUE:34699427, ISSUE:34699429, ISSUE:34699430, ISSUE:34699431, ISSUE:34699433, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513, ISSUE:34699436

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase20"
    tc_desc = "UNDER STRIKE EVENT CRASH_DTC Snapshot Record under default conditions and followed by change is parameter values."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase20")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699422, ISSUE:34699424, ISSUE:34699427, ISSUE:34699429, ISSUE:34699430, ISSUE:34699431, ISSUE:34699433, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513, ISSUE:34699436")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Snapshot data for Active state,Historic and healed state in normal conditions values")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set/Update the existing values of the parameters:// // Vehicle Speed = 0x27 kmph// Battery voltage = 13 V & IGN Voltage = 12V// Original odometer Occurrence reading is 0x150// Vehicle State = 3(Chargi")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 5: Read corresponding DIDs to the parameters applicable for freeze frame: Vehicle Speed = (SID: $22). (DID: F1B2) Battery voltage = (SID: $22). (DID: F1B1) Original odometer Occurrence reading = (SID: $2")
        RESULT.InsertComment("Expected: 738:05 62 F1 B2 00 27 00 00 00 738:05 62 F1 B1 88 81 00 00 00 738:06 62 F1 B0 00 01 50 00 00 738:06 62 F1 B9 03 00 00 00 738:07 62 04 44 00 00 03 46 738:10 0B 62 04 48 14 11 11 01 00 00 00 00 738: 04 ")
        RESULT.LogAction("MANUAL / precondition step", "Read corresponding DIDs to the parameters applicable for freeze frame: Vehicle Speed = (SID: $22). (DID: F1B2) Battery voltage = (SID: $22). (DID: F1B1) Original odometer Occurrence reading = (SID: $2")

        RESULT.InsertComment("Step 6: Set Under strike Event Crash fault i.e. by simulating crash(Understrike).")
        RESULT.InsertComment("Expected: Active, DTC_Under strike Event Crash DTC:925200")
        RESULT.LogAction("MANUAL / precondition step", "Set Under strike Event Crash fault i.e. by simulating crash(Understrike).")

        RESULT.InsertComment("Step 7: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 52 00 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 8: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 52 00 8B 01 11 F1 B2 00 27 F1 B1 88 81 F1 B0 00 01 50 F1 B9 03 04 44 00 00 03 46 04 48 14 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A 3F F1 B6 00 00 00 1B 00 FF 00 FF 07 EB 01 01 01 01 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 52 00 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 10: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 19 04 92 52 00 02 11 F1 B2 00 27 F1 B1 88 81 F1 B0 00 01 50 F1 B9 03 04 44 00 00 03 46 04 48 14 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A 3F F1 B6 00 00 00 1B 00 FF 00 FF 07 EB 01 01 01 01 F1 B5 01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 11: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 52 00 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 12: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 52 00 8B 01 11 F1 B2 00 27 F1 B1 88 81 F1 B0 00 01 50 F1 B9 03 04 44 00 00 03 46 04 48 14 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A 3F F1 B6 00 00 00 1B 00 FF 00 FF 07 EB 01 01 01 01 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
