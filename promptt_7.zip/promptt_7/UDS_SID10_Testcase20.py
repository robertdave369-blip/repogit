# Author: Christy, Krishna
# Test Case : SID10_Testcase20
# Folder    : Diagnostics Session Control service (SID $10)
# Service   : 0x10 DiagnosticSessionControl
# Intention : To Verify NRC_($12) Sub-function not supported.
# Verifies  : ISSUE:33623698

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID10_Testcase20"
    tc_desc = "To Verify NRC_($12) Sub-function not supported."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID10_Testcase20")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x10 DiagnosticSessionControl")
        RESULT.InsertComment("Requirements verified: ISSUE:33623698")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send Request 730: 02 10 XX (XX can be 00 to FF except 01,02,03,83)")
        RESULT.InsertComment("Expected: NRC12")
        RESULT.LogAction("MANUAL: request contains run-time value(s)", "10 xx")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
