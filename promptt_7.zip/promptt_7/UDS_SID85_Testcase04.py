# Author: Christy, Krishna
# Test Case : SID85_Testcase04
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : Send Incorrect DL in drive to confirm NRC13 is observed in extended session using Functional request
# Verifies  : ISSUE:33623645, ISSUE:33692241

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_85_01,
    UDS_REQ_85_81,
    UDS_REQ_85_82,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase04"
    tc_desc = "Send Incorrect DL in drive to confirm NRC13 is observed in extended session using Functional request"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase04")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:33623645, ISSUE:33692241")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send 3E to keep current session.(period:3s)")
        RESULT.InsertComment("Expected: Test on Functional Request ID")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Send ControlDTCSetting command ($85) to request DTC control ON with incorrect length")
        RESULT.InsertComment("Expected: 7DF: xx 85 01 (xx can be except 02).")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 5: Verify ACU sends out negative response")
        RESULT.InsertComment("Expected: ID 738: 08 03 7F 85 13 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out negative response")

        RESULT.InsertComment("Step 6: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 7: Send ControlDTCSetting command ($85) to request DTC control ON with incorrect length")
        RESULT.InsertComment("Expected: 7DF: xx 85 01 (xx can be except 02).")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 8: Verify ACU sends out negative response")
        RESULT.InsertComment("Expected: ID 738: 08 03 7F 85 13 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out negative response")

        RESULT.InsertComment("Step 9: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 10: Send ControlDTCSetting command ($85) to request DTC control ON with incorrect length")
        RESULT.InsertComment("Expected: 7DF: xx 85 81 (xx can be except 02).")
        response = CAN.SendDiagByValues(UDS_REQ_85_81)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 11: Verify ACU sends out negative response")
        RESULT.InsertComment("Expected: ID 738: 08 03 7F 85 13 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out negative response")

        RESULT.InsertComment("Step 12: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 13: Send ControlDTCSetting command ($85) to request DTC control ON with incorrect length")
        RESULT.InsertComment("Expected: 7DF: xx 85 82 (xx can be except 02).")
        response = CAN.SendDiagByValues(UDS_REQ_85_82)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 14: Verify ACU sends out negative response")
        RESULT.InsertComment("Expected: ID 738: 08 03 7F 85 13 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out negative response")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
