# Author: Christy, Krishna
# Test Case : SID19 04_Testcase11
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : To verify First 15DTCs are Clearing with 40 IGN cycle & Checking 16 DTC Freeze frame data
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_04_92_0A_13_FF,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase11"
    tc_desc = "To verify First 15DTCs are Clearing with 40 IGN cycle & Checking 16 DTC Freeze frame data"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase11")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: 16th DTC Freeze frame data")
        RESULT.LogAction("MANUAL / precondition step", "16th DTC Freeze frame data")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Stop Valid CAN WAKE UP frames")
        RESULT.LogAction("MANUAL / precondition step", "Stop Valid CAN WAKE UP frames")

        RESULT.InsertComment("Step 4: Read DTC")
        RESULT.InsertComment("Expected: first 15 DTCs are historic/healed state & 3 DTC are active")
        RESULT.LogAction("MANUAL / precondition step", "Read DTC")

        RESULT.InsertComment("Step 5: Verify ageing of first 15 DTCs")
        RESULT.InsertComment("Expected: Perform 40 IGN cycles with time gap for 7seconds")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 6: Read DTC")
        RESULT.InsertComment("Expected: First 15 DTC are cleared & 3 DTC are active in system")
        RESULT.LogAction("MANUAL / precondition step", "Read DTC")

        RESULT.InsertComment("Step 7: Read Freeze frame data for 16Th DTC 19 04 92 0A 13")
        RESULT.InsertComment("Expected: 730: 19 04 92 0A 13 FF")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_0A_13_FF)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 8: Verify Freeze frame data with 2 records")
        RESULT.InsertComment("Expected: 59 04 92 0A 13 8B 01 0C F1 B2 00 00 F1 B1 79 72 F1 B0 00 00 00 F1 B9 00 04 44 0000 4C E5 04 48 11 00 04 4B 01 04 59 00 04 5A 00 F1 B6 00 00 00 8C F1 B5 00 00 04 9D 00 00 00 8C 02 0C F1 B2 00 00 F1 B1 ")
        RESULT.LogAction("MANUAL / precondition step", "Verify Freeze frame data with 2 records")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
