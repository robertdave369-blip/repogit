# Author: Christy, Krishna
# Test Case : SID19_Testcase08
# Folder    : Read DTC Information Service (SID $19)
# Service   : 0x19 ReadDTCInformation
# Intention : To verify NRC13 test on Physical Request ID ($730) for length of the message is wrong.
# Verifies  : ISSUE:33697817

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19,
    UDS_REQ_19_01_FF_FF_FF,
    UDS_REQ_19_02_FF,
    UDS_REQ_READ_ACTIVE_SESSION,
    UDS_RESP_7F_19_13,
    UDS_RESP_ACTIVE_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19_Testcase08"
    tc_desc = "To verify NRC13 test on Physical Request ID ($730) for length of the message is wrong."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_Testcase08")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697817")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send Read Active Diagnostic Session command(SID $22,DID $F186).")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 86 FF FF FF FF ID 738: 04 62 F1 86 01 FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send Diagnostic Session Control service(SID: $19) with incorrect length.")
        RESULT.InsertComment("Expected: ID 730: 03 19 02 FF FF FF FF FF ID 738: 03 7F 19 13 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_19_02_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_19_13)

        RESULT.InsertComment("Step 5: Send Read Active Diagnostic Session command(SID $22,DID $F186).")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 86 FF FF FF FF ID 738: 04 62 F1 86 01 FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

        RESULT.InsertComment("Step 6: Send Diagnostic Session Control service(SID: $19) with incorrect length.")
        RESULT.InsertComment("Expected: ID 730: 01 19 01 FF FF FF FF FF ID 738: 03 7F 19 13 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_19)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_19_13)

        RESULT.InsertComment("Step 7: Send Read Active Diagnostic Session command(SID $22,DID $F186).")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 86 FF FF FF FF ID 738: 04 62 F1 86 01 FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

        RESULT.InsertComment("Step 8: Send Diagnostic Session Control service(SID: $19) with incorrect length.")
        RESULT.InsertComment("Expected: ID 730: 05 19 01 FF FF FF FF FF ID 738: 03 7F 19 13 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_19_01_FF_FF_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_19_13)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
