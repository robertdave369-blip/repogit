# Author: Christy, Krishna
# Test Case : SID19 04_Testcase13
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : DID Snapshot Record Number(FF) RSU faults in CAN wakeup
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_F1_B2,
    UDS_REQ_22_F1_B6,
    UDS_RESP_62_F1_B2,
    UDS_RESP_62_F1_B6_00,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase13"
    tc_desc = "DID Snapshot Record Number(FF) RSU faults in CAN wakeup"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase13")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Snapshot data record(FF) with RSU fault for Active state and historic state condition")
        RESULT.LogAction("MANUAL / precondition step", "Snapshot data record(FF) with RSU fault for Active state and historic state condition")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set vehicle Speed as VEHICLE_SPEED_= 150 kmph Set Battery voltage as Battery_voltage= 12 V Set Original odometer Occurance reading to 0x999999(ID0x318_ODOMTR_READING=999999) (F423F) set Most Recent Li")
        RESULT.InsertComment("DBC names referenced: BRAKE_PEDAL_VALUE, INDC_SRS, ODOMTR_READING, RAW_ACC_PEDAL_VALUE, VEHICLE_SPEED")
        Sleep(10)
        RESULT.LogAction("MANUAL / precondition step", "Set vehicle Speed as VEHICLE_SPEED_= 150 kmph Set Battery voltage as Battery_voltage= 12 V Set Original odometer Occurance reading to 0x999999(ID0x318_ODOMTR_READING=999999) (F423F) set Most Recent Li")

        RESULT.InsertComment("Step 5: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 XX YY 00 00 00 Default Value : 25 80")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_B2)

        RESULT.InsertComment("Step 6: Read DID $F1B6 (IGN counter)")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 B6 00 00 00 00 00 ID 738: 04 62 F1 B6 00 00 02 47 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B6)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_62_F1_B6_00)

        RESULT.InsertComment("Step 7: Set Right FRSU OPEN fault")
        RESULT.InsertComment("Expected: Active, DTC_RIGHT_FRSU_OPEN DTC:809513")
        RESULT.LogAction("MANUAL / precondition step", "Set Right FRSU OPEN fault")

        RESULT.InsertComment("Step 8: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 95 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 9: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 95 13 8B 01 0C F1 B2 25 80 F1 B1 7A 74 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 07 C4 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 46 F1 B5 00 02 04 9D 00 00 00 0A")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 95 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 11: Verify ACU sends out the positive response.(record data 02 is same asrecord data 01 in step 18)")
        RESULT.InsertComment("Expected: 59 04 80 95 13 8B 02 0C F1 B2 25 80 F1 B1 7A 72 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 08 15 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 47 F1 B5 00 02 04 9D 00 00 00 0B")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.(record data 02 is same asrecord data 01 in step 18)")

        RESULT.InsertComment("Step 12: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 95 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 13: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 95 13 8B 01 0C F1 B2 25 80 F1 B1 7A 74 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 07 C4 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 46 F1 B5 00 02 04 9D 00 00 00 0A 02 0C F1 B2 25 80 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 14: Make to Normal position Right FRSU & Perform Ign OFF/ON && Read Ign DID")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 15: Set Right FRSU for Historic condition")
        RESULT.InsertComment("Expected: Historic state, DTC_Right_FRSU_OPEN DTC:809513")
        RESULT.LogAction("MANUAL / precondition step", "Set Right FRSU for Historic condition")

        RESULT.InsertComment("Step 16: Send ReadDTCInformation command($19, SF $04) to request information for DTC: for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 95 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC: for healed condition")

        RESULT.InsertComment("Step 17: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 95 13 08 01 0C F1 B2 25 80 F1 B1 7A 74 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 07 C4 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 46 F1 B5 00 02 04 9D 00 00 00 0A")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 18: Send ReadDTCInformation command($19, SF $04) to request information for DTC for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 95 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC for healed condition")

        RESULT.InsertComment("Step 19: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 95 13 08 02 0C F1 B2 25 80 F1 B1 7A 72 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 08 15 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 47 F1 B5 00 02 04 9D 00 00 00 0B")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 20: Send ReadDTCInformation command($19, SF $04) to request information for DTC for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 95 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC for healed condition")

        RESULT.InsertComment("Step 21: Verify ACU sends out the positive response.(record data 01 & record data 02 same as in step 23)")
        RESULT.InsertComment("Expected: 59 04 80 95 13 08 01 0C F1 B2 25 80 F1 B1 7A 74 F1 B0 0F 42 3F F1 B9 01 04 44 00 00 07 C4 04 48 11 00 04 4B 01 04 59 02 04 5A 32 F1 B6 00 00 02 46 F1 B5 00 02 04 9D 00 00 00 0A 02 0C F1 B2 25 80 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.(record data 01 & record data 02 same as in step 23)")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
