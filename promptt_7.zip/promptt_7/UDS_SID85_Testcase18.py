# Author: Christy, Krishna
# Test Case : SID85_Testcase18
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : To Verify NRC88 for Boundary Values for Functional Id
# Verifies  : ISSUE:33692241, ISSUE:33696905

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_85_01,
    UDS_REQ_85_02,
    UDS_REQ_85_81,
    UDS_REQ_85_82,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03_00_32_13_88,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase18"
    tc_desc = "To Verify NRC88 for Boundary Values for Functional Id"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase18")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:33692241, ISSUE:33696905")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")
        RESULT.LogAction("MANUAL / precondition step", "To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify No faults")
        RESULT.InsertComment("Expected: No faults")
        RESULT.LogAction("MANUAL / precondition step", "Verify No faults")

        RESULT.InsertComment("Step 4: Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")
        RESULT.InsertComment("Expected: ID 730: 08 02 10 03 FF FF FF FF FF ID 738: 08 06 50 03 00 32 13 88 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 5: Set Vehicle speed > Threshold DID value i.e. greater than 5")
        RESULT.LogAction("MANUAL / precondition step", "Set Vehicle speed > Threshold DID value i.e. greater than 5")

        RESULT.InsertComment("Step 6: Send in extended session.(SID $85, SF $01).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 01 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 7: Verify ACU send NRC 88")
        RESULT.InsertComment("Expected: 738:08 03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU send NRC 88")

        RESULT.InsertComment("Step 8: Send extended session (SID $85, SF $02).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 02 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_85_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 9: Verify ACU send NRC 88")
        RESULT.InsertComment("Expected: 738:08 03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU send NRC 88")

        RESULT.InsertComment("Step 10: Send extended session (SID $85, SF $81).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 81 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_85_81)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 11: Verify ACU send NRC 88")
        RESULT.InsertComment("Expected: 738:08 03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU send NRC 88")

        RESULT.InsertComment("Step 12: Send extended session (SID $85, SF $82).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 82 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_85_82)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 13: Verify ACU send NRC 88")
        RESULT.InsertComment("Expected: 738:08 03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU send NRC 88")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
