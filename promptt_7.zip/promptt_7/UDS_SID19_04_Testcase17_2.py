# Author: Christy, Krishna
# Test Case : SID19 04_Testcase17
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : Same date record for 01 and 02 Freeze frame after flashing and first DTC check
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_04_80_70_13_01,
    UDS_REQ_19_04_80_70_13_02,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase17"
    tc_desc = "Same date record for 01 and 02 Freeze frame after flashing and first DTC check"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase17")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Perform flashing.")
        RESULT.LogAction("MANUAL / precondition step", "Perform flashing.")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 730: 19 04 80 70 13 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_70_13_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 5: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: %%(text-wrap-mode:nowrap;)738: 59 04 80 70 13 00%!")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 6: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 730: 19 04 80 70 13 02")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_70_13_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 7: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 738: 59 04 80 70 13 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 8: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 730: 19 04 80 70 13 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_70_13_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 9: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 01 11 F1 B2 00 00 F1 B1 78 5E F1 B0 00 00 00 F1 B9 00 04 44 00 00 04 74 04 48 59 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 18 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 730: 19 04 80 70 13 02")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_70_13_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 11: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 02 11 F1 B2 00 00 F1 B1 78 5E F1 B0 00 00 00 F1 B9 00 04 44 00 00 04 74 04 48 59 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 18 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
