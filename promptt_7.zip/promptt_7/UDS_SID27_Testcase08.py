# Author: Christy, Krishna
# Test Case : SID27_Testcase08
# Folder    : Security Access Service (SID $27)
# Service   : 0x27 SecurityAccess
# Intention : To Verify NRC_ ($13). The length of the message is wrong with level 1 security.
# Verifies  : ISSUE:33629950

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_01_FF_FF_FF_FF_FF,
    UDS_REQ_27_02_FF_FF_FF_FF_FF,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_7F_27_13,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID27_Testcase08"
    tc_desc = "To Verify NRC_ ($13). The length of the message is wrong with level 1 security."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID27_Testcase08")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x27 SecurityAccess")
        RESULT.InsertComment("Requirements verified: ISSUE:33629950")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send Tester Present Request(SID $3E, SF $00) in periodically")
        RESULT.InsertComment("Expected: 730: 02 3E 00 00 00 00 00 00 738: 02 7E 00 FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Verify no active fault is detected.")
        RESULT.InsertComment("Expected: No Fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify no active fault is detected.")

        RESULT.InsertComment("Step 4: Send request for Extended Diagnostic session ID 730: 02 10 03 FF FF FF FF FF")
        RESULT.InsertComment("Expected: ID 730: 02 10 03 00 00 00 00 00 ID 738:06 50 03 00 32 01 F4 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Send Security Seed Request with wrong length ID 730: xx 27 01 FF FF FF FF FF (xx can other 02)")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. D 738: 03 7F 27 13 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_27_01_FF_FF_FF_FF_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_13)

        RESULT.InsertComment("Step 6: Request Seed with wrong length ID 730: xx 27 02 FF FF FF FF FF (xx can other 02)")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID738: 03 7F 27 13 FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_27_02_FF_FF_FF_FF_FF)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
