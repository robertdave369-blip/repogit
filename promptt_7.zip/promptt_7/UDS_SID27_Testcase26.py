# Author: Christy, Krishna
# Test Case : SID27_Testcase26
# Folder    : Security Access Service (SID $27)
# Service   : 0x27 SecurityAccess
# Intention : To verify NRC_($7F) test on Physical Request ID ($730) on default session for level1 and level3 security.
# Verifies  : ISSUE:33629950

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_01,
    UDS_REQ_27_02,
    UDS_REQ_27_05,
    UDS_REQ_27_06,
    UDS_REQ_READ_ACTIVE_SESSION,
    UDS_REQ_SESSION_DEFAULT,
    UDS_RESP_7F_27_7F,
    UDS_RESP_ACTIVE_SESSION_DEFAULT,
    UDS_RESP_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID27_Testcase26"
    tc_desc = "To verify NRC_($7F) test on Physical Request ID ($730) on default session for level1 and level3 security."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID27_Testcase26")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x27 SecurityAccess")
        RESULT.InsertComment("Requirements verified: ISSUE:33629950")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active fault is detected.")
        RESULT.InsertComment("Expected: No Fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify no active fault is detected.")

        RESULT.InsertComment("Step 3: Enter Enter default session")
        RESULT.InsertComment("Expected: 730: 02 10 01 00 00 00 00 00 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send Read Active Diagnostic Session command(SID $22,DID $F186).")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 86 FF FF FF FF ID 738: 04 62 F1 86 01 FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

        RESULT.InsertComment("Step 5: Send in default session.(SID $27, SF $01).")
        RESULT.InsertComment("Expected: 730: 02 27 01 00 00 00 00 00 738: 03 7F 27 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_27_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_7F)

        RESULT.InsertComment("Step 6: Send in default session.(SID $27, SF $02).")
        RESULT.InsertComment("Expected: 730: 02 27 02 00 00 00 00 00 738: 03 7F 27 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_27_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_7F)

        RESULT.InsertComment("Step 7: Send in default session.(SID $27, SF $05).")
        RESULT.InsertComment("Expected: 730: 02 27 05 00 00 00 00 00 738: 03 7F 27 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_27_05)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_7F)

        RESULT.InsertComment("Step 8: Send in default session.(SID $27, SF $06).")
        RESULT.InsertComment("Expected: 730: 02 27 06 00 00 00 00 00 738: 03 7F 27 7F AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_27_06)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:3]), UDS_RESP_7F_27_7F)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
