# Author: Christy, Krishna
# Test Case : SID2E_Testcase12
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify NRC22 and validate DIDs with crash DTC present.
# Verifies  : ISSUE:33696864, ISSUE:33696865, ISSUE:33696866

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_61,
    UDS_REQ_2E_01_00_18,
    UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290,
    UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01,
    UDS_REQ_2E_F1_00_01,
    UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086,
    UDS_REQ_2E_F1_99_23_02_26,
    UDS_REQ_2E_F1_9D_18_09_18,
    UDS_REQ_SESSION_PROGRAMMING,
    UDS_RESP_50_02,
    UDS_RESP_67_61,
    UDS_RESP_7F_2E_22,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase12"
    tc_desc = "To verify NRC22 and validate DIDs with crash DTC present."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase12")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696864, ISSUE:33696865, ISSUE:33696866")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        # --- Write project-default Variant Code / EOL baseline ---
        manage_variant_code("DEFAULT", project="M310_M314_M110")
        manage_eol_code("DEFAULT", project="M310_M314_M110")

        RESULT.InsertComment("Step 1: Verify Write DID F198 With Active Crash DTC")
        RESULT.LogAction("MANUAL / precondition step", "Verify Write DID F198 With Active Crash DTC")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Create Front Crash")
        RESULT.LogAction("MANUAL / precondition step", "Create Front Crash")

        RESULT.InsertComment("Step 4: Verify Crash DTC")
        RESULT.InsertComment("Expected: Active,DTC_CRASH_DETECT_FRONT, DTC: 9061 96 8B")
        RESULT.LogAction("MANUAL / precondition step", "Verify Crash DTC")

        RESULT.InsertComment("Step 5: Send Extended Session Request")
        RESULT.InsertComment("Expected: ID 730: 02 10 02 00 00 00 00 00 ID 738: 02 50 02 00 32 01 F4 AA")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_PROGRAMMING)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:2]), UDS_RESP_50_02)

        RESULT.InsertComment("Step 6: Unlock Security Level 1")
        RESULT.InsertComment("Expected: ID 730: 02 27 61 00 00 00 00 00 ID 738: 06 67 61 XX XX XX XX 00 ID 730: 06 27 62 YY YY YY YY 00 ID 738: 02 67 62 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_27_61)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:2]), UDS_RESP_67_61)

        RESULT.InsertComment("Step 7: Send WriteDatabyIdentifier request(SID: $2E DID:$F1 98)")
        RESULT.InsertComment("Expected: 730: 00 13 2E F1 98 AA AA AA AA AA AA 20 20 20 20 20 20 20 20 20 20")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 8: Verify Negative Response")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        RESULT.LogAction("MANUAL / precondition step", "Verify Negative Response")

        RESULT.InsertComment("Step 9: Send WriteDatabyIdentifier request (SID: $2E DID: $F100) 730:04 2E F1 00 01 00 00 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_00_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 10: Send WriteDatabyIdentifier request (SID: $2E DID: $0102) 730: 2E 01 02 7F 0F 0F AB 2A 18 01 00 00 00 00 00 00 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 11: Send WriteDatabyIdentifier request (SID: $2E DID: $(F199) to set 0X03 730: 08 06 2E F1 99 23 02 26 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_99_23_02_26)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 12: Send WriteDatabyIdentifier request (SID: $2E DID: $(F19D) to set 0X03 730: 08 06 2E F1 9D 18 09 18 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_9D_18_09_18)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 13: Send WriteDatabyIdentifier request(SID: $2E DID:$0100) to set 0X18 730: 08 04 2E 01 00 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_00_18)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 14: Send WriteDatabyIdentifier request(SID: $2E DID:$0101) 730: 2E 01 01 2B 10 00 03 20 00 20 04 00 00 00 04 01 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

        RESULT.InsertComment("Step 15: Send WriteDatabyIdentifier request (SID: $2E DID: $0102) 730: 2E 01 02 7F 0F 0F AB 2A 18 01 00 00 00 00 00 00 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 7F 2E 22")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_22)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        RESULT.InsertComment("Teardown: restore project-default Variant Code / EOL")
        manage_variant_code("DEFAULT", project="M310_M314_M110")
        manage_eol_code("DEFAULT", project="M310_M314_M110")
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
