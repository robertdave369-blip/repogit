# Author: Christy, Krishna
# Test Case : SID2E_Testcase06
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : Validation of DID ($0100)- MODEL NUMBER
# Verifies  : ISSUE:32591593

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_01_00,
    UDS_REQ_2E_01_00_18,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_6E_01_00,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase06"
    tc_desc = "Validation of DID ($0100)- MODEL NUMBER"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase06")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:32591593")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set Bench to normal condition")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$0100) to set 0X18")
        RESULT.InsertComment("Expected: 730: 04 2E 01 00 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 738: 03 6E 01 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_00_18)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_01_00)

        RESULT.InsertComment("Step 3: Send DiagnosticSessionControl command to request extended diagnostic session. (SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 4: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 5: Send ReadDatabyIdentifier request to read MODEL NUMBER (SID: $22 DID:$0100)")
        RESULT.InsertComment("Expected: ID 730: 03 22 01 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_01_00)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 6: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: ID 738: 10 0B 62 01 00 XX XX XX ID 730: 30 00 00 AA AA AA AA AA ID 738: 21 XX XX XX XX XX XX XX (18 Bytes of Response Data With 18)")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
