# Author: Christy, Krishna
# Test Case : SID11_Testcase31
# Folder    : ECU Reset Service (SID $11)
# Service   : 0x11 ECUReset
# Intention : To Verify NRC_ ($33), ECU Reset Request ($11) with SF $01 and 03 in Extended session with Level3 security in ASW.
# Verifies  : ISSUE:33629773

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID11_Testcase31"
    tc_desc = "To Verify NRC_ ($33), ECU Reset Request ($11) with SF $01 and 03 in Extended session with Level3 security in ASW."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID11_Testcase31")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x11 ECUReset")
        RESULT.InsertComment("Requirements verified: ISSUE:33629773")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Verify 2C0 message and confirm communication")
        RESULT.InsertComment("Expected: 2C0 msg present")
        RESULT.InsertComment("Bus communication confirmed by read_software_version() above.")

        RESULT.InsertComment("Step 4: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        RESULT.InsertComment("Expected: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        RESULT.InsertComment("Expected: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        RESULT.InsertComment("Step 6: %%(color:rgb(30, 30, 30);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:non")
        sec_status = Internal_Security_Access(0x05)
        RESULT.InterpretEqualResult("Security Access level seed 0x05 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Send Hard ECU Reset request (SID: $11 SF 01) in extended session.")
        RESULT.InsertComment("Expected: 738: 02 7F 11 33 FF FF FF FF")
        RESULT.LogAction("MANUAL / precondition step", "Send Hard ECU Reset request (SID: $11 SF 01) in extended session.")

        RESULT.InsertComment("Step 8: Send Soft ECU Reset request (SID: $11 SF 03) in extended session.")
        RESULT.InsertComment("Expected: 738: 02 7F 11 33 FF FF FF FF")
        RESULT.LogAction("MANUAL / precondition step", "Send Soft ECU Reset request (SID: $11 SF 03) in extended session.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
