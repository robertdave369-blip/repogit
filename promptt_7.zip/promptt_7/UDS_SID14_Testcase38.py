# Author: Christy, Krishna
# Test Case : SID14_Testcase38
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : Test on Functional Request ID ($7DF) with Devices faults on Default session.
# Verifies  : ISSUE:33697042, ISSUE:33697043

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_CLEAR_ALL_DTC,
    UDS_REQ_SESSION_DEFAULT,
    UDS_RESP_54,
    UDS_RESP_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase38"
    tc_desc = "Test on Functional Request ID ($7DF) with Devices faults on Default session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase38")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697042, ISSUE:33697043")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send DiagnosticSessionControl command to request Default diagnostic session. (SID $10, SF $01).")
        RESULT.InsertComment("Expected: ID 730: 02 10 01 00 00 00 00 00 ID 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 7DF: 04 14 FF FF FF 00 00 00 ID 738: 01 54 FF FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 5: Create Open DRIVER_PRE_TENSIONER_SQUIB fault.")
        RESULT.InsertComment("Expected: Verify DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create Open DRIVER_PRE_TENSIONER_SQUIB fault.")

        RESULT.InsertComment("Step 6: Create PASSENGER SEAT BELT LEAK TO PLUS fault.")
        RESULT.InsertComment("Expected: Verify PASSENGER SEAT BELT LEAK TO PLUS fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create PASSENGER SEAT BELT LEAK TO PLUS fault.")

        RESULT.InsertComment("Step 7: Create RIGHT FRSU SHORT TO GROUND fault.")
        RESULT.InsertComment("Expected: Verify RIGHT FRSU SHORT TO GROUND fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create RIGHT FRSU SHORT TO GROUND fault.")

        RESULT.InsertComment("Step 8: Create CRASH OUTPUT LINE SHORT TO GROUND fault.")
        RESULT.InsertComment("Expected: Verify CRASH OUTPUT LINE SHORT TO GROUND fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create CRASH OUTPUT LINE SHORT TO GROUND fault.")

        RESULT.InsertComment("Step 9: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 7DF: 04 14 FF FF FF 00 00 00 ID 738: 01 54 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 10: Wait for qualify time,verif DTC is detected again")
        RESULT.LogAction("MANUAL / precondition step", "Wait for qualify time,verif DTC is detected again")

        RESULT.InsertComment("Step 11: Set All created faults to Normal state.")
        RESULT.InsertComment("Expected: Verify DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN fault is Historic. Verify PASSENGER SEAT BELT LEAK TO PLUS fault is Historic. Verify RIGHT FRSU SHORT TO GROUND fault is Historic. Verify CRASH OUTPUT LI")
        RESULT.LogAction("MANUAL / precondition step", "Set All created faults to Normal state.")

        RESULT.InsertComment("Step 12: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 7DF: 04 14 FF FF FF 00 00 00 ID 738: 01 54 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 13: Verify the faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify the faults.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
