# Author: Christy, Krishna
# Test Case : SID11_Testcase30
# Folder    : ECU Reset Service (SID $11)
# Service   : 0x11 ECUReset
# Intention : To Verify Time out response: After IGN ON, the software shall enable CAN Diagnostic communication within 500ms.
# Verifies  : ISSUE:32591237, ISSUE:32591255

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_READ_ACTIVE_SESSION,
    UDS_RESP_ACTIVE_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID11_Testcase30"
    tc_desc = "To Verify Time out response: After IGN ON, the software shall enable CAN Diagnostic communication within 500ms."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID11_Testcase30")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x11 ECUReset")
        RESULT.InsertComment("Requirements verified: ISSUE:32591237, ISSUE:32591255")
        RESULT.InsertComment("Pre-Action: Precondition: ECU should be in Application")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Perform ECU Reset both Hard Reset SID 11 01 and Soft Reset 11 03")
        RESULT.LogAction("MANUAL / precondition step", "Perform ECU Reset both Hard Reset SID 11 01 and Soft Reset 11 03")

        RESULT.InsertComment("Step 4: Immediately Read Active Diagnostic Session.")
        RESULT.InsertComment("Expected: 738: Timeout")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        RESULT.LogAction("Active diagnostic session response", str(response))

        RESULT.InsertComment("Step 5: Read the active diagnostic session at 200 ms after reset")
        RESULT.InsertComment("Expected: 738: Timeout")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        RESULT.LogAction("Active diagnostic session response", str(response))

        RESULT.InsertComment("Step 6: %%(font-style:normal;) Read the active diagnostic session at 400 ms from IGN ON%!")
        RESULT.InsertComment("Expected: 738: 04 62 F1 86 01 FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate active diagnostic session", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

        RESULT.InsertComment("Step 7: Read the active diagnostic session at 500 ms after reset.")
        RESULT.InsertComment("Expected: %%(color:rgb(65, 65, 65);font-style:normal;font-variant-ligatures:normal;font-variant-caps:normal;letter-spacing:normal;orphans:2;text-align:left;text-indent:0px;text-transform:none;widows:2;word-spac")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate active diagnostic session", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_DEFAULT)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
