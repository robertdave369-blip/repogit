# Author: Christy, Krishna
# Test Case : SID14_Testcase32
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : 1.Test on Functional Request ID ($7DF) with SID $14 SF $0x000000
# Verifies  : ISSUE:33697045

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_14_00_00_00,
    UDS_REQ_SESSION_DEFAULT,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_7F_14_31,
    UDS_RESP_SESSION_DEFAULT,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase32"
    tc_desc = "1.Test on Functional Request ID ($7DF) with SID $14 SF $0x000000"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase32")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697045")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send 3E to keep current session.(period:3s)")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Send to Default session.(SID $10, SF $01).")
        RESULT.InsertComment("Expected: 7DF: 02 10 01 00 00 00 00 00 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send in extended session.(SID $14, SF $000000).")
        RESULT.InsertComment("Expected: 7DF: 04 14 00 00 00 00 00 00 738: 03 7F 14 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_14_00_00_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_14_31)

        RESULT.InsertComment("Step 5: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 7DF: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 6: Send in extended session.(SID $14, SF $000000).")
        RESULT.InsertComment("Expected: 7DF: 04 14 00 00 00 00 00 00 738: 03 7F 14 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_14_00_00_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_14_31)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
