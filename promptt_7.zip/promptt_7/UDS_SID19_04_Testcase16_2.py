# Author: Christy, Krishna
# Test Case : SID19 04_Testcase16
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : 1. Test on Physical Request ID ($730) 2.Test on default session 3. Check the LOOP7 fault When ACU receives report DTC by Snapshot Record by DTC Number (SF $04)
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697873, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase16"
    tc_desc = "1. Test on Physical Request ID ($730) 2.Test on default session 3. Check the LOOP7 fault When ACU receives report DTC by Snapshot Record by DTC Number (SF $04)"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase16")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697873, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Set the driver Buckle status as Unbuckled and Passenger buckle status as Buckled.")
        RESULT.InsertComment("Expected: STS_SEAT_BLT_DRV =0x0 STS_SEAT_BLT_PSGR =0x1")
        RESULT.InsertComment("DBC names referenced: STS_SEAT_BLT_PSGR")
        RESULT.LogAction("MANUAL / precondition step", "Set the driver Buckle status as Unbuckled and Passenger buckle status as Buckled.")

        RESULT.InsertComment("Step 4: Set the PASSENGER AIRBAG OPEN fault")
        RESULT.LogAction("MANUAL / precondition step", "Set the PASSENGER AIRBAG OPEN fault")

        RESULT.InsertComment("Step 5: Verify fault is detected.")
        RESULT.InsertComment("Expected: Active fault, DTC:801013,Error Code:0x8B")
        RESULT.LogAction("MANUAL / precondition step", "Verify fault is detected.")

        RESULT.InsertComment("Step 6: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 13")
        RESULT.InsertComment("Expected: 19 04 80 10 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 13")

        RESULT.InsertComment("Step 7: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 10 13 8B 01 0A F1 B2 00 00 F1 B1 74 6D F1 B0 00 00 00 F1 B9 00 04 44 00 00 37 FA 04 48 45 55 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 11")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 8: Remove the PASSENGER AIRBAG OPEN fault")
        RESULT.LogAction("MANUAL / precondition step", "Remove the PASSENGER AIRBAG OPEN fault")

        RESULT.InsertComment("Step 9: Verify Historic fault is Historic .")
        RESULT.InsertComment("Expected: Historic, DTC:801013,Error Code:0x000A")
        RESULT.LogAction("MANUAL / precondition step", "Verify Historic fault is Historic .")

        RESULT.InsertComment("Step 10: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 11: Set the driver Buckle status as Buckled and Passenger buckle status as Unbuckled.")
        RESULT.InsertComment("Expected: STS_SEAT_BLT_DRV =0x1 STS_SEAT_BLT_PSGR =0x0")
        RESULT.InsertComment("DBC names referenced: STS_SEAT_BLT_PSGR")
        RESULT.LogAction("MANUAL / precondition step", "Set the driver Buckle status as Buckled and Passenger buckle status as Unbuckled.")

        RESULT.InsertComment("Step 12: Set the PASSENGER AIRBAG Short fault")
        RESULT.LogAction("MANUAL / precondition step", "Set the PASSENGER AIRBAG Short fault")

        RESULT.InsertComment("Step 13: Verify fault is detected.")
        RESULT.InsertComment("Expected: Active, DTC:801012,Error Code:0x008B")
        RESULT.LogAction("MANUAL / precondition step", "Verify fault is detected.")

        RESULT.InsertComment("Step 14: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 12")
        RESULT.InsertComment("Expected: 19 04 80 10 12 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 12")

        RESULT.InsertComment("Step 15: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 10 12 8B 01 0A F1 B2 00 00 F1 B1 74 6D F1 B0 00 00 00 F1 B9 00 04 44 00 00 37 FA 04 48 45 55 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 11")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 16: Remove the PASSENGER AIRBAG short fault")
        RESULT.LogAction("MANUAL / precondition step", "Remove the PASSENGER AIRBAG short fault")

        RESULT.InsertComment("Step 17: Verify fault is Historic")
        RESULT.InsertComment("Expected: Historic, DTC:801012,Error Code:0x000A")
        RESULT.LogAction("MANUAL / precondition step", "Verify fault is Historic")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
