# Author: Christy, Krishna
# Test Case : SID2E_Testcase01
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify Write DataByIdentifier service (SID 0x2E) followed by the data identifiers (Write Default EOL).
# Verifies  : ISSUE:32591240, ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:34697666, ISSUE:32591241

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_2E_01_02_03_03_CD_A0,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03_00_32_13_88,
    UDS_RESP_6E_01_02,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase01"
    tc_desc = "To verify Write DataByIdentifier service (SID 0x2E) followed by the data identifiers (Write Default EOL)."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase01")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:32591240, ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:34697666, ISSUE:32591241")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        # --- Write project-default Variant Code / EOL baseline ---
        manage_eol_code("DEFAULT", project="M310_M314_M110")

        RESULT.InsertComment("Step 1: Write Default EOL using SID 2E")
        RESULT.LogAction("MANUAL / precondition step", "Write Default EOL using SID 2E")

        RESULT.InsertComment("Step 2: Set bench to normal conditon")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Read DTC")
        RESULT.InsertComment("Expected: No DTC")
        RESULT.LogAction("MANUAL / precondition step", "Read DTC")

        RESULT.InsertComment("Step 4: Send Request for Extended Session. ID 730: 02 10 03 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 10 03 FF FF FF FF FF ID 738: 06 50 03 00 32 13 88 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 5: Send Request for Security Seed. ID 730: 02 27 01 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 01 FF FF FF FF FF ID 738: 06 67 01 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 6: Send Request for Security Key. ID 730: 06 27 02 yy yy yy yy FF")
        sec_status = Internal_Security_Access(0x01)
        RESULT.InterpretEqualResult("Security Access level seed 0x01 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Write EOL using 2E service 730: 2E 01 02 03 03 CD A0 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: Verify ACU response: ID 738: 6E 01 02")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_03_03_CD_A0)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_01_02)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        RESULT.InsertComment("Teardown: restore project-default Variant Code / EOL")
        manage_eol_code("DEFAULT", project="M310_M314_M110")
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
