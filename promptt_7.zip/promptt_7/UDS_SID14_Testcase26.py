# Author: Christy, Krishna
# Test Case : SID14_Testcase26
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : To verify NRC_($22). Conditions are not correct when check engine is not in running state(730).
# Verifies  : ISSUE:33697045, ISSUE:34698177

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_CLEAR_ALL_DTC,
    UDS_REQ_SESSION_DEFAULT,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_7F_14_22,
    UDS_RESP_SESSION_DEFAULT,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase26"
    tc_desc = "To verify NRC_($22). Conditions are not correct when check engine is not in running state(730)."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase26")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697045, ISSUE:34698177")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send 3E to keep current session.(period:3s)")
        RESULT.InsertComment("Expected: Test on Physical Request ID")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 4: Send DiagnosticSessionControl command to request Extended diagnostic session. (SID $10, SF $03).")
        RESULT.InsertComment("Expected: ID 730: 02 10 03 00 00 00 00 00 ID 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Set Vehicle Speed = 0")
        RESULT.InsertComment("Expected: Vehcile speed set to 0")
        RESULT.LogAction("MANUAL / precondition step", "Set Vehicle Speed = 0")

        RESULT.InsertComment("Step 6: check engine is not in running state")
        RESULT.InsertComment("Expected: Engine respective CAN signal is not equal to run")
        RESULT.LogAction("MANUAL / precondition step", "check engine is not in running state")

        RESULT.InsertComment("Step 7: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 03 7F 14 22 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_14_22)

        RESULT.InsertComment("Step 8: Send DiagnosticSessionControl command to request Default diagnostic session. (SID $10, SF $01).")
        RESULT.InsertComment("Expected: ID 730: 02 10 01 00 00 00 00 00 ID 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 9: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 03 7F 14 22 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_14_22)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
