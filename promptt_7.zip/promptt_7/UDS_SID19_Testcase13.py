# Author: Christy, Krishna
# Test Case : SID19_Testcase13
# Folder    : Read DTC Information Service (SID $19)
# Service   : 0x19 ReadDTCInformation
# Intention : To Verify NRC88 for Boundary Values for Physical Id
# Verifies  : ISSUE:33692241, ISSUE:33696905

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19_Testcase13"
    tc_desc = "To Verify NRC88 for Boundary Values for Physical Id"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_Testcase13")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33692241, ISSUE:33696905")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")
        RESULT.LogAction("MANUAL / precondition step", "To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify No faults")
        RESULT.InsertComment("Expected: No faults")
        RESULT.LogAction("MANUAL / precondition step", "Verify No faults")

        RESULT.InsertComment("Step 4: Set Vechicle speed > Threshold DID value i.e. greater than 5")
        RESULT.LogAction("MANUAL / precondition step", "Set Vechicle speed > Threshold DID value i.e. greater than 5")

        RESULT.InsertComment("Step 5: Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")
        RESULT.InsertComment("Expected: ID 730:: 02 10 03 FF FF FF FF FF ID 738:: 06 50 03 00 32 13 88 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")

        RESULT.InsertComment("Step 6: Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX i.e. greater than 5")
        RESULT.InsertComment("DBC names referenced: IEB1_FD_10")
        RESULT.LogAction("MANUAL / precondition step", "Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX i.e. greater than 5")

        RESULT.InsertComment("Step 7: Send in extended session.(SID $19, SF $06).")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send in extended session.(SID $19, SF $06).")

        RESULT.InsertComment("Step 8: Send in extended session.(SID $19, SF $0A).")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send in extended session.(SID $19, SF $0A).")

        RESULT.InsertComment("Step 9: Send in extended session.(SID $19, SF $01).")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send in extended session.(SID $19, SF $01).")

        RESULT.InsertComment("Step 10: Send in extended session.(SID $19, SF $02).")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send in extended session.(SID $19, SF $02).")

        RESULT.InsertComment("Step 11: Send in extended session. (SID $19, SF $04).")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send in extended session. (SID $19, SF $04).")

        RESULT.InsertComment("Step 12: Verify ACU send NRC 88")
        RESULT.InsertComment("Expected: 738:03 7F 19 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU send NRC 88")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
