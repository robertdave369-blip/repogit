# Author: Christy, Krishna
# Test Case : SID19 04_Testcase09
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : DTC Snapshot Record Number_normal conditions
# Verifies  : ISSUE:32591249, ISSUE:33697815, ISSUE:33697873, ISSUE:32591250, ISSUE:33697896, ISSUE:32591251, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699427, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_04_80_10_1A_01,
    UDS_REQ_19_04_80_10_1A_02,
    UDS_REQ_19_04_80_10_1A_FF,
    UDS_REQ_19_04_80_72_11_01,
    UDS_REQ_19_04_80_72_11_02,
    UDS_REQ_19_04_80_72_11_FF,
    UDS_REQ_19_04_80_95_96_01,
    UDS_REQ_19_04_80_95_96_02,
    UDS_REQ_19_04_80_95_96_FF,
    UDS_REQ_19_04_92_04_1B_01,
    UDS_REQ_19_04_92_04_1B_02,
    UDS_REQ_19_04_92_04_1B_FF,
    UDS_REQ_19_04_92_06_64_01,
    UDS_REQ_19_04_92_06_64_02,
    UDS_REQ_19_04_92_06_64_FF,
    UDS_REQ_19_04_92_07_12_01,
    UDS_REQ_19_04_92_07_12_02,
    UDS_REQ_19_04_92_07_12_FF,
    UDS_REQ_19_04_92_0B_13_01,
    UDS_REQ_19_04_92_0B_13_02,
    UDS_REQ_19_04_92_0B_13_FF,
    UDS_REQ_19_04_92_10_12_01,
    UDS_REQ_19_04_92_10_12_02,
    UDS_REQ_19_04_92_10_12_FF,
    UDS_REQ_19_04_92_18_11_01,
    UDS_REQ_19_04_92_18_11_02,
    UDS_REQ_19_04_92_18_11_FF,
    UDS_REQ_19_04_92_1C_13_01,
    UDS_REQ_19_04_92_1C_13_02,
    UDS_REQ_19_04_92_1C_13_FF,
    UDS_REQ_19_04_92_53_2B_01,
    UDS_REQ_19_04_92_53_2B_02,
    UDS_REQ_19_04_92_53_2B_FF,
    UDS_REQ_19_04_92_54_2B_01,
    UDS_REQ_19_04_92_54_2B_02,
    UDS_REQ_19_04_92_54_2B_FF,
    UDS_REQ_19_04_98_F9_13_01,
    UDS_REQ_19_04_98_F9_13_02,
    UDS_REQ_19_04_98_F9_13_FF,
    UDS_REQ_19_04_99_0E_13_01,
    UDS_REQ_19_04_99_0E_13_02,
    UDS_REQ_19_04_99_0E_13_FF,
    UDS_REQ_19_04_99_14_13_01,
    UDS_REQ_19_04_99_14_13_02,
    UDS_REQ_19_04_99_14_13_FF,
    UDS_REQ_19_04_D2_71_00_01,
    UDS_REQ_19_04_D2_71_00_02,
    UDS_REQ_19_04_D2_71_00_FF,
    UDS_REQ_22_F1_B2,
    UDS_REQ_22_F1_B6,
    UDS_RESP_59_04_80_10_1A_8B_01_11,
    UDS_RESP_59_04_80_10_1A_8B_02_11,
    UDS_RESP_59_04_80_72_11_8B_01_11,
    UDS_RESP_59_04_80_72_11_8B_02_11,
    UDS_RESP_59_04_80_95_96_08_01_11,
    UDS_RESP_59_04_80_95_96_08_02_11,
    UDS_RESP_59_04_92_00_00_8B,
    UDS_RESP_59_04_92_04_1B_8B_01_11,
    UDS_RESP_59_04_92_04_1B_8B_02_11,
    UDS_RESP_59_04_92_06_64_8B_01_11,
    UDS_RESP_59_04_92_06_64_8B_02_11,
    UDS_RESP_59_04_92_07_12_8B_01_11,
    UDS_RESP_59_04_92_07_12_8B_02_11,
    UDS_RESP_59_04_92_0B_13_8B_01_11,
    UDS_RESP_59_04_92_0B_13_8B_02_11,
    UDS_RESP_59_04_92_10_12_8B_01_11,
    UDS_RESP_59_04_92_10_12_8B_02_11,
    UDS_RESP_59_04_92_18_11_8B_01_11,
    UDS_RESP_59_04_92_18_11_8B_02_11,
    UDS_RESP_59_04_92_1C_13_13_8B_02,
    UDS_RESP_59_04_92_1C_13_8B_01_11,
    UDS_RESP_59_04_92_53_2B_8B_01_11,
    UDS_RESP_59_04_92_53_2B_8B_02_11,
    UDS_RESP_59_04_92_54_2B_8B_01_11,
    UDS_RESP_59_04_92_54_2B_8B_02_11,
    UDS_RESP_59_04_98_F9_13_8B_01_11,
    UDS_RESP_59_04_98_F9_13_8B_02_11,
    UDS_RESP_59_04_99_0E_13_8B_01_11,
    UDS_RESP_59_04_99_0E_13_8B_02_11,
    UDS_RESP_59_04_99_14_13_8B_01_11,
    UDS_RESP_59_04_99_14_13_8B_02_11,
    UDS_RESP_59_04_D2_71_00_8B,
    UDS_RESP_62_F1_B2,
    UDS_RESP_62_F1_B2_00_C0,
    UDS_RESP_62_F1_B2_19_00,
    UDS_RESP_62_F1_B2_4B_00,
    UDS_RESP_62_F1_B6_00_00,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase09"
    tc_desc = "DTC Snapshot Record Number_normal conditions"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase09")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:32591249, ISSUE:33697815, ISSUE:33697873, ISSUE:32591250, ISSUE:33697896, ISSUE:32591251, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699427, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: 1.Send with DTC. 2. Snapshot data recorded for first 15 DTC’s & 16th DTC onwards no record to be available, it should give just positive response")
        RESULT.LogAction("MANUAL / precondition step", "1.Send with DTC. 2. Snapshot data recorded for first 15 DTC’s & 16th DTC onwards no record to be available, it should give just positive response")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set the below mentioned parameters before creating DTC // Vehicle Speed = 0x5 kmph// Battery voltage = 12 V & IGN Voltage = 12V// Original odometer Occurrence reading is 0x50// Vehicle State = 2(Runni")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 5: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 XX XX 00 00 00 Default Value : XX YY= 01 80")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_B2)

        RESULT.InsertComment("Step 6: Create PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY fault.")

        RESULT.InsertComment("Step 7: Wait until qualify time,verify DTC_PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY is detected")
        RESULT.InsertComment("Expected: DTC_PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY, active DTC: 80 72 11")
        RESULT.LogAction("MANUAL / precondition step", "Wait until qualify time,verify DTC_PASSENGER AIRBAG SQUIB SHORT CIRCUIT TO BATTERY is detected")

        RESULT.InsertComment("Step 8: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 72 11 ID 730: 19 04 80 72 11 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 738: 59 04 80 72 11 8B 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 32 F")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_72_11_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_72_11_8B_01_11)

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 72 11// // ID 730: 19 04 80 72 11 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 80 72 11 8B 02 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_72_11_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_72_11_8B_02_11)

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 72 11 // ID 730: 19 04 80 72 11 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 80 72 11 8B 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_72_11_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_72_11_8B_01_11)

        RESULT.InsertComment("Step 11: Create PASSENGER AIRBAG SQUIB LOW RES fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create PASSENGER AIRBAG SQUIB LOW RES fault.")

        RESULT.InsertComment("Step 12: Verify DTC_PASSENGER AIRBAG SQUIB LOW RES is detected")
        RESULT.InsertComment("Expected: DTC_PASSENGER AIRBAG SQUIB LOW RES, active DTC: 80101A")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_PASSENGER AIRBAG SQUIB LOW RES is detected")

        RESULT.InsertComment("Step 13: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 1A // ID 730: 19 04 80 10 1A 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 80 10 1A 8B 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_10_1A_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_10_1A_8B_01_11)

        RESULT.InsertComment("Step 14: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 1A// // ID 730: 19 04 80 10 1A 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 80 10 1A 8B 02 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_10_1A_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_10_1A_8B_02_11)

        RESULT.InsertComment("Step 15: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 10 1A// // ID 730: 19 04 80 10 1A FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 80 10 1A 8B 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_10_1A_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_10_1A_8B_01_11)

        RESULT.InsertComment("Step 16: Create RIGHT FRSU INTERNAL ERROR fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create RIGHT FRSU INTERNAL ERROR fault.")

        RESULT.InsertComment("Step 17: Verify DTC_RIGHT FRSU INTERNAL ERROR is detected")
        RESULT.InsertComment("Expected: DTC_RIGHT FRSU INTERNAL ERROR, active// // DTC: 809596")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_RIGHT FRSU INTERNAL ERROR is detected")

        RESULT.InsertComment("Step 18: Set DTC_RIGHT FRSU INTERNAL ERROR to Historic")
        RESULT.InsertComment("Expected: DTC_RIGHT FRSU INTERNAL ERROR, historic(08)// // DTC: 809596")
        RESULT.LogAction("MANUAL / precondition step", "Set DTC_RIGHT FRSU INTERNAL ERROR to Historic")

        RESULT.InsertComment("Step 19: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B6)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B6 00 00 00 00 00 738:05 62 F1 B6 00 00 00 1B")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B6)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:5]), UDS_RESP_62_F1_B6_00_00)

        RESULT.InsertComment("Step 20: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 95 96 // ID 730: 19 04 80 95 96 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 80 95 96 08 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_95_96_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_95_96_08_01_11)

        RESULT.InsertComment("Step 21: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 95 96 // ID 730: 19 04 80 95 96 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 80 95 96 08 02 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_95_96_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_95_96_08_02_11)

        RESULT.InsertComment("Step 22: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:80 95 96 // ID 730: 19 04 80 95 96 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 80 95 96 08 01 11 F1 B2 00 05 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_80_95_96_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_80_95_96_08_01_11)

        RESULT.InsertComment("Step 23: Set vehicle Speed as VEHICLE_SPEED_= 300 kmph")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "Set vehicle Speed as VEHICLE_SPEED_= 300 kmph")

        RESULT.InsertComment("Step 24: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 4B 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:5]), UDS_RESP_62_F1_B2_4B_00)

        RESULT.InsertComment("Step 25: Create B-PILLAR RIGHT SRSU OPEN fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create B-PILLAR RIGHT SRSU OPEN fault.")

        RESULT.InsertComment("Step 26: Verify DTC_B-PILLAR RIGHT SRSU OPEN is detected")
        RESULT.InsertComment("Expected: DTC_B-PILLAR RIGHT SRSU OPEN is detected DTC: 920B13")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_B-PILLAR RIGHT SRSU OPEN is detected")

        RESULT.InsertComment("Step 27: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 0B 13 // ID 730: 19 04 92 0B 13 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 0B 13 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_0B_13_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_0B_13_8B_01_11)

        RESULT.InsertComment("Step 28: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 0B 13// // ID 730: 19 04 92 0B 13 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 0B 13 8B 02 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_0B_13_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_0B_13_8B_02_11)

        RESULT.InsertComment("Step 29: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 0B 13// // ID 730: 19 04 92 0B 13 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 0B 13 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_0B_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_0B_13_8B_01_11)

        RESULT.InsertComment("Step 30: Create PASSENGER AIRBAG DISABLE LAMP – SHORT TO BATTERY fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create PASSENGER AIRBAG DISABLE LAMP – SHORT TO BATTERY fault.")

        RESULT.InsertComment("Step 31: Verify DTC_PASSENGER AIRBAG DISABLE LAMP – SHORT TO BATTERY is detected")
        RESULT.InsertComment("Expected: DTC_PASSENGER AIRBAG DISABLE LAMP – SHORT TO BATTERY, active DTC: 921012")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_PASSENGER AIRBAG DISABLE LAMP – SHORT TO BATTERY is detected")

        RESULT.InsertComment("Step 32: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 10 12 // ID 730: 19 04 92 10 12 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 10 12 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_10_12_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_10_12_8B_01_11)

        RESULT.InsertComment("Step 33: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 10 12// // ID 730: 19 04 92 10 12 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 10 12 8B 02 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_10_12_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_10_12_8B_02_11)

        RESULT.InsertComment("Step 34: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 10 12 // ID 730: 19 04 92 10 12 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 10 12 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_10_12_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_10_12_8B_01_11)

        RESULT.InsertComment("Step 35: Create RIGHT SIDE AIRBAG UNEXPECTED SQUIB fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create RIGHT SIDE AIRBAG UNEXPECTED SQUIB fault.")

        RESULT.InsertComment("Step 36: Verify DTC_RIGHT SIDE AIRBAG UNEXPECTED SQUIB is detected")
        RESULT.InsertComment("Expected: DTC_RIGHT SIDE AIRBAG UNEXPECTED SQUIB, active DTC: 920664")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_RIGHT SIDE AIRBAG UNEXPECTED SQUIB is detected")

        RESULT.InsertComment("Step 37: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 06 64 // ID 730: 19 04 92 06 64 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 06 64 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_06_64_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_06_64_8B_01_11)

        RESULT.InsertComment("Step 38: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 06 64// // ID 730: 19 04 92 06 64 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 06 64 8B 02 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_06_64_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_06_64_8B_02_11)

        RESULT.InsertComment("Step 39: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 06 64// // ID 730: 19 04 92 06 64 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 06 64 8B 01 11 F1 B2 4B 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 01 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_06_64_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_06_64_8B_01_11)

        RESULT.InsertComment("Step 40: Set vehicle Speed as VEHICLE_SPEED_= 3 kmph Brake Switch Status as Pressed.")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "Set vehicle Speed as VEHICLE_SPEED_= 3 kmph Brake Switch Status as Pressed.")

        RESULT.InsertComment("Step 41: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2) (SID: $22). (DID: 0459)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 00 C0 00 00 00 ID 730 :03 22 04 59 00 00 00 00 00 738:05 62 04 59 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:5]), UDS_RESP_62_F1_B2_00_C0)

        RESULT.InsertComment("Step 42: Create DRIVER DC'S cross connect & CO-DRIVER DC cross connect fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create DRIVER DC'S cross connect & CO-DRIVER DC cross connect fault.")

        RESULT.InsertComment("Step 43: Verify DTCs_DRIVER DC'S cross connect & CO-DRIVER DC cross connect is detected")
        RESULT.InsertComment("Expected: DTCs_DRIVER DC'S cross connect & CO-DRIVER DC cross connect, active DTCs: 92532B & 92542B")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTCs_DRIVER DC'S cross connect & CO-DRIVER DC cross connect is detected")

        RESULT.InsertComment("Step 44: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 53 2B // ID 730: 19 04 92 53 2B 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 53 2B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_53_2B_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_53_2B_8B_01_11)

        RESULT.InsertComment("Step 45: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 53 2B// // ID 730: 19 04 92 53 2B 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 53 2B 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_53_2B_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_53_2B_8B_02_11)

        RESULT.InsertComment("Step 46: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 53 2B// // ID 730: 19 04 92 53 2B FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 53 2B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_53_2B_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_53_2B_8B_01_11)

        RESULT.InsertComment("Step 47: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 54 2B // ID 730: 19 04 92 54 2B 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 54 2B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_54_2B_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_54_2B_8B_01_11)

        RESULT.InsertComment("Step 48: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 54 2B// // ID 730: 19 04 92 54 2B 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 54 2B 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_54_2B_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_54_2B_8B_02_11)

        RESULT.InsertComment("Step 49: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 54 2B// // ID 730: 19 04 92 54 2B FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 54 2B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 00 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_54_2B_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_54_2B_8B_01_11)

        RESULT.InsertComment("Step 50: Create DRIVER STPS1 CONNETOR OPEN fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create DRIVER STPS1 CONNETOR OPEN fault.")

        RESULT.InsertComment("Step 51: Verify DTC_DRIVER STPS1 CONNETOR OPEN is detected")
        RESULT.InsertComment("Expected: DTC_DRIVER STPS1 CONNETOR OPEN, active DTC: 98F913")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_DRIVER STPS1 CONNETOR OPEN is detected")

        RESULT.InsertComment("Step 52: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:98 F9 13 // ID 730: 19 04 98 F9 13 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 98 F9 13 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_98_F9_13_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_98_F9_13_8B_01_11)

        RESULT.InsertComment("Step 53: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:98 F9 13// // ID 730: 19 04 98 F9 13 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 98 F9 13 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_98_F9_13_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_98_F9_13_8B_02_11)

        RESULT.InsertComment("Step 54: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:98 F9 13// // ID 730: 19 04 98 F9 13 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 98 F9 13 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_98_F9_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_98_F9_13_8B_01_11)

        RESULT.InsertComment("Step 55: Create LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE fault.")

        RESULT.InsertComment("Step 56: Verify DTC_LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE is detected")
        RESULT.InsertComment("Expected: DTC_LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE , active DTC: 92041B")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_LEFT LAP PRETENSIONER SQUIB - HIGH RESISTANCE is detected")

        RESULT.InsertComment("Step 57: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 04 1B // ID 730: 19 04 92 04 1B 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 04 1B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_04_1B_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_04_1B_8B_01_11)

        RESULT.InsertComment("Step 58: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 04 1B // ID 730: 19 04 92 04 1B 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 04 1B 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_04_1B_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_04_1B_8B_02_11)

        RESULT.InsertComment("Step 59: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 04 1B // ID 730: 19 04 92 04 1B FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 04 1B 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_04_1B_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_04_1B_8B_01_11)

        RESULT.InsertComment("Step 60: Create 2nd ROW LEFT PRETENSIONER OPEN fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create 2nd ROW LEFT PRETENSIONER OPEN fault.")

        RESULT.InsertComment("Step 61: Verify DTC_2nd ROW LEFT PRETENSIONER OPEN is detected")
        RESULT.InsertComment("Expected: DTC_2nd ROW LEFT PRETENSIONER OPEN, active DTC: 991413")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_2nd ROW LEFT PRETENSIONER OPEN is detected")

        RESULT.InsertComment("Step 62: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 991413 // ID 730: 19 04 99 14 13 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 99 14 13 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_14_13_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_14_13_8B_01_11)

        RESULT.InsertComment("Step 63: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 991413 // ID 730: 19 04 99 14 13 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 99 14 13 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_14_13_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_14_13_8B_02_11)

        RESULT.InsertComment("Step 64: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 991413// // ID 730: 19 04 99 14 13 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 99 14 13 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_14_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_14_13_8B_01_11)

        RESULT.InsertComment("Step 65: Create RIGHT CURTAIN AIRBAG - SHORT TO BATTERY fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create RIGHT CURTAIN AIRBAG - SHORT TO BATTERY fault.")

        RESULT.InsertComment("Step 66: Verify DTC_RIGHT CURTAIN AIRBAG - SHORT TO BATTERY is detected")
        RESULT.InsertComment("Expected: DTC_RIGHT CURTAIN AIRBAG - SHORT TO BATTERY, active DTC: 920712")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_RIGHT CURTAIN AIRBAG - SHORT TO BATTERY is detected")

        RESULT.InsertComment("Step 67: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 07 12 // ID 730: 19 04 92 07 12 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 07 12 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_07_12_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_07_12_8B_01_11)

        RESULT.InsertComment("Step 68: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 07 12 // ID 730: 19 04 92 07 12 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 07 12 8B 02 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_07_12_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_07_12_8B_02_11)

        RESULT.InsertComment("Step 69: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 07 12// // ID 730: 19 04 92 07 12 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 07 12 8B 01 11 F1 B2 00 C0 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_07_12_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_07_12_8B_01_11)

        RESULT.InsertComment("Step 70: Set vehicle Speed as VEHICLE_SPEED_= 100 kmph")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "Set vehicle Speed as VEHICLE_SPEED_= 100 kmph")

        RESULT.InsertComment("Step 71: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :08 03 22 F1 B2 00 00 00 00 00 738:08 05 62 F1 B2 19 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:5]), UDS_RESP_62_F1_B2_19_00)

        RESULT.InsertComment("Step 72: Create CRASH OUTPUT LINE SHORT TO GROUND fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create CRASH OUTPUT LINE SHORT TO GROUND fault.")

        RESULT.InsertComment("Step 73: Verify DTC_CRASH OUTPUT LINE SHORT TO GROUND is detected")
        RESULT.InsertComment("Expected: DTC_CRASH OUTPUT LINE SHORT TO GROUND, active DTC: 921811")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_CRASH OUTPUT LINE SHORT TO GROUND is detected")

        RESULT.InsertComment("Step 74: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 18 11 // ID 730: 19 04 92 18 11 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 18 11 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_18_11_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_18_11_8B_01_11)

        RESULT.InsertComment("Step 75: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 18 11// // ID 730: 19 04 92 18 11 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 18 11 8B 02 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_18_11_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_18_11_8B_02_11)

        RESULT.InsertComment("Step 76: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 18 11// // ID 730: 19 04 92 18 11 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 18 11 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_18_11_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_18_11_8B_01_11)

        RESULT.InsertComment("Step 77: Create CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT fault.")

        RESULT.InsertComment("Step 78: Verify DTC_CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT is detected")
        RESULT.InsertComment("Expected: DTC_CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT, active DTC: 990E13")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_CRASH OUTPUT ECALL HW LINE OPEN CIRCUIT is detected")

        RESULT.InsertComment("Step 79: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:99 0E 13// // ID 730: 19 04 99 0E 13 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 99 0E 13 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_0E_13_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_0E_13_8B_01_11)

        RESULT.InsertComment("Step 80: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:99 0E 13// // ID 730: 19 04 99 0E 13 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 99 0E 13 8B 02 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_0E_13_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_0E_13_8B_02_11)

        RESULT.InsertComment("Step 81: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:99 0E 13// // ID 730: 19 04 99 0E 13 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 99 0E 13 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_99_0E_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_99_0E_13_8B_01_11)

        RESULT.InsertComment("Step 82: Create C-PILLAR RIGHT SRSU OPEN fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create C-PILLAR RIGHT SRSU OPEN fault.")

        RESULT.InsertComment("Step 83: Verify DTC_C-PILLAR RIGHT SRSU OPEN is detected")
        RESULT.InsertComment("Expected: DTC_C-PILLAR RIGHT SRSU OPEN, active // DTC: 921C13")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_C-PILLAR RIGHT SRSU OPEN is detected")

        RESULT.InsertComment("Step 84: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 1C 13 // ID 730: 19 04 92 1C 13 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 92 1C 13 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A 3")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_1C_13_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_1C_13_8B_01_11)

        RESULT.InsertComment("Step 85: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 1C 13// // ID 730: 19 04 92 1C 13 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 1C 13 13 8B 02 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_1C_13_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_1C_13_13_8B_02)

        RESULT.InsertComment("Step 86: Send ReadDTCInformation command ($19, SF $04) to request information for DTC:92 1C 13// // ID 730: 19 04 92 1C 13 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 1C 13 8B 01 11 F1 B2 19 00 F1 B1 71 6B F1 B0 00 00 50 F1 B9 02 04 44 00 00 03 46 04 48 22 11 11 01 00 00 03 00 04 4B 01 04 59 00 04 5A")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_92_1C_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_04_92_1C_13_8B_01_11)

        RESULT.InsertComment("Step 87: Create HSCAN_BUS_OFF_FAULT fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create HSCAN_BUS_OFF_FAULT fault.")

        RESULT.InsertComment("Step 88: Verify DTC_HSCAN_BUS_OFF_FAULT is detected")
        RESULT.InsertComment("Expected: DTC_HSCAN_BUS_OFF_FAULT should not qualify DTC: D27100")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC_HSCAN_BUS_OFF_FAULT is detected")

        RESULT.InsertComment("Step 89: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: D2 71 00 // ID 730: 19 04 D2 71 00 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 D2 71 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_D2_71_00_8B)

        RESULT.InsertComment("Step 90: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: D2 71 00// // ID 730: 19 04 D2 71 00 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 D2 71 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_D2_71_00_8B)

        RESULT.InsertComment("Step 91: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: D2 71 00// // ID 730: 19 04 D2 71 00 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. // ID 738: 59 04 D2 71 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_D2_71_00_8B)

        RESULT.InsertComment("Step 92: Create ECU IN PLANT MODE fault.")
        RESULT.LogAction("MANUAL / precondition step", "Create ECU IN PLANT MODE fault.")

        RESULT.InsertComment("Step 93: Verify ECU IN PLANT MODE is detected")
        RESULT.InsertComment("Expected: DTC_ECU IN PLANT MODE should not qualify// DTC: 92 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ECU IN PLANT MODE is detected")

        RESULT.InsertComment("Step 94: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 00 00// ID 730: 19 04 D2 71 00 01")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 00 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_92_00_00_8B)

        RESULT.InsertComment("Step 95: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 00 00// ID 730: 19 04 D2 71 00 02")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 00 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_92_00_00_8B)

        RESULT.InsertComment("Step 96: Send ReadDTCInformation command ($19, SF $04) to request information for DTC: 92 00 00// ID 730: 19 04 D2 71 00 FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response.// // ID 738: 59 04 92 00 00 8B")
        response = CAN.SendDiagByValues(UDS_REQ_19_04_D2_71_00_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_04_92_00_00_8B)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
