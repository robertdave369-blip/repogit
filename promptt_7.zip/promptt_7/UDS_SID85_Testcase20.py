# Author: Christy, Krishna
# Test Case : SID85_Testcase20
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : To verify DTC records with SF 02 followed by SF 01 on Physical mode in Extended session
# Verifies  : ISSUE:33692205, ISSUE:33692206

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_06_80_10_13_FF,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_59_06_80_10_13_40,
    UDS_RESP_59_06_80_10_13_8B_01,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase20"
    tc_desc = "To verify DTC records with SF 02 followed by SF 01 on Physical mode in Extended session"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase20")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:33692205, ISSUE:33692206")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Test on Loop fault")
        RESULT.LogAction("MANUAL / precondition step", "Test on Loop fault")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Send 3E to keep current session.(period:3s)")
        RESULT.InsertComment("Expected: Test on Physical Request ID")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 4: Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")
        RESULT.InsertComment("Expected: ID 730:: 08 02 10 03 FF FF FF FF FF ID 738:: 08 06 50 03 00 32 13 88 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")

        RESULT.InsertComment("Step 5: Send disable control DTC settings (SID $85,SF $02)")
        RESULT.InsertComment("Expected: 738: 08 02 C5 02 00 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Send disable control DTC settings (SID $85,SF $02)")

        RESULT.InsertComment("Step 6: Create PASSENGER_AIRBAG_SQUIB Open fault")
        RESULT.InsertComment("Expected: DTC_LOP_PASSENGER_AIRBAG_SQUIB_OPEN Fault will not be Active/Suppressed 730: 08 06 19 06 80 10 13 ff 00 738: 08 07 59 06 80 10 13 40")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_80_10_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_06_80_10_13_40)

        RESULT.InsertComment("Step 7: Send enable control DTC settings (SID $85,SF $01) in same Ign cycle")
        RESULT.InsertComment("Expected: 738: 08 02 C5 01 00 00 00 00 00")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 8: Verify the fault")
        RESULT.InsertComment("Expected: DTC_LOP_PASSENGER_AIRBAG_SQUIB_OPEN will be active 730: 08 06 19 06 80 10 13 ff 00 738: 08 07 59 06 80 10 13 8B 01 01 02 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_80_10_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:7]), UDS_RESP_59_06_80_10_13_8B_01)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
