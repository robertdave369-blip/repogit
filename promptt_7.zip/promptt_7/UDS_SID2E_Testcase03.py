# Author: Christy, Krishna
# Test Case : SID2E_Testcase03
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : Validation of DID($ F190) - VIN-VEHICLE IDENTIFICATION NUMBER
# Verifies  : ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:33696867

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_2E_01_01_19_00_00_02_00_14_00_04_00__c9c75d,
    UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_62_F1_90,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase03"
    tc_desc = "Validation of DID($ F190) - VIN-VEHICLE IDENTIFICATION NUMBER"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase03")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:33696867")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        # --- Write project-default Variant Code / EOL baseline ---
        manage_variant_code("DEFAULT", project="M310_M314_M110")

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 3: Enable VCU NODE in variant code")
        RESULT.LogAction("MANUAL / precondition step", "Enable VCU NODE in variant code")

        RESULT.InsertComment("Step 4: Send WriteDatabyIdentifier request(SID: $2E DID:$01 01)")
        RESULT.InsertComment("Expected: 730: 2E 01 01 19 00 00 02 00 14 00 04 00 00 00 04 01 00 00 00 00 00 00 00 738: 62 F1 90 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_01_19_00_00_02_00_14_00_04_00__c9c75d)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_90)

        RESULT.InsertComment("Step 5: Toggle IGN and verify active fault")
        RESULT.InsertComment("Expected: DTC_VIN_MIS_MATCH_ERROR, Active 8B DTC CODE: D3 06 00")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 6: Send WriteDatabyIdentifier request(SID: $2E DID:$F190) with Level 1 security")
        RESULT.InsertComment("Expected: 730: 2E F1 90 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 738: 62 F1 90 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_62_F1_90)

        RESULT.InsertComment("Step 7: Toggle IGN and verify active fault")
        RESULT.InsertComment("Expected: DTC_VIN_MIS_MATCH_ERROR, Historic 08 DTC CODE: D3 06 00 08")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        RESULT.InsertComment("Teardown: restore project-default Variant Code / EOL")
        manage_variant_code("DEFAULT", project="M310_M314_M110")
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
