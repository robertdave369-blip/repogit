# Author: Christy, Krishna
# Test Case : SID19 06_Testcase07
# Folder    : Extended Snapshot Data Record ($19_06)
# Service   : 0x19 ReadDTCInformation
# Intention : Test in Default Session to verify Frequency Counter and Operational Cycle Counter Behavior Under VBAT Low Fault Condition
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_SESSION_DEFAULT,
    UDS_RESP_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 06_Testcase07"
    tc_desc = "Test in Default Session to verify Frequency Counter and Operational Cycle Counter Behavior Under VBAT Low Fault Condition"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_06_Testcase07")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Test on under voltage")
        RESULT.LogAction("MANUAL / precondition step", "Test on under voltage")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Send to default session.(SID $10, SF $01).")
        RESULT.InsertComment("Expected: 730: 02 10 01 00 00 00 00 00 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 5: Set voltage is 7V and verify the fault")
        RESULT.InsertComment("Expected: DTC_BATTERY_VOLTAGE_LOW , Active 8B DTC CODE: 94 2A 16 8B")
        RESULT.LogAction("MANUAL / precondition step", "Set voltage is 7V and verify the fault")

        RESULT.InsertComment("Step 6: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 7: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x8B 0x01 0x01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 8: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 9: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x8B 0x02 0x00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 11: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x8B 0x01 0x01 0x02 0x00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 12: Set voltage back to Normal")
        RESULT.InsertComment("Expected: DTC_BATTERY_VOLTAGE_LOW , Healed 0A DTC CODE: 94 2A 17 0A")
        RESULT.LogAction("MANUAL / precondition step", "Set voltage back to Normal")

        RESULT.InsertComment("Step 13: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 14: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x0A 0x01 0x01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 15: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 16: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x0A 0x02 0x00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 17: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 18: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x0A 0x01 0x01 0x02 0x00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 19: Toggle IGN and verify the fault")
        RESULT.InsertComment("Expected: DTC_BATTERY_VOLTAGE_LOW , Historic 08 DTC CODE: 94 2A 17 08")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 20: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 21: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x08 0x01 0x01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 22: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 23: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x08 0x02 0x01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 24: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 94 2A 16 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 25: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 0x59 0x06 0x94 0x2A 0x16 0x08 0x01 0x01 0x02 0x01")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
