# Author: Christy, Krishna
# Test Case : SID11_Testcase26
# Folder    : ECU Reset Service (SID $11)
# Service   : 0x11 ECUReset
# Intention : To Verify Functional addressing mode (7DF) not supported in Extended Session.
# Verifies  : ISSUE:33629760

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_11_01,
    UDS_REQ_11_03,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03_00_32_13_88,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID11_Testcase26"
    tc_desc = "To Verify Functional addressing mode (7DF) not supported in Extended Session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID11_Testcase26")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x11 ECUReset")
        RESULT.InsertComment("Requirements verified: ISSUE:33629760")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Verify 2C0 message and confirm communication")
        RESULT.InsertComment("Expected: 2C0 msg present")
        RESULT.InsertComment("Bus communication confirmed by read_software_version() above.")

        RESULT.InsertComment("Step 4: Send Request for extended Session 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 13 88 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 5: Send Request for Security Seed 730: 02 27 01")
        RESULT.InsertComment("Expected: 738: 06 67 01 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 6: Send Request for Security Key 730: 27 02 yy yy yy yy")
        sec_status = Internal_Security_Access(0x01)
        RESULT.InterpretEqualResult("Security Access level seed 0x01 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Send ECU reset request (Hard reset) 7DF: 02 11 01")
        RESULT.InsertComment("Expected: 738: Response Timeout")
        response = CAN.SendDiagByValues(UDS_REQ_11_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 8: Send ECU reset request (Soft reset) 7DF: 02 11 03")
        RESULT.InsertComment("Expected: 738: Response Timeout")
        response = CAN.SendDiagByValues(UDS_REQ_11_03)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
