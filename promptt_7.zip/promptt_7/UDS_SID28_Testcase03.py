# Author: Christy, Krishna
# Test Case : SID28_Testcase03
# Folder    : Communication Control(SID $28)
# Service   : 0x28 CommunicationControl
# Intention : Test on Physical Request ID ($730) with SID $28 SF $02 on extended session.
# Verifies  : ISSUE:32591236, ISSUE:33634562, ISSUE:33623645, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33667151

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_28_02_01,
    UDS_REQ_28_02_02,
    UDS_REQ_28_02_03,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_68_02,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID28_Testcase03"
    tc_desc = "Test on Physical Request ID ($730) with SID $28 SF $02 on extended session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID28_Testcase03")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x28 CommunicationControl")
        RESULT.InsertComment("Requirements verified: ISSUE:32591236, ISSUE:33634562, ISSUE:33623645, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33667151")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 3: Send in extended session.(SID $28, SF $02).")
        RESULT.InsertComment("Expected: 730: 03 28 02 01 00 00 00 00 738: 02 68 02 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_02_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:2]), UDS_RESP_68_02)

        RESULT.InsertComment("Step 4: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Send in extended session.(SID $28, SF $02).")
        RESULT.InsertComment("Expected: 730: 03 28 02 02 00 00 00 00 738: 02 68 02 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_02_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:2]), UDS_RESP_68_02)

        RESULT.InsertComment("Step 6: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 7: Send in extended session.(SID $28, SF $02).")
        RESULT.InsertComment("Expected: 730: 03 28 02 03 00 00 00 00 738: 02 68 02 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_02_03)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:2]), UDS_RESP_68_02)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
