# Author: Christy, Krishna
# Test Case : SID19 06_Testcase20
# Folder    : Extended Snapshot Data Record ($19_06)
# Service   : 0x19 ReadDTCInformation
# Intention : Test in Default Session to verify Frequency Counter and Operational Cycle Counter Behavior for CAN Fault under CAN wakeup Condition
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_SESSION_DEFAULT,
    UDS_RESP_SESSION_DEFAULT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 06_Testcase20"
    tc_desc = "Test in Default Session to verify Frequency Counter and Operational Cycle Counter Behavior for CAN Fault under CAN wakeup Condition"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_06_Testcase20")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send to default session.(SID $10, SF $01).")
        RESULT.InsertComment("Expected: 730: 02 10 01 00 00 00 00 00 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Create IEB node absent & make Historic")
        RESULT.LogAction("MANUAL / precondition step", "Create IEB node absent & make Historic")

        RESULT.InsertComment("Step 5: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 D1 03 00 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 6: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 06 D1 03 00 01 01 02 01 (first time)")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 7: Perform IGN OFF")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 8: Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")
        RESULT.InsertComment("DBC names referenced: ACTIVE_WAKEUP_BIT")
        RESULT.LogAction("MANUAL / precondition step", "Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 D1 03 00 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 10: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 06 D1 03 00 01 02 02 02 (Second Time)")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 11: Create IEB node absent & make Historic")
        RESULT.LogAction("MANUAL / precondition step", "Create IEB node absent & make Historic")

        RESULT.InsertComment("Step 12: Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")
        RESULT.InsertComment("DBC names referenced: ACTIVE_WAKEUP_BIT")
        RESULT.LogAction("MANUAL / precondition step", "Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")

        RESULT.InsertComment("Step 13: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 D1 03 00 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 14: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 06 D1 03 00 01 03 02 03(Third time)")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 15: Create IEB node absent & make Historic")
        RESULT.LogAction("MANUAL / precondition step", "Create IEB node absent & make Historic")

        RESULT.InsertComment("Step 16: Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")
        RESULT.InsertComment("DBC names referenced: ACTIVE_WAKEUP_BIT")
        RESULT.LogAction("MANUAL / precondition step", "Set ACTIVE_WAKEUP_BIT=0 & wake up same with ACTIVE_WAKEUP_BIT=1")

        RESULT.InsertComment("Step 17: Send ReadDTCInformation command($19, SF $06) request")
        RESULT.InsertComment("Expected: 19 06 D1 03 00 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $06) request")

        RESULT.InsertComment("Step 18: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 06 D1 03 00 01 04 02 04 (Fourth time)")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
