# Author: Christy, Krishna
# Test Case : SID85_Testcase13
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : To verify DTC records with SPR SFs 81 and 82 on Physical mode in Extended session - LOOP
# Verifies  : ISSUE:32591246, ISSUE:33692214

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_NO_RESPONSE,
    UDS_REQ_19_06_80_01_13_FF,
    UDS_REQ_19_06_92_36_13_FF,
    UDS_REQ_85_81,
    UDS_REQ_85_82,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_59_06_80_01_13,
    UDS_RESP_59_06_92_36_13,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase13"
    tc_desc = "To verify DTC records with SPR SFs 81 and 82 on Physical mode in Extended session - LOOP"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase13")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:32591246, ISSUE:33692214")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send 3E to keep current session.(period:3s)")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Send in extend session.(SID $85, SF $81).")
        RESULT.InsertComment("Expected: 730: 08 02 85 81 00 00 00 00 00 No response")
        response = CAN.SendDiagByValues(UDS_REQ_85_81)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("ControlDTCSetting expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

        RESULT.InsertComment("Step 4: DRIVER AIRBAG OPEN, Read DTC information.(SID $19, SF $06).")
        RESULT.InsertComment("Expected: DRIVER AIRBAG OPEN Fault will be Active 730: 08 06 19 06 80 01 13 ff 00 738: 08 07 59 06 80 01 13 XX 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_80_01_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:5]), UDS_RESP_59_06_80_01_13)

        RESULT.InsertComment("Step 5: Send in extend session.(SID $85, SF $82).")
        RESULT.InsertComment("Expected: 730: 08 02 85 82 00 00 00 00 00 No response")
        response = CAN.SendDiagByValues(UDS_REQ_85_82)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("ControlDTCSetting expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

        RESULT.InsertComment("Step 6: Set Passenger_A piller_SRSU_Open then read DTC status after 3s.(SID $19, SF $06).")
        RESULT.InsertComment("Expected: Passenger_A piller_SRSU_Open Fault is not logged 730: 08 06 19 06 92 36 13 ff 00 738: 08 07 59 06 92 36 13 XX 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_36_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:5]), UDS_RESP_59_06_92_36_13)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
