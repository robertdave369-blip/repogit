# Author: Christy, Krishna
# Test Case : SID85_Testcase35
# Folder    : Control DTC Setting Service(SID $85)
# Service   : 0x85 ControlDTCSetting
# Intention : To verify DTC records with SF 02 followed by SF 01 on Functional mode in Extended session.
# Verifies  : ISSUE:33623645, ISSUE:33692205, ISSUE:33692206

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_06_80_72_13_FF,
    UDS_REQ_19_06_90_32_12_FF,
    UDS_REQ_85_01,
    UDS_REQ_85_02,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_59_06_80_72_13,
    UDS_RESP_59_06_90_32_12_40,
    UDS_RESP_C5_01,
    UDS_RESP_C5_02,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID85_Testcase35"
    tc_desc = "To verify DTC records with SF 02 followed by SF 01 on Functional mode in Extended session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID85_Testcase35")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x85 ControlDTCSetting")
        RESULT.InsertComment("Requirements verified: ISSUE:33623645, ISSUE:33692205, ISSUE:33692206")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Expected: Test on Functional Request ID")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Send 3E to keep current session.(period:3s)")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 3: Send in extend session. (SID $85, SF $02).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 02 00 00 00 00 00 738: 08 02 C5 02 AA AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:2]), UDS_RESP_C5_02)

        RESULT.InsertComment("Step 4: Create PASSENGER SEAT BELT LEAK TO PLUS fault")
        RESULT.InsertComment("Expected: DTC_DCS_PASSENGER_SEAT_BELT_LEAK_TO_PLUS Fault will not be Active/Suppressed 730: 08 06 19 06 90 32 12 ff 00 738: 08 07 59 06 90 32 12 40")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_90_32_12_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:6]), UDS_RESP_59_06_90_32_12_40)

        RESULT.InsertComment("Step 5: Send in extend session. (SID $85, SF $01).")
        RESULT.InsertComment("Expected: 7DF: 08 02 85 01 00 00 00 00 00 738: 08 02 C5 01 AA AA AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_85_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ControlDTCSetting response", " ".join(response_tokens[:2]), UDS_RESP_C5_01)

        RESULT.InsertComment("Step 6: Set LEFT PRETENSIONER OPEN fault then read DTC after 3s(SID $19, SF $06).")
        RESULT.InsertComment("Expected: 730: 08 06 19 06 80 72 13 ff 00 738: 08 07 59 06 80 72 13 XX 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_80_72_13_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:5]), UDS_RESP_59_06_80_72_13)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
