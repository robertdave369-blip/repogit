# Author: Christy, Krishna
# Test Case : SID19_Testcase01
# Folder    : Read DTC Information Service (SID $19)
# Service   : 0x19 ReadDTCInformation
# Intention : Test on Physical Request ID ($730) on default and extended session with (SID$19 SF$01) request.
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697870, ISSUE:33697881, ISSUE:34699404, ISSUE:34699406

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_01_CB,
    UDS_REQ_SESSION_DEFAULT,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_59_01_CB,
    UDS_RESP_SESSION_DEFAULT,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19_Testcase01"
    tc_desc = "Test on Physical Request ID ($730) on default and extended session with (SID$19 SF$01) request."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_Testcase01")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697870, ISSUE:33697881, ISSUE:34699404, ISSUE:34699406")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send to extended session.(SID $10, SF $01).")
        RESULT.InsertComment("Expected: 730: 02 10 01 00 00 00 00 00 738: 06 50 01 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_DEFAULT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_DEFAULT)

        RESULT.InsertComment("Step 4: Send Report Number of DTC By Status Mask command($19, SF $01) request")
        RESULT.InsertComment("Expected: 730: 03 19 01 CB 00 00 00 00 738: 07 59 01 CB XX XX XX 00 XX=reportNumberOfDTCByStatusMask")
        response = CAN.SendDiagByValues(UDS_REQ_19_01_CB)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_59_01_CB)

        RESULT.InsertComment("Step 5: Send 3E to keep current session.(period:4s)")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 6: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 7: Send Report Number of DTC By Status Mask command($19, SF $01) request")
        RESULT.InsertComment("Expected: 730: 03 19 01 CB 00 00 00 00 738: 07 59 01 CB XX XX XX 00 XX=reportNumberOfDTCByStatusMask")
        response = CAN.SendDiagByValues(UDS_REQ_19_01_CB)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_59_01_CB)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
