# Author: Christy, Krishna
# Test Case : SID2E_Testcase18
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify NRC31 for the not supported DIDs in $2E.
# Verifies  : ISSUE:33696867, ISSUE:34898235

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_2E_02_00_02,
    UDS_REQ_2E_02_01_02,
    UDS_REQ_2E_04_46_02,
    UDS_REQ_2E_F1_80_02,
    UDS_REQ_2E_F1_81,
    UDS_REQ_2E_F1_82_02,
    UDS_REQ_2E_F1_86_02,
    UDS_REQ_2E_F1_87_02,
    UDS_REQ_2E_F1_8A_02,
    UDS_REQ_2E_F1_8B_02,
    UDS_REQ_2E_F1_8C_02,
    UDS_REQ_2E_F1_91_02,
    UDS_REQ_2E_F1_B7_02,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase18"
    tc_desc = "To verify NRC31 for the not supported DIDs in $2E."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase18")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696867, ISSUE:34898235")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request (SID: $2E DID: $F181)")
        RESULT.InsertComment("Expected: ID 730: 2E F1 81.... (15 bytes of xx) xx is the ASW 738: NRC31")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_81)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 3: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request (SID: $2E DID: $0446)")
        RESULT.InsertComment("Expected: ID 730: 2E 04 46 02// 738: NRC31")
        response = CAN.SendDiagByValues(UDS_REQ_2E_04_46_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 4: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F180) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 80 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_80_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 5: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 6: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request (SID: $2E DID: $F191) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 91 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_91_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 7: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 8: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F182) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 82 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_82_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 9: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738: 03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 10: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F18A) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 8A 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_8A_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 11: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 12: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F18B) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 8B 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_8B_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 13: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 14: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request (SID: $2E DID: $F18C) to set 0X02")
        RESULT.InsertComment("Expected: 730:04 2E F1 8C 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_8C_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 15: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 16: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F191) to set 0X02")
        RESULT.InsertComment("Expected: 730:04 2E F1 91 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_91_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 17: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 18: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F186) to set 0X02")
        RESULT.InsertComment("Expected: 730:04 2E F1 86 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_86_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 19: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 20: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$0200) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E 02 00 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_02_00_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 21: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 22: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$0201) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E 02 01 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_02_01_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 23: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738: 03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 24: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F1B7) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 B7 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_B7_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 25: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738: 03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

        RESULT.InsertComment("Step 26: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request(SID: $2E DID:$F187) to set 0X02")
        RESULT.InsertComment("Expected: 730: 04 2E F1 87 02 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_87_02)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 27: Verify ACU sends out the Negative response.")
        RESULT.InsertComment("Expected: 738:03 7F 22 31 00 00 00 00")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the Negative response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
