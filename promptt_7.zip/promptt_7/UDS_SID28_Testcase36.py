# Author: Christy, Krishna
# Test Case : SID28_Testcase36
# Folder    : Communication Control(SID $28)
# Service   : 0x28 CommunicationControl
# Intention : In BSW, Send SID $28 SF $83 in physical request ID ($730) on extended session.
# Verifies  : ISSUE:32591247, ISSUE:33634562, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33666982

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_NO_RESPONSE,
    UDS_REQ_28_83_01,
    UDS_REQ_28_83_02,
    UDS_REQ_28_83_03,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID28_Testcase36"
    tc_desc = "In BSW, Send SID $28 SF $83 in physical request ID ($730) on extended session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID28_Testcase36")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x28 CommunicationControl")
        RESULT.InsertComment("Requirements verified: ISSUE:32591247, ISSUE:33634562, ISSUE:33634567, ISSUE:33634612, ISSUE:33666969, ISSUE:33666972, ISSUE:33666976, ISSUE:33666982")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: In Boot Mode")
        RESULT.LogAction("MANUAL / precondition step", "In Boot Mode")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Send in extended session.(SID $28, SF $83).")
        RESULT.InsertComment("Expected: 730: 08 03 28 83 01 00 00 00 00 738: No response")
        response = CAN.SendDiagByValues(UDS_REQ_28_83_01)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("CommunicationControl expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

        RESULT.InsertComment("Step 5: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 6: Send in extended session.(SID $28, SF $83).")
        RESULT.InsertComment("Expected: 730: 08 03 28 83 02 00 00 00 00 738: No response")
        response = CAN.SendDiagByValues(UDS_REQ_28_83_02)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("CommunicationControl expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

        RESULT.InsertComment("Step 7: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 08 02 10 03 00 00 00 00 00 738: 08 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 8: Send in extended session.(SID $28, SF $83).")
        RESULT.InsertComment("Expected: 730: 08 03 28 83 03 00 00 00 00 738: No response")
        response = CAN.SendDiagByValues(UDS_REQ_28_83_03)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("CommunicationControl expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
