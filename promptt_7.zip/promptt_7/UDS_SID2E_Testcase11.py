# Author: Christy, Krishna
# Test Case : SID2E_Testcase11
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify NRC88 and validate DID($F198) - TESTER SERIAL NUMBER with vehicle speed is greater than 5 kmph.
# Verifies  : ISSUE:33696864, ISSUE:33696865, ISSUE:33696866

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_27_61,
    UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03,
    UDS_RESP_67_61,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase11"
    tc_desc = "To verify NRC88 and validate DID($F198) - TESTER SERIAL NUMBER with vehicle speed is greater than 5 kmph."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase11")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696864, ISSUE:33696865, ISSUE:33696866")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Verify Write DID F198 With Vehicle Speed set to Greater than 5")
        RESULT.LogAction("MANUAL / precondition step", "Verify Write DID F198 With Vehicle Speed set to Greater than 5")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Set Vehicle speed to 200(Refer Message and signal as per variant).")
        RESULT.LogAction("MANUAL / precondition step", "Set Vehicle speed to 200(Refer Message and signal as per variant).")

        RESULT.InsertComment("Step 4: Send Extended Session Request")
        RESULT.InsertComment("Expected: ID 730: 02 10 03 00 00 00 00 00 ID 738: 02 50 03 00 32 01 F4 AA")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:2]), UDS_RESP_50_03)

        RESULT.InsertComment("Step 5: Unlock Security Level 1")
        RESULT.InsertComment("Expected: ID 730: 02 27 61 00 00 00 00 00 ID 738: 06 67 61 XX XX XX XX 00 ID 730: 06 27 62 YY YY YY YY 00 ID 738: 02 67 62 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_27_61)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate SecurityAccess response", " ".join(response_tokens[:2]), UDS_RESP_67_61)

        RESULT.InsertComment("Step 6: Send WriteDatabyIdentifier request(SID: $2E DID:$F1 98)")
        RESULT.InsertComment("Expected: 730: 00 13 2E F1 98 AA AA AA AA AA AA 20 20 20 20 20 20 20 20 20 20")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 7: Verify Negative Response")
        RESULT.InsertComment("Expected: 738: 7F 2E 88 AA AA AA AA")
        RESULT.LogAction("MANUAL / precondition step", "Verify Negative Response")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
