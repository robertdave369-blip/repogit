# Author: Christy, Krishna
# Test Case : SID14_Testcase05
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : 1.Test on Physical Request ID ($730) with SID $14 with DCS faults
# Verifies  : ISSUE:32591241, ISSUE:33697042, ISSUE:33697043, ISSUE:33697044, ISSUE:33697454, ISSUE:33697475

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_CLEAR_ALL_DTC,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_54,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase05"
    tc_desc = "1.Test on Physical Request ID ($730) with SID $14 with DCS faults"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase05")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:32591241, ISSUE:33697042, ISSUE:33697043, ISSUE:33697044, ISSUE:33697454, ISSUE:33697475")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send DiagnosticSessionControl command to request Extended diagnostic session. (SID $10, SF $03).")
        RESULT.InsertComment("Expected: ID 730: 02 10 03 00 00 00 00 00 ID 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 01 54 FF FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 5: Create S2B fault for DCS 0.")
        RESULT.InsertComment("Expected: Verify open fault for DCS 0 fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create S2B fault for DCS 0.")

        RESULT.InsertComment("Step 6: Create s2B fault for DCS 1. (Driver Seat)")
        RESULT.InsertComment("Expected: Verify open fault for DCS 1 fault is detected. (DTC: 903312)")
        RESULT.LogAction("MANUAL / precondition step", "Create s2B fault for DCS 1. (Driver Seat)")

        RESULT.InsertComment("Step 7: Create s2B fault for DCS 2.")
        RESULT.InsertComment("Expected: Verify open fault for DCS 2 fault is detected. (DTC: 903212)")
        RESULT.LogAction("MANUAL / precondition step", "Create s2B fault for DCS 2.")

        RESULT.InsertComment("Step 8: Create s2B fault for DCS 3.")
        RESULT.InsertComment("Expected: Verify open fault for DCS 3 fault is detected. (DTC: 924312)")
        RESULT.LogAction("MANUAL / precondition step", "Create s2B fault for DCS 3.")

        RESULT.InsertComment("Step 9: Create s2B fault for DCS 4.")
        RESULT.InsertComment("Expected: Verify open fault for DCS 4 fault is detected. (DTC: 924412)")
        RESULT.LogAction("MANUAL / precondition step", "Create s2B fault for DCS 4.")

        RESULT.InsertComment("Step 10: Create s2B fault for DCS 5.")
        RESULT.InsertComment("Expected: Verify open fault for DCS 5 fault is detected. (DTC: 924212)")
        RESULT.LogAction("MANUAL / precondition step", "Create s2B fault for DCS 5.")

        RESULT.InsertComment("Step 11: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 08 04 14 FF FF FF 00 00 00 ID 738: 08 01 54 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 12: Wait for qualify time,verif DTC is detected")
        RESULT.LogAction("MANUAL / precondition step", "Wait for qualify time,verif DTC is detected")

        RESULT.InsertComment("Step 13: Set DCS 0,1,2,3,4,5 to Normal")
        RESULT.InsertComment("Expected: DCS 0, DCS1,DCS2, DCS3, DCS4,DCS5 fault is historic")
        RESULT.LogAction("MANUAL / precondition step", "Set DCS 0,1,2,3,4,5 to Normal")

        RESULT.InsertComment("Step 14: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 01 54 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
