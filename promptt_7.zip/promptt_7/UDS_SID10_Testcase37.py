# Author: Christy, Krishna
# Test Case : SID10_Testcase37
# Folder    : Diagnostics Session Control service (SID $10)
# Service   : 0x10 DiagnosticSessionControl
# Intention : To Verify Positive Response for Extended Session in Boot Mode (730 and 7DF).
# Verifies  : ISSUE:33623871, ISSUE:33629749

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22,
    UDS_REQ_22_02_00,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_62_02_00_01,
    UDS_RESP_ACTIVE_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID10_Testcase37"
    tc_desc = "To Verify Positive Response for Extended Session in Boot Mode (730 and 7DF)."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID10_Testcase37")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x10 DiagnosticSessionControl")
        RESULT.InsertComment("Requirements verified: ISSUE:33623871, ISSUE:33629749")
        RESULT.InsertComment("Pre-Action: Precondition: ECU should be in Application")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Enter in Boot Mode.")
        RESULT.LogAction("MANUAL / precondition step", "Enter in Boot Mode.")

        RESULT.InsertComment("Step 3: Read 22 02 00 to confirm BSW ID 730: 08 03 22 02 00 00 00 00 00")
        RESULT.InsertComment("Expected: ID 738: 08 04 62 02 00 01 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_02_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_62_02_00_01)

        RESULT.InsertComment("Step 4: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 5: Send Extended Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 6: Within 5Sec Send Read Active Diagnostic Session 730: 22 F186")
        RESULT.InsertComment("Expected: 738: 04 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_EXTENDED)

        RESULT.InsertComment("Step 7: Send Extended Request 7DF: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 8: Within 5Sec Send Read Active Diagnostic Session 730: 22 F186")
        RESULT.InsertComment("Expected: 738: 04 62 F1 86 03 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_EXTENDED)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
