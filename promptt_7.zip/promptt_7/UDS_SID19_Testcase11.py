# Author: Christy, Krishna
# Test Case : SID19_Testcase11
# Folder    : Read DTC Information Service (SID $19)
# Service   : 0x19 ReadDTCInformation
# Intention : To verify NRC_11 on Physical Request ID ($730) on programming session.
# Verifies  : ISSUE:33697817, ISSUE:33697818

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_01_FF,
    UDS_REQ_19_0A_FF,
    UDS_REQ_SESSION_EXTENDED,
    UDS_REQ_SESSION_PROGRAMMING,
    UDS_RESP_7F_19_11,
    UDS_RESP_SESSION_EXTENDED,
    UDS_RESP_SESSION_PROGRAMMING,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19_Testcase11"
    tc_desc = "To verify NRC_11 on Physical Request ID ($730) on programming session."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_Testcase11")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697817, ISSUE:33697818")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Enter extended session, & Level 3 security unlocked Send programming session request.(SID $10, SF $02).")
        RESULT.InsertComment("Expected: 730: 08 02 10 02 00 00 00 00 00 738: 08 06 50 02 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_PROGRAMMING)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_PROGRAMMING)

        RESULT.InsertComment("Step 5: Send in extended session.(SID $19, SF $06).")
        RESULT.InsertComment("Expected: 730: 03 19 06 XX XX XX FF 00 738: 03 7F 19 11 00 00 00 00")
        RESULT.LogAction("MANUAL: request contains run-time value(s)", "19 06 xx")

        RESULT.InsertComment("Step 6: Send in extended session.(SID $19, SF $01).")
        RESULT.InsertComment("Expected: 730: 03 19 01 FF 00 00 00 00 738: 03 7F 19 11 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_01_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_19_11)

        RESULT.InsertComment("Step 7: Send in extended session.(SID $19, SF $0A).")
        RESULT.InsertComment("Expected: 730: 03 19 0A FF 00 00 00 00 738: 03 7F 19 11 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_0A_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:3]), UDS_RESP_7F_19_11)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
