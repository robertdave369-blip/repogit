# Author: Christy, Krishna
# Test Case : SID14_Testcase30
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : To Verify NRC88 for Vehicle Speed Too High for Functional Id
# Verifies  : ISSUE:33697045, ISSUE:33697595

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_TESTER_PRESENT,
    UDS_RESP_TESTER_PRESENT,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase30"
    tc_desc = "To Verify NRC88 for Vehicle Speed Too High for Functional Id"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase30")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697045, ISSUE:33697595")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")
        RESULT.LogAction("MANUAL / precondition step", "To check Vehicle Speed Too High($88) on changing the vehicle speed value more than Threshold DID")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify No faults")
        RESULT.InsertComment("Expected: No faults")
        RESULT.LogAction("MANUAL / precondition step", "Verify No faults")

        RESULT.InsertComment("Step 4: Send 3E to keep current session.(period:3s)")
        response = CAN.SendDiagByValues(UDS_REQ_TESTER_PRESENT)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate TesterPresent response", " ".join(response_tokens[:2]), UDS_RESP_TESTER_PRESENT)

        RESULT.InsertComment("Step 5: Set Vechicle speed > Threshold DID value")
        RESULT.LogAction("MANUAL / precondition step", "Set Vechicle speed > Threshold DID value")

        RESULT.InsertComment("Step 6: Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")
        RESULT.InsertComment("Expected: ID 7DF:: 02 10 03 FF FF FF FF FF ID 738:: 06 50 03 00 32 13 88 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send DiagnosticSessionControl command to request extended diagnostic session(SID: $10, SF $03) .")

        RESULT.InsertComment("Step 7: Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX")
        RESULT.InsertComment("DBC names referenced: IEB1_FD_10")
        RESULT.LogAction("MANUAL / precondition step", "Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX")

        RESULT.InsertComment("Step 8: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: 7DF:03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL: request contains run-time value(s)", "85 88 xx xx xx xx")

        RESULT.InsertComment("Step 9: Send DiagnosticSessionControl command to request Default diagnostic session(SID: $10, SF $01) .")
        RESULT.InsertComment("Expected: ID 730:: 02 10 01 FF FF FF FF FF ID 738:: 06 50 01 00 32 13 88 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send DiagnosticSessionControl command to request Default diagnostic session(SID: $10, SF $01) .")

        RESULT.InsertComment("Step 10: Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX")
        RESULT.InsertComment("DBC names referenced: IEB1_FD_10")
        RESULT.LogAction("MANUAL / precondition step", "Send Vechicle speed > Threshold DID value. Set Vechicle Speed IEB1_FD_10 =XX")

        RESULT.InsertComment("Step 11: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: 738: 03 7F 85 88 xx xx xx xx")
        RESULT.LogAction("MANUAL / precondition step", "Send ClearDiagnosticInformation request(SID: $14)")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
