# Author: Christy, Krishna
# Test Case : SID19 06_Testcase22
# Folder    : Extended Snapshot Data Record ($19_06)
# Service   : 0x19 ReadDTCInformation
# Intention : Validate the frequency counter and operational cycle counter behavior in the Default Session for active and historic DTC state.
# Verifies  : ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_19_06_92_0B_11_01,
    UDS_REQ_19_06_92_0B_11_02,
    UDS_REQ_19_06_92_0B_11_FF,
    UDS_RESP_59_06_92_0B_11_08_01_01,
    UDS_RESP_59_06_92_0B_11_8B_01_01,
    UDS_RESP_59_06_92_0B_11_8B_02,
    UDS_RESP_59_06_92_0B_11_8B_02_01,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 06_Testcase22"
    tc_desc = "Validate the frequency counter and operational cycle counter behavior in the Default Session for active and historic DTC state."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_06_Testcase22")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697814, ISSUE:33697815, ISSUE:33697816, ISSUE:33697879, ISSUE:33698142, ISSUE:34699441, ISSUE:34699442")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Set B-PILLAR RIGHT SRSU SHORT TO GROUND Fault Wait until DTC gets qualified Verify B-PILLAR RIGHT SRSU SHORT TO GROUND is detected.")
        RESULT.InsertComment("Expected: B-PILLAR RIGHT SRSU SHORT TO GROUND, active")
        RESULT.LogAction("MANUAL / precondition step", "Set B-PILLAR RIGHT SRSU SHORT TO GROUND Fault Wait until DTC gets qualified Verify B-PILLAR RIGHT SRSU SHORT TO GROUND is detected.")

        RESULT.InsertComment("Step 4: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11 730: 19 06 92 0B 11 01")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 8B 01 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_06_92_0B_11_8B_01_01)

        RESULT.InsertComment("Step 5: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11// // 730: 19 06 92 0B 11 02")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 8B 02 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:7]), UDS_RESP_59_06_92_0B_11_8B_02)

        RESULT.InsertComment("Step 6: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11// // 730: 19 06 92 0B 11 FF")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 08 01 01 02 00")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_06_92_0B_11_08_01_01)

        RESULT.InsertComment("Step 7: Set RCU DTC back to Inherent and wait until faults gets de-qualify Verify B-PILLAR RIGHT SRSU SHORT TO GROUND fault become historic.")
        RESULT.InsertComment("Expected: B-PILLAR RIGHT SRSU SHORT TO GROUND, historic")
        RESULT.LogAction("MANUAL / precondition step", "Set RCU DTC back to Inherent and wait until faults gets de-qualify Verify B-PILLAR RIGHT SRSU SHORT TO GROUND fault become historic.")

        RESULT.InsertComment("Step 8: Perform toggle IGN")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11// // 730: 19 06 92 0B 11 01")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 8B 01 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_06_92_0B_11_8B_01_01)

        RESULT.InsertComment("Step 10: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11// // 730: 19 06 92 0B 11 02")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 8B 02 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_06_92_0B_11_8B_02_01)

        RESULT.InsertComment("Step 11: Send ReadDTCInformation command ($19, SF $06) to request information for DTC:92 0B 11// // 730: 19 06 92 0B 11 FF")
        RESULT.InsertComment("Expected: 738: 59 06 92 0B 11 08 01 01 02 01")
        response = CAN.SendDiagByValues(UDS_REQ_19_06_92_0B_11_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDTCInformation response", " ".join(response_tokens[:8]), UDS_RESP_59_06_92_0B_11_08_01_01)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
