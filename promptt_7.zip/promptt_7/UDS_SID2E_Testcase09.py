# Author: Christy, Krishna
# Test Case : SID2E_Testcase09
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : Validation of DID($F100) - Mode Configuration

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_F1_00,
    UDS_REQ_2E_F1_00_01,
    UDS_REQ_2E_F1_00_02,
    UDS_REQ_2E_F1_00_03,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_62_F1_00_01,
    UDS_RESP_62_F1_00_02,
    UDS_RESP_62_F1_00_03,
    UDS_RESP_6E_F1_00,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase09"
    tc_desc = "Validation of DID($F100) - Mode Configuration"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase09")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Verify test bench is fault free and in normal condition")
        RESULT.LogAction("MANUAL / precondition step", "Verify test bench is fault free and in normal condition")

        RESULT.InsertComment("Step 2: Send Extended session Request 730: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 3: Clear level1 security")
        RESULT.LogAction("MANUAL / precondition step", "Clear level1 security")

        RESULT.InsertComment("Step 4: Write 730:04 2E F1 00 01 00 00 00")
        RESULT.InsertComment("Expected: 738: 03 6E F1 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_00_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_F1_00)

        RESULT.InsertComment("Step 5: Read 730:03 22 F1 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 04 62 F1 00 01")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_62_F1_00_01)

        RESULT.InsertComment("Step 6: Write 730:04 2E F1 00 02 00 00 00")
        RESULT.InsertComment("Expected: 738: 03 6E F1 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_00_02)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_F1_00)

        RESULT.InsertComment("Step 7: Read 730:03 22 F1 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 04 62 F1 00 02")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_62_F1_00_02)

        RESULT.InsertComment("Step 8: Write 730:04 2E F1 00 03 00 00 00")
        RESULT.InsertComment("Expected: 738: 03 6E F1 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_00_03)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_F1_00)

        RESULT.InsertComment("Step 9: Read 730:03 22 F1 00 00 00 00 00")
        RESULT.InsertComment("Expected: 738: 04 62 F1 00 03")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_00)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_62_F1_00_03)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
