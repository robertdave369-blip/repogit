# Author: Christy, Krishna
# Test Case : SID3E_Testcase17
# Folder    : Tester Present Service (SID $3E)
# Service   : 0x3E TesterPresent
# Intention : To Verify the Suppressive Positive Response in Extended Session and Confirm keep current session in Functional Mode(7DF).
# Verifies  : ISSUE:32591394

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_NO_RESPONSE,
    UDS_REQ_3E_80,
    UDS_REQ_READ_ACTIVE_SESSION,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_ACTIVE_SESSION_EXTENDED,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID3E_Testcase17"
    tc_desc = "To Verify the Suppressive Positive Response in Extended Session and Confirm keep current session in Functional Mode(7DF)."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID3E_Testcase17")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x3E TesterPresent")
        RESULT.InsertComment("Requirements verified: ISSUE:32591394")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Cycle IG and wait for lamp check to end.")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 4: Send Extended Request 7DF: 02 10 03")
        RESULT.InsertComment("Expected: 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 5: Confirm keep in extended session.(SID $22, SF $F186).")
        RESULT.InsertComment("Expected: 730: 03 22 F1 86 00 00 00 00 738: 04 62 F1 86 03 AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_EXTENDED)

        RESULT.InsertComment("Step 6: Send SPR Request(SID $3E, SF $80).")
        RESULT.InsertComment("Expected: 7DF: 02 3E 80 00 00 00 00 00 No response")
        response = CAN.SendDiagByValues(UDS_REQ_3E_80)
        response_text = str(response).strip()
        RESULT.InterpretEqualResult("TesterPresent expect no response", (response_text or UDS_NO_RESPONSE), UDS_NO_RESPONSE)

        RESULT.InsertComment("Step 7: Read active session after 5secs from the point of tester present is enabled.")
        RESULT.InsertComment("Expected: 730: 03 22 F1 86 00 00 00 00 738: 04 62 F1 86 03 AA AA AA")
        response = CAN.SendDiagByValues(UDS_REQ_READ_ACTIVE_SESSION)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:4]), UDS_RESP_ACTIVE_SESSION_EXTENDED)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
