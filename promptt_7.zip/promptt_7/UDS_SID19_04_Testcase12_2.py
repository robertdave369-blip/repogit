# Author: Christy, Krishna
# Test Case : SID19 04_Testcase12
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : DTC Snapshot Record Number_normal conditions with CAN Wakeup
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_F1_B2,
    UDS_REQ_22_F1_B6,
    UDS_RESP_62_F1_B2_00_00,
    UDS_RESP_62_F1_B6_00_00_02_42,
    UDS_RESP_62_F1_B6_00_00_02_43_00,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase12"
    tc_desc = "DTC Snapshot Record Number_normal conditions with CAN Wakeup"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase12")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Snapshot data for Active state,Historic and healed state in normal conditions values")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set vehicle Speed as VEHICLE_SPEED_= 0 kmph")
        RESULT.InsertComment("DBC names referenced: VEHICLE_SPEED")
        RESULT.LogAction("MANUAL / precondition step", "Set vehicle Speed as VEHICLE_SPEED_= 0 kmph")

        RESULT.InsertComment("Step 5: Send ReadDatabyIdentifier request(SID: $22). (DID: F1B2)")
        RESULT.InsertComment("Expected: ID 730 :03 22 F1 B2 00 00 00 00 00 738:05 62 F1 B2 00 00 00 00 00 Default Value : 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B2)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:5]), UDS_RESP_62_F1_B2_00_00)

        RESULT.InsertComment("Step 6: Set Battery voltage as Battery_voltage= 12 V & IGN Voltage=12V")
        RESULT.LogAction("MANUAL / precondition step", "Set Battery voltage as Battery_voltage= 12 V & IGN Voltage=12V")

        RESULT.InsertComment("Step 7: Read DID $F1B6 (IGN counter)")
        RESULT.InsertComment("Expected: ID 730: 03 22 F1 B6 00 00 00 00 00 ID 738: 07 62 F1 B6 00 00 02 42 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B6)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:7]), UDS_RESP_62_F1_B6_00_00_02_42)

        RESULT.InsertComment("Step 8: Set LOOP0 Open fault")
        RESULT.InsertComment("Expected: Active, DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN DTC:807013")
        RESULT.LogAction("MANUAL / precondition step", "Set LOOP0 Open fault")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 70 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 10: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 11: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 70 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 12: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 02 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 13: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 70 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 14: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06 02 0C F1 B2 00 00 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 15: Set Driver pretensioner to healed State (0A)")
        RESULT.InsertComment("Expected: verify fault state 0A DTC:807013")
        RESULT.LogAction("MANUAL / precondition step", "Set Driver pretensioner to healed State (0A)")

        RESULT.InsertComment("Step 16: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 70 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 17: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 0A 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 18: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 80 70 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 19: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 0A 02 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 20: Perform Ign OFF/ON && Read Ign DID")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 21: Set Driver Pretensioner Squib historic condition")
        RESULT.InsertComment("Expected: historic state, DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN DTC:807013")
        RESULT.LogAction("MANUAL / precondition step", "Set Driver Pretensioner Squib historic condition")

        RESULT.InsertComment("Step 22: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 70 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")

        RESULT.InsertComment("Step 23: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 08 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 24: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 70 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")

        RESULT.InsertComment("Step 25: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 08 02 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 26: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")
        RESULT.InsertComment("Expected: 19 04 80 70 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13 for healed condition")

        RESULT.InsertComment("Step 27: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 08 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06 02 0C F1 B2 00 00 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 28: Set Driver pretensioner to Open fault")
        RESULT.InsertComment("Expected: Active, DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN DTC:807013")
        RESULT.LogAction("MANUAL / precondition step", "Set Driver pretensioner to Open fault")

        RESULT.InsertComment("Step 29: Read DID $F1B6 (IGN counter)")
        RESULT.InsertComment("Expected: ID 730: 08 03 22 F1 B6 00 00 00 00 00 ID 738: 07 08 62 F1 B6 00 00 02 43 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B6)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:8]), UDS_RESP_62_F1_B6_00_00_02_43_00)

        RESULT.InsertComment("Step 30: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")
        RESULT.InsertComment("Expected: 19 04 80 70 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")

        RESULT.InsertComment("Step 31: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 32: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")
        RESULT.InsertComment("Expected: 19 04 80 70 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")

        RESULT.InsertComment("Step 33: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 02 0C F1 B2 00 00 F1 B1 72 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 91 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 43 F1 B5 00 02 04 9D 00 00 00 07")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 34: Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")
        RESULT.InsertComment("Expected: 19 04 80 70 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:80 70 13")

        RESULT.InsertComment("Step 35: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 80 70 13 8B 01 0C F1 B2 00 00 F1 B1 71 6B F1 B0 00 00 00 F1 B9 00 04 44 00 00 03 58 04 48 11 00 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 02 42 F1 B5 00 02 04 9D 00 00 00 06 02 0C F1 B2 00 00 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
