# Author: Christy, Krishna
# Test Case : SID14_Testcase03
# Folder    : Clear Diagnostic Information service (SID $14)
# Service   : 0x14 ClearDiagnosticInformation
# Intention : To verify ECU gives positive response after fault creation.
# Verifies  : ISSUE:32591241, ISSUE:33697042, ISSUE:33697043, ISSUE:33697044, ISSUE:33697454, ISSUE:33697475, ISSUE:33697497

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_CLEAR_ALL_DTC,
    UDS_RESP_54,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID14_Testcase03"
    tc_desc = "To verify ECU gives positive response after fault creation."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID14_Testcase03")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x14 ClearDiagnosticInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:32591241, ISSUE:33697042, ISSUE:33697043, ISSUE:33697044, ISSUE:33697454, ISSUE:33697475, ISSUE:33697497")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 3: Create DRIVER_PRE_TENSIONER_SQUIB Open fault.")
        RESULT.InsertComment("Expected: Verify DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN fault is detected.")
        RESULT.LogAction("MANUAL / precondition step", "Create DRIVER_PRE_TENSIONER_SQUIB Open fault.")

        RESULT.InsertComment("Step 4: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 01 54 FF FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 5: Wait for qualify time,verify DTC is detected again")
        RESULT.InsertComment("Expected: DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN,active")
        RESULT.LogAction("MANUAL / precondition step", "Wait for qualify time,verify DTC is detected again")

        RESULT.InsertComment("Step 6: Set DRIVER_PRE_TENSIONER_SQUIB Open fault to Normal")
        RESULT.InsertComment("Expected: DTC_LOP_DRIVER_PRE_TENSIONER_SQUIB_OPEN,historic")
        RESULT.LogAction("MANUAL / precondition step", "Set DRIVER_PRE_TENSIONER_SQUIB Open fault to Normal")

        RESULT.InsertComment("Step 7: Send ClearDiagnosticInformation request(SID: $14)")
        RESULT.InsertComment("Expected: ID 730: 04 14 FF FF FF 00 00 00 ID 738: 01 54 FF FF FF FF FF FF")
        response = CAN.SendDiagByValues(UDS_REQ_CLEAR_ALL_DTC)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ClearDiagnosticInformation response", " ".join(response_tokens[:1]), UDS_RESP_54)

        RESULT.InsertComment("Step 8: Verify the faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify the faults.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
