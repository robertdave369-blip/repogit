# Author: Christy, Krishna
# Test Case : SID28_Testcase11
# Folder    : Communication Control(SID $28)
# Service   : 0x28 CommunicationControl
# Intention : To verify NRC31 on Physical Request ID ($730) with SID $28 on extended session (NRC31).
# Verifies  : ISSUE:33634585

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_28_00_FF,
    UDS_REQ_28_01_FF,
    UDS_REQ_28_02_FF,
    UDS_REQ_28_03,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_7F_28_31,
    UDS_RESP_SESSION_EXTENDED,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID28_Testcase11"
    tc_desc = "To verify NRC31 on Physical Request ID ($730) with SID $28 on extended session (NRC31)."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID28_Testcase11")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x28 CommunicationControl")
        RESULT.InsertComment("Requirements verified: ISSUE:33634585")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: NRC_31")
        RESULT.LogAction("MANUAL / precondition step", "NRC_31")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 4: Send in extended session.(SID $28, SF $00).")
        RESULT.InsertComment("Expected: 730: 03 28 00 FF 00 00 00 00 738: 03 7F 28 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_00_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:3]), UDS_RESP_7F_28_31)

        RESULT.InsertComment("Step 5: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 6: Send in extended session.(SID $28, SF $01).")
        RESULT.InsertComment("Expected: 730: 03 28 01 FF 00 00 00 00 738: 03 7F 28 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_01_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:3]), UDS_RESP_7F_28_31)

        RESULT.InsertComment("Step 7: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738:06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 8: Send in extended session.(SID $28, SF $02).")
        RESULT.InsertComment("Expected: 730: 03 28 02 FF 00 00 00 00 738: 03 7F 28 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_02_FF)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:3]), UDS_RESP_7F_28_31)

        RESULT.InsertComment("Step 9: Send to extended session.(SID $10, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 10 03 00 00 00 00 00 738: 06 50 03 00 32 01 F4 00")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_SESSION_EXTENDED)

        RESULT.InsertComment("Step 10: Send in extended session.(SID $28, SF $03).")
        RESULT.InsertComment("Expected: 730: 02 28 03 FF 00 00 00 00 738: 03 7F 28 31 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_28_03)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate CommunicationControl response", " ".join(response_tokens[:3]), UDS_RESP_7F_28_31)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
