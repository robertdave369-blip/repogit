# Author: Christy, Krishna
# Test Case : SID2E_Testcase23
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify NRC_$88 Vehicle Speed Too High
# Verifies  : ISSUE:33696867, ISSUE:33696881

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03_00_32_13_88,
    UDS_RESP_7F_2E_88,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase23"
    tc_desc = "To verify NRC_$88 Vehicle Speed Too High"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase23")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696867, ISSUE:33696881")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        # --- Write project-default Variant Code / EOL baseline ---
        manage_eol_code("DEFAULT", project="M310_M314_M110")

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active fault is detected.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify no active fault is detected.")

        RESULT.InsertComment("Step 3: Set Vehicle speed to 6.")
        RESULT.LogAction("MANUAL / precondition step", "Set Vehicle speed to 6.")

        RESULT.InsertComment("Step 4: Send Request for Extended Session. ID 730: 02 10 03 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 10 03 FF FF FF FF FF ID 738: 06 50 03 00 32 13 88 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 5: Send Request for Security Seed. ID 730: 02 27 01 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 27 01 FF FF FF FF FF ID 738: 06 67 01 xx xx xx xx FF (xx : Security Seed)")
        RESULT.InsertComment("Step 6: Send Request for Security Key. ID 730: 06 27 02 yy yy yy yy FF")
        sec_status = Internal_Security_Access(0x01)
        RESULT.InterpretEqualResult("Security Access level seed 0x01 unlock", sec_status, TestStatus.Passed)

        RESULT.InsertComment("Step 7: Write EOL (DID 0102) ID 730: 2E 01 02 7F 8F CF AF AA 1A 01 00 00 00 00 00 00 00 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. ID 738: 7F 2E 88 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_88)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        RESULT.InsertComment("Teardown: restore project-default Variant Code / EOL")
        manage_eol_code("DEFAULT", project="M310_M314_M110")
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
