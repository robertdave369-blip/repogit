# Author: Christy, Krishna
# Test Case : SID2E_Testcase04
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : Validation of DID ($ F199) - Programming Date
# Verifies  : ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:33696867

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_F1_99,
    UDS_REQ_2E_F1_99_23_02_26,
    UDS_RESP_62_F1_99_23_02_26,
    UDS_RESP_6E_F1_C0,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase04"
    tc_desc = "Validation of DID ($ F199) - Programming Date"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase04")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696864, ISSUE:33696865, ISSUE:33696866, ISSUE:33696867")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Enter extended session, & Level 1 security unlocked Send WriteDatabyIdentifier request (SID: $2E DID: $(F199) to set 0X03")
        RESULT.InsertComment("Expected: 730: 06 2E F1 99 23 02 26 00 738: 03 6E F1 C0 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_99_23_02_26)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_6E_F1_C0)

        RESULT.InsertComment("Step 3: Send ReadDatabyIdentifier request (SID: $22 DID: $F199)")
        RESULT.InsertComment("Expected: 730: 08 03 22 F1 99 00 00 00 00 738: 08 06 62 F1 99 23 02 26 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_99)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:6]), UDS_RESP_62_F1_99_23_02_26)

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
