# Author: Christy, Krishna
# Test Case : SID19 04_Testcase15
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : DID Snapshot Record Number(FF) GPO Fault in CAN Wakeup
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase15"
    tc_desc = "DID Snapshot Record Number(FF) GPO Fault in CAN Wakeup"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase15")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Snapshot data record(FF) with GPO fault for Active state , healed state condition & Historic")
        RESULT.LogAction("MANUAL / precondition step", "Snapshot data record(FF) with GPO fault for Active state , healed state condition & Historic")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Again Set vehicle Speed as VEHICLE_SPEED_= 250 kmph Set Battery voltage as Battery_voltage= 12 V Set Original odometer Occurance reading to 500KM Set Engine status as Soft reset(1) Set seat belt statu")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 5: Create CRASH OUTPUT LINE OPEN CIRCUIT")
        RESULT.LogAction("MANUAL / precondition step", "Create CRASH OUTPUT LINE OPEN CIRCUIT")

        RESULT.InsertComment("Step 6: Wait until qualify time,verify DTC")
        RESULT.InsertComment("Expected: DTC_CRASH OUTPUT LINE OPEN CIRCUIT active DTC CODE: 92 18 13 8B")
        RESULT.LogAction("MANUAL / precondition step", "Wait until qualify time,verify DTC")

        RESULT.InsertComment("Step 7: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 8: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 8B 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 10: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 8B 02 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 11: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 12: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 8B 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10 02 0C F1 B2 3E 80 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 13: Make CRASH OUTPUT LINE to Normal position")
        RESULT.InsertComment("Expected: DTC_CRASH OUTPUT LINE OPEN CIRCUIT , Healed DTC CODE: 92 18 13 0A")
        RESULT.LogAction("MANUAL / precondition step", "Make CRASH OUTPUT LINE to Normal position")

        RESULT.InsertComment("Step 14: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 15: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 0A 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 16: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 17: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 0A 02 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 18: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 19: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 0A 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10 02 0C F1 B2 3E 80 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 20: Cycle IGN")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 21: Verify DTC in Historic state")
        RESULT.InsertComment("Expected: DTC_CRASH OUTPUT LINE OPEN CIRCUIT , Historic DTC CODE: 92 18 13 08")
        RESULT.LogAction("MANUAL / precondition step", "Verify DTC in Historic state")

        RESULT.InsertComment("Step 22: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 23: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 08 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 24: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 25: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 08 02 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 26: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 92 18 13 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 27: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 92 18 13 08 01 0C F1 B2 3E 80 F1 B1 71 6B F1 B0 00 01 F4 F1 B9 03 04 44 00 00 14 04 04 48 00 00 04 4B 00 04 59 01 04 5A 5A F1 B6 00 00 02 4C F1 B5 00 02 04 9D 00 00 00 10 02 0C F1 B2 3E 80 F1 B1")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
