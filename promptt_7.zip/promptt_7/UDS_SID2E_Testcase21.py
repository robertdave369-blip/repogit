# Author: Christy, Krishna
# Test Case : SID2E_Testcase21
# Folder    : Write Data by Identifier Service(SID $2E)
# Service   : 0x2E WriteDataByIdentifier
# Intention : To verify NRC_$33 Security access denied / Security access requested
# Verifies  : ISSUE:33696867

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_2E_01_00_18_18_18_18_18_18_18_18_18__5befe0,
    UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290,
    UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01,
    UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01,
    UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9,
    UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086,
    UDS_REQ_2E_F1_99_23_02_26,
    UDS_REQ_2E_F1_9D_18_09_18,
    UDS_REQ_2E_F1_C0_05,
    UDS_REQ_SESSION_EXTENDED,
    UDS_RESP_50_03_00_32_13_88,
    UDS_RESP_7F_2E_33,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID2E_Testcase21"
    tc_desc = "To verify NRC_$33 Security access denied / Security access requested"
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID2E_Testcase21")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x2E WriteDataByIdentifier")
        RESULT.InsertComment("Requirements verified: ISSUE:33696867")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        # --- Write project-default Variant Code / EOL baseline ---
        manage_variant_code("DEFAULT", project="M310_M314_M110")
        manage_eol_code("DEFAULT", project="M310_M314_M110")

        RESULT.InsertComment("Step 1: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Verify no active fault is detected.")
        RESULT.InsertComment("Expected: no fault")
        RESULT.LogAction("MANUAL / precondition step", "Verify no active fault is detected.")

        RESULT.InsertComment("Step 3: Send Request for Extended Session. ID 730: 02 10 03 FF FF FF FF FF")
        RESULT.InsertComment("Expected: Verify ACU sends out the positive response. ID 730: 02 10 03 FF FF FF FF FF ID 738: 06 50 03 00 32 13 88 FF")
        response = CAN.SendDiagByValues(UDS_REQ_SESSION_EXTENDED)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate DiagnosticSessionControl response", " ".join(response_tokens[:6]), UDS_RESP_50_03_00_32_13_88)

        RESULT.InsertComment("Step 4: Send without L1 security through EOL (DID 0102) ID 730: 2E 01 02 7F 8F CF AF AA 1A 01 00 00 00 00 00 00 00 00 00 00 00 00 00")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. ID 738: 7F 2E 33 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_7F_8F_CF_AF_AA_1A_01)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_33)

        RESULT.InsertComment("Step 5: Send without L1 security VIN (DID F190) 730: 2E F1 90 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 32 738: 62 F1 90 00 00 00 00")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. ID 738: 7F 2E 33 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_90_32_32_32_32_32_32_32_32_32__faa1a9)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_33)

        RESULT.InsertComment("Step 6: Send without L1 security Vehicle speed (DID F1C0) 730: 08 04 2E F1 C0 05 00 00 00")
        RESULT.InsertComment("Expected: Verify ACU sends out the negative response. ID 738: 7F 2E 33 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_C0_05)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate WriteDataByIdentifier response", " ".join(response_tokens[:3]), UDS_RESP_7F_2E_33)

        RESULT.InsertComment("Step 7: Send without L1 security (DID F198)// 730: 00 13 2E F1 98 AA AA AA AA AA AA 20 20 20 20 20 20 20 20 20 20")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_98_AA_AA_AA_AA_AA_AA_20_20_20__10c086)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 8: Send without L1 security (DID F199) 730: 06 2E F1 99 23 02 26 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_99_23_02_26)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 9: Send without L1 security (DID F19D) 730: 06 2E F1 9D 18 09 18 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_F1_9D_18_09_18)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 10: Send without L1 security (DID 0100) 730: 20 2E 01 00 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18 18")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_00_18_18_18_18_18_18_18_18_18__5befe0)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 11: Send without L1 security (DID 0101) 730: 20 2E 01 01 2B 10 00 03 20 00 20 04 00 00 00 04 01 00 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_01_2B_10_00_03_20_00_20_04_00__bed290)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

        RESULT.InsertComment("Step 12: Send without L1 security (DID 0102) 730: 20 2E 01 02 7F 0F 0F AB 2A 18 01 00 00 00 00 00 00 00 00 00 00 00 00 00")
        response = CAN.SendDiagByValues(UDS_REQ_2E_01_02_7F_0F_0F_AB_2A_18_01)
        RESULT.LogAction("Response captured (no deterministic expected in workbook)", str(response))

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        RESULT.InsertComment("Teardown: restore project-default Variant Code / EOL")
        manage_variant_code("DEFAULT", project="M310_M314_M110")
        manage_eol_code("DEFAULT", project="M310_M314_M110")
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
