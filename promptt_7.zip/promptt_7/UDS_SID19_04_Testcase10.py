# Author: Christy, Krishna
# Test Case : SID19 04_Testcase10
# Folder    : Freeze Frame ($19_04)
# Service   : 0x19 ReadDTCInformation
# Intention : VBAT_HIGH DTC Snapshot Record under default conditions and followed by change is parameter values.
# Verifies  : ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699422, ISSUE:34699424, ISSUE:34699427, ISSUE:34699429, ISSUE:34699430, ISSUE:34699431, ISSUE:34699433, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513, ISSUE:34699436

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *
from Framework_IOEM_Py.projects.M310_M314_M110.config.cand_config import (
    UDS_LOG_CAN_IDS,
    UDS_REQ_22_F1_B6,
    UDS_RESP_62_F1_B6_00_00_00_1B,
)

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "SID19 04_Testcase10"
    tc_desc = "VBAT_HIGH DTC Snapshot Record under default conditions and followed by change is parameter values."
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=UDS_LOG_CAN_IDS, direct_write=False, tc_desc=tc_desc)
    aria_reports.add_group("SID19_04_Testcase10")

    try:
        RESULT.InsertComment(f"#Test Case ID: {tc_id}")
        RESULT.InsertComment(f"#Test Case Description: {tc_desc}")
        RESULT.InsertComment("Service under test: 0x19 ReadDTCInformation")
        RESULT.InsertComment("Requirements verified: ISSUE:33697815, ISSUE:33697873, ISSUE:33697896, ISSUE:33697897, ISSUE:33697960, ISSUE:33697961, ISSUE:33697964, ISSUE:33697966, ISSUE:33697967, ISSUE:33697968, ISSUE:33697969, ISSUE:33697970, ISSUE:33697971, ISSUE:33697972, ISSUE:33697973, ISSUE:34699415, ISSUE:34699417, ISSUE:34699419, ISSUE:34699422, ISSUE:34699424, ISSUE:34699427, ISSUE:34699429, ISSUE:34699430, ISSUE:34699431, ISSUE:34699433, ISSUE:34699432, ISSUE:34699434, ISSUE:34699435, ISSUE:34699509, ISSUE:34699513, ISSUE:34699436")

        # --- Standard precondition: fault-free bench, power, comms ---
        fault_free_profile_classic_can()
        PS.Power_Cycle()
        Sleep(1)
        read_software_version()

        RESULT.InsertComment("Step 1: Snapshot data for Active state,Historic and healed state in normal conditions values")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 2: Set the test bench to normal condition.")
        RESULT.InsertComment("Covered by standard precondition block above.")

        RESULT.InsertComment("Step 3: Verify no active faults.")
        RESULT.InsertComment("Fault-free state established by fault_free_profile_classic_can() above.")

        RESULT.InsertComment("Step 4: Set the below mentioned parameters before creating DTC __Vehicle Speed__ = 0 kmph __Battery voltage__ = 12 V & IGN Voltage = 12V __Original odometer Occurrence reading__ is 0x00000 __Vehicle State__ =")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 5: Read corresponding DIDs to the parameters applicable for freeze frame: Vehicle Speed = (SID: $22). (DID: F1B2) Battery voltage = (SID: $22). (DID: F1B1) Original odometer Occurrence reading = (SID: $2")
        RESULT.InsertComment("Expected: 738:05 62 F1 B2 00 00 00 00 00 738:05 62 F1 B1 71 6B 00 00 00 738:06 62 F1 B0 00 00 00 00 738:06 62 F1 B9 00 00 00 00 738:07 62 04 44 00 00 03 46 738:10 0B 62 04 48 55 55 55 01 00 00 00 00 738: 04 62 ")
        RESULT.LogAction("MANUAL / precondition step", "Read corresponding DIDs to the parameters applicable for freeze frame: Vehicle Speed = (SID: $22). (DID: F1B2) Battery voltage = (SID: $22). (DID: F1B1) Original odometer Occurrence reading = (SID: $2")

        RESULT.InsertComment("Step 6: Set BATTERY VOLTAGE HIGH fault")
        RESULT.InsertComment("Expected: Active, BATTERY VOLTAGE HIGH DTC:942A17")
        RESULT.LogAction("MANUAL / precondition step", "Set BATTERY VOLTAGE HIGH fault")

        RESULT.InsertComment("Step 7: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 8: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 9: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 10: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 02 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 11: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 12: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 13: Set BATTERY VOLTAGE HIGH to healed State (0A)")
        RESULT.InsertComment("Expected: verify fault state 0A DTC:94 2A 17")
        RESULT.LogAction("MANUAL / precondition step", "Set BATTERY VOLTAGE HIGH to healed State (0A)")

        RESULT.InsertComment("Step 14: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 15: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 0A 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 16: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 17: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 0A 02 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 18: Send ReadDTCInformation command($19, SF $04) to request information for DTC")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC")

        RESULT.InsertComment("Step 19: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 0A 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 20: Perform Ign OFF/ON && Read Ign DID")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 21: Set BATTERY VOLTAGE HIGH historic condition")
        RESULT.InsertComment("Expected: historic state, DTC_BATTERY VOLTAGE HIGH DTC:94 2A 17")
        RESULT.LogAction("MANUAL / precondition step", "Set BATTERY VOLTAGE HIGH historic condition")

        RESULT.InsertComment("Step 22: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")

        RESULT.InsertComment("Step 23: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 08 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 24: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")

        RESULT.InsertComment("Step 25: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 08 02 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 26: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17 for healed condition")

        RESULT.InsertComment("Step 27: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 08 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 28: Set/Update the existing values of the parameters: // Vehicle Speed = 0x27 kmph Battery voltage = 13 V & IGN Voltage = 12V Original odometer Occurrence reading is 0x150 Vehicle State = 3(Charging) Most")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 29: Set BATTERY VOLTAGE HIGH fault")
        RESULT.InsertComment("Expected: Active, DTC_BATTERY VOLTAGE HIGH DTC:94 2A 17")
        RESULT.LogAction("MANUAL / precondition step", "Set BATTERY VOLTAGE HIGH fault")

        RESULT.InsertComment("Step 30: Read DID $F1B6 (IGN counter)")
        RESULT.InsertComment("Expected: ID 730: 08 03 22 F1 B6 00 00 00 00 00 ID 738: 08 07 62 F1 B6 00 00 00 1B")
        response = CAN.SendDiagByValues(UDS_REQ_22_F1_B6)
        response_tokens = str(response).replace(",", " ").split()
        RESULT.InterpretEqualResult("Validate ReadDataByIdentifier response", " ".join(response_tokens[:7]), UDS_RESP_62_F1_B6_00_00_00_1B)

        RESULT.InsertComment("Step 31: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 32: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 33: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 02 11 F1 B2 00 27 F1 B1 88 81 F1 B0 00 01 50 F1 B9 03 04 44 00 00 03 46 04 48 14 11 11 01 00 00 00 00 04 4B 01 04 59 00 04 5A 3F F1 B6 00 00 00 1B 00 FF 00 FF 07 EB 01 01 01 01 F1 B5 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 34: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 02")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 35: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 36: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 37: Make the BATTERY VOLTAGE HIGH fault to healed and then historic.")
        RESULT.LogAction("MANUAL / precondition step", "Make the BATTERY VOLTAGE HIGH fault to healed and then historic.")

        RESULT.InsertComment("Step 38: Set/Update the existing values of the parameters:// // Vehicle Speed = 0x54 kmph// Battery voltage = 13 V & IGN Voltage = 12V// Original odometer Occurrence reading is 0x269// Vehicle State = 0(Stoppe")
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(1)

        RESULT.InsertComment("Step 39: Set BATTERY VOLTAGE HIGH fault again.")
        RESULT.InsertComment("Expected: Active, DTC_BATTERY VOLTAGE HIGH DTC:94 2A 17")
        RESULT.LogAction("MANUAL / precondition step", "Set BATTERY VOLTAGE HIGH fault again.")

        RESULT.InsertComment("Step 40: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 01")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 41: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 42: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 02")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 43: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 02 11 F1 B2 00 54 F1 B1 88 81 F1 B0 00 02 69 F1 B9 00 04 44 00 00 03 46 04 4814 11 11 01 00 00 00 00 04 4B 00 04 59 00 04 5A 3F F1 B6 00 00 00 1C 00 FF 00 FF 07 EB 01 01 01 01 F1 B5 ")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

        RESULT.InsertComment("Step 44: Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")
        RESULT.InsertComment("Expected: 19 04 94 2A 17 FF")
        RESULT.LogAction("MANUAL / precondition step", "Send ReadDTCInformation command($19, SF $04) to request information for DTC:94 2A 17")

        RESULT.InsertComment("Step 45: Verify ACU sends out the positive response.")
        RESULT.InsertComment("Expected: 59 04 94 2A 17 8B 01 11 F1 B2 00 00 F1 B1 79 5C F1 B0 00 00 00 F1 B9 00 04 44 00 00 02 FF 04 48 55 44 44 00 00 01 00 01 04 4B 00 04 59 00 04 5A 00 F1 B6 00 00 00 1A 00 FF 07 E4 00 00 00 00 00 00 F1 B5")
        RESULT.LogAction("MANUAL / precondition step", "Verify ACU sends out the positive response.")

    except Exception as ex:
        RESULT.InterpretEqualResult(f"{tc_id} exception", str(ex), "No exception")
    finally:
        aria_reports.write_to_file()
        aria_reports.close_group()


if __name__ == "__main__":
    run_test()
