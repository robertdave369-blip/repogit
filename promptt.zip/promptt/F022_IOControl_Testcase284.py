# Author: Christy
# IO Control: IOControl_Testcase284  |  Section: 0F22 - PASSENGER AIR BAG Enable INDICATOR(PADI)

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase284"
    tc_desc = 'F022 IO-control - 0F22 - PASSENGER AIR BAG Enable INDICATOR(PADI)'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        CAN.ChangeSignalValue("HPCC_1_100", "PSGR_AIRBAG_SW_IC", "0", channel_name="CANFD")
        Wait(200)
        _resp = CAN.SendDiagByValues("0x10 0x03")
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, "0x50 0x03 0x00 0x32 0x01 0xF4")
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues("0x2F 0x0F 0x22 0x03 0x00")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0x0F 0x22 0x03 0x00", " ".join(_tok[:4]), "0x6F 0x0F 0x22 0x03")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "INDC_PADL")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control INDC_PADL', _v, "0x1")
        _resp = CAN.SendDiagByValues("0x2F 0x0F 0x22 0x00")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0x0F 0x22 0x00", " ".join(_tok[:4]), "0x6F 0x0F 0x22 0x00")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "INDC_PADL")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control INDC_PADL', _v, "0x1")
    finally:
        try:
            CAN.ReloadDefaultPeriodicFrame("CANFD", "HPCC_1_100")
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
