# Author: Christy
# IO Control: IOControl_Testcase4  |  Section: F010 - ACTIVATE CRASH

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase4"
    tc_desc = 'F010 IO-control - F010 - ACTIVATE CRASH'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x2C0, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial DOOR_UNLOCK', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial STS_CRASH', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial CRASH_LOCATION', _v, "0x0")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('Initial SCM_CNT', _v, "0x0")
        _resp = CAN.SendDiagByValues("0x10 0x03")
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, "0x50 0x03 0x00 0x32 0x01 0xF4")
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues("0x2F 0xF0 0x10 0x03 0x01")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x10 0x03 0x01", " ".join(_tok[:4]), "0x6F 0xF0 0x10 0x03")
        _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control DOOR_UNLOCK (pre-freeze confirm)', _v, "0x1")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_CRASH (pre-freeze confirm)', _v, "0x1")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control CRASH_LOCATION (pre-freeze confirm)', _v, "0x1")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
        try:
            _n = int(_v, 16) if _v.lower().startswith("0x") else int(float(_v))
        except Exception:
            _n = None
        RESULT.InterpretEqualResultRange('After control SCM_CNT', _n, 0, 15)
        _resp = CAN.SendDiagByValues("0x2F 0xF0 0x10 0x02")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x10 0x02", " ".join(_tok[:4]), "0x6F 0xF0 0x10 0x02")
        _v = str(CAN.GetSignalFromFrame("HSCAN", "SRS1_20", "DOOR_UNLOCK")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control DOOR_UNLOCK', _v, "0x1")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_CRASH")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_CRASH', _v, "0x1")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "CRASH_LOCATION")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control CRASH_LOCATION', _v, "0x1")
        _samples = []
        for _i in range(25):
            _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "SCM_CNT")).strip()
            try:
                _samples.append(int(_v, 16) if _v.lower().startswith("0x") else int(float(_v)))
            except Exception:
                pass
            if _i < 24:
                Wait(200)
        RESULT.LogCustomAction('After control SCM_CNT', "Counter updates within 0..15", str(_samples), TestStatus.Passed if _samples and all(0 <= _x <= 15 for _x in _samples) and len(set(_samples)) >= 2 else TestStatus.Failed)
    finally:
        # (no injected frames to restore)
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
