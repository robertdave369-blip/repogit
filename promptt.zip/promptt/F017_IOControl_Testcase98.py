# Author: Christy
# IO Control: IOControl_Testcase98  |  Section: SEAT BELT LAMP

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase98"
    tc_desc = 'F017 IO-control - SEAT BELT LAMP'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738, 0x13C], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        # Set the Second Row RH SEAT BELT to STB faulty state
        SET_DCS_LOADS("200R", 9)  # ODS Present prerequisite
        SET_DCS_LOADS("BUS", 0)
        PS.SetLeakageVBATBusHigh()
        Wait(500)
        _resp = CAN.SendDiagByValues("0x10 0x03")
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, "0x50 0x03 0x00 0x32 0x01 0xF4")
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues("0x2F 0xF0 0x17 0x03 0x01")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("IO control 0x2F 0xF0 0x17 0x03 0x01", " ".join(_tok[:4]), "0x6F 0xF0 0x17 0x03")
        _v = str(CAN.GetSignalFromFrame("CANFD", "SRS1_FD_10", "STS_SEC_ROW_RIGHT_BLT")).strip()
        try:
            _v = f"0x{int(_v, 16):X}" if _v.lower().startswith("0x") else f"0x{int(float(_v)):X}"
        except Exception:
            pass
        RESULT.InterpretEqualResult('After control STS_SEC_ROW_RIGHT_BLT', _v, "0x1")
    finally:
        try:
            PS.ClearLeakageVBATBusHigh()
        except Exception:
            pass
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
