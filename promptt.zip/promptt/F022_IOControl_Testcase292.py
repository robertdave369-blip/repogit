# Author: Christy
# IO Control: IOControl_Testcase292  |  Section: 0F22 - PASSENGER AIR BAG Enable INDICATOR(PADI)

import os
import sys
from pathlib import Path

_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()


def run_test():
    tc_id = "IOControl_Testcase292"
    tc_desc = 'F022 IO-control - 0F22 - PASSENGER AIR BAG Enable INDICATOR(PADI)'
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=[0x730, 0x738], direct_write=False, tc_desc=tc_desc)
    try:
        aria_reports.add_report_info("#Test Case ID:", tc_id)
    except Exception:
        pass
    try:
        Clear_DTC_Info()
        PS.BATT_ON()
        Wait(100)
        PS.IGN_OFF()
        Sleep(1)
        PS.IGN_ON()
        Sleep(8)
        ExpectInternalErrors("")
        _resp = CAN.SendDiagByValues("0x10 0x03")
        RESULT.InterpretEqualResult("Start extended diagnostic session", _resp, "0x50 0x03 0x00 0x32 0x01 0xF4")
        Internal_Security_Access(0x01)
        Wait(50)
        Internal_Security_Access(0x01)
        Wait(50)
        _resp = CAN.SendDiagByValues("0x2F 0x0F 0x22 0x03 0x01")
        _tok = [t for t in str(_resp).replace(",", " ").split() if t]
        RESULT.InterpretEqualResult("Negative response to 0x2F 0x0F 0x22 0x03 0x01 (NRC 0x13)", _tok[0] if _tok else str(_resp), "0x7F")
    finally:
        # (no injected frames to restore)
        try:
            aria_reports.write_to_file()
        except Exception:
            pass


if __name__ == "__main__":
    run_test()
