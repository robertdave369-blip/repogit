# M210 EDR IMU recording

Author: Kris

`scripts/M210_EDR_IMU_Recording_FrontLeft.py` simulates every IMU axis through the ARIA Panasonic SPI
simulation with .txt curves. It then runs a front crash, which is checked in EDR record 1, and a left
crash, which is checked in EDR record 2. The six IMU elements of each record are compared with what was
simulated: `X_AXIS_ANGULAR`, `Y_AXIS_ANGULAR`, `YAW_RATE`, `LONG_ACCEL`, `LATERAL_ACCEL` and
`Z_AXIS_ACCEL`, each 17 samples from -5 s to +3 s every 0.5 s.

## Curves

The script names its two folders and loads only them. Each folder's `imu_set_summary.txt` lists every value.

| Folder | Content |
|---|---|
| `crash_data/m210/imu_front_crash` | the standard front crash with every RSU and GEN6 curve delayed 5.5 s (T0 5515 ms after the trigger), plus `Panasonic_imu_axis1-7.txt` |
| `crash_data/m210/imu_left_crash` | the same for the left crash (T0 5518.5 ms); every IMU value is the front set's negated, so the two records cannot be mistaken for each other |

IMU values for the front crash (the left crash uses them negated):

| Axis | Element | Values, -5 s to +3 s |
|---|---|---|
| 1 gyro X | X_AXIS_ANGULAR | 0, +2.5, -2.5 ... +20, -20 deg/s |
| 2 gyro Y | Y_AXIS_ANGULAR | the same values in reverse order |
| 3 gyro Z | YAW_RATE | -300 to +300 deg/s (imu_config `EDR_IMU_STIMULUS` sweep) |
| 4 accel X | LONG_ACCEL | -8 to +8 g (imu_config sweep) |
| 5 accel Y | LATERAL_ACCEL | the imu_config sweep values in another order: 0, +1, -1 ... +8, -8 g |
| 6 accel Z | Z_AXIS_ACCEL | the same values in reverse order |
| 7 | temperature | 0 |

Every element gets its own pattern. A record element that follows the wrong axis or sign therefore
fails, and the report names the axis and sign it does follow.

## Sampling

The ECU samples the IMU signals on a free-running 500 ms tick (RstEdr_Lcfg.c):
- a pre-event ring buffer of 11 samples;
- one extra sample at T0 when the last tick is at least 100 ms old (RSTEDR_500MS_PREDATA_ACQUIRED_OFFSET);
- after T0, samples are read from the second tick on.

Each value is therefore held over the whole interval in which its sample can be taken, whatever the
tick phase:
- label L < 0: (T0 + L - 100 ms, T0 + L + 400 ms];
- label 0: (T0 - 100 ms, T0 + 500 ms];
- label L > 0: (T0 + L, T0 + L + 500 ms].

The script works out T0 from the set's central curves (rule R1) and reads each expected value from the
IMU curve over that interval.

## Assumptions and open points

- **Bench:** the Panasonic SPI simulation must be wired on the bench. On 2026-10-24 the M314 loadbox
  gave the `Panasonic` function `Channel -1` and no EVT (projects/M310_M314_M110/modules/CANC/
  IMU_SPI_SIMULATION.md). The script keeps the EVT the bench gave the function. Its hand-over DTC read
  shows whether the ECU accepts the simulated IMU.
- **IMU type:** the M210 IMU is a Panasonic sensor (user, 2026-11-06), read through ARIA's
  `Panasonic` function. The part number is not confirmed; the scale below is the EWTS5G default.
- **Scale and axes:** 50 counts per deg/s and 2000 counts per g, which equal the EDR resolution. Axis
  map 1:1 with sign +1, as the M310 CAN-C IMU scripts assume. One curve line is 0.5 ms.
- **ECU processing:** the ECU is assumed to record the IMU vehicle signals unfiltered, with no offset
  learning. The component that writes them is not in the M210 source tree.
- **Rollover:** roll and pitch rates stay within ±20 deg/s and alternate in sign, so the roll angle
  stays below about 10 deg. This keeps the rollover algorithm (OpsRollAlg) from firing. Yaw, LONG and
  LAT use the full ±300 deg/s and ±8 g.
- **Records:** the front crash deploys and locks record 1, and the left crash goes to record 2. After
  the front crash, record 2 must be empty. After the left crash, record 1 must still hold the front
  crash's IMU data.
- **T0:** the ECU's T0 is taken within 5 ms of the rule R1 T0.
- **EDR-13 not covered:** the review item about a post-T0 sample one slot late is not revealed here,
  because every interval above is within one sampling period of its label. Use the EDR-13 test for it.
- **Curve length:** the IMU curves are 19030 samples and the crash curves 11600. The bench's longest
  IMU curve so far is 20000 samples.
- **Not bench-run.**
