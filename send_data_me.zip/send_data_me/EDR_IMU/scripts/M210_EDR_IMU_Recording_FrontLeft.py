# Author: Kris
#
# M210 EDR IMU recording: every IMU axis simulated through the ARIA Panasonic SPI simulation with
# .txt curves, then a front crash (EDR record 1) and a left crash (EDR record 2).
# Checks that the six IMU elements of each record (X_AXIS_ANGULAR, Y_AXIS_ANGULAR, YAW_RATE,
# LONG_ACCEL, LATERAL_ACCEL, Z_AXIS_ACCEL: 17 samples, -5 s to +3 s every 0.5 s) hold the values the
# simulated IMU gave at those instants.
# Crash sets (the curves fed, named in the script): crash_data/m210/imu_front_crash and
# crash_data/m210/imu_left_crash (imu_set_summary.txt in each folder). Each is the standard front /
# left crash delayed 5.5 s, plus one Panasonic curve per axis that holds, for each EDR sample, a value
# within the element's range; the left set's IMU values are the front set's negated, so the two
# records cannot be mistaken for each other.
# The ECU takes the IMU samples on its free-running 500 ms tick (RstEdr_Lcfg.c: pre-event ring buffer,
# one more sample at T0 when the last tick is 100 ms or more old, post-T0 samples read from index 1),
# so each value is held over the whole interval in which its sample can be taken, whatever the tick
# phase: label L < 0: (T0 + L - 100 ms, T0 + L + 400 ms]; label 0: (T0 - 100 ms, T0 + 500 ms];
# label L > 0: (T0 + L, T0 + L + 500 ms]. The expected value of each sample is read from the curve
# over that interval.
# Sequence: fault-free profile; the ECU's IMU handed over to the Panasonic simulation (no DTC). For
# each crash: ECU off, the set's Panasonic, RSU and GEN6 curves loaded, ECU on, one trigger (all curves
# start together), wait until the record is complete, read it. After the front crash record 2 must be
# empty; after the left crash record 1 must still hold the front crash's IMU data. At the end the
# curves are removed, the Panasonic simulation is stopped and the bench is made fault free, also on a
# failure.

import os
import sys
from pathlib import Path

# Make Framework_IOEM_Py importable as a top-level package.
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# Shared library: import_list re-exports every shared-library module (DTC constants, bench and
# report calls, EDR decoding). The two ARIA calls run before anything below uses the bench.
from Framework_IOEM_Py.shared_libraries.import_list import *

ensure_apym_on_path()
init_aria()

from Framework_IOEM_Py.shared_libraries.crash_configuration import build_rsu_config, build_spi_config

# M210 configuration.
from Framework_IOEM_Py.projects.M210.config.crash_curve_config import M210_RSU_CHANNEL_SPECS, M210_SPI_SPECS
from Framework_IOEM_Py.projects.M210.config.edr_config import (
    DECONFIGURED_BYTE_VALUE, EDR_DECODER_CONFIG, EDR_PARAMETERS, EDR_PARAMETERS_BY_NAME, EDR_RECORD_DIDS,
    RESPONSE_HEADER_BYTES,
)
from Framework_IOEM_Py.projects.M210.config.rsu_config import RSU_T0_OFFSETS


def read_curve(path):
    """A curve file: one value per line."""
    with open(path) as handle:
        return [int(float(line)) for line in handle if line.strip()]


def r1_t0(curve_g, window_samples, threshold_kmh, kmh_per_g_sample):
    """Rule R1: the first sample where the delta-V over the window reaches the threshold."""
    running = 0.0
    for index, value in enumerate(curve_g):
        running += value
        if index >= window_samples:
            running -= curve_g[index - window_samples]
        if abs(running) * kmh_per_g_sample >= threshold_kmh:
            return index
    return None


def signed16(word):
    return word - 0x10000 if word >= 0x8000 else word


def run_test():
    tc_id = "M210-EDR-IMU-01"
    tc_desc = ("Every IMU axis simulated with .txt curves, a front crash then a left crash: the six IMU elements "
               "of record 1 against the front crash's IMU input and of record 2 against the left crash's.")
    records = EDR_RECORD_DIDS    # 0455 / 045B

    # -- 1. The crash sets and what is tested -----------------------------------------------------
    # One set per crash; the curves fed come from these folders only. (crash type, folder, record)
    crashes = [
        ("front", _FRAMEWORK_ROOT / "crash_data" / "m210" / "imu_front_crash", 0),
        ("left", _FRAMEWORK_ROOT / "crash_data" / "m210" / "imu_left_crash", 1),
    ]
    # NOT IN CONFIG - the M210 IMU is a Panasonic sensor (user, 2026-11-06). The ARIA SPI-FPGA function of
    # the IMU (bench loadbox Function.Name) and its curve files; Panasonic axis 1..7 = gyro X, gyro Y, gyro Z, accel X, accel Y, accel Z, temperature.
    imu_function = "Panasonic"
    imu_curve_name = "Panasonic_imu_axis{axis}.txt"
    imu_axis_count = 7
    # NOT IN CONFIG [ASSUMPTION, to confirm on the bench] - the EDR element each Panasonic axis drives
    # and the mounting sign (as the M310 CAN-C IMU scripts assume; a sensor turned 90 deg would swap
    # LONG / LAT and X / Y angular). (element, Panasonic axis, sign)
    imu_axes = [
        ("X_AXIS_ANGULAR", 1, 1),
        ("Y_AXIS_ANGULAR", 2, 1),
        ("YAW_RATE", 3, 1),
        ("LONG_ACCEL", 4, 1),
        ("LATERAL_ACCEL", 5, 1),
        ("Z_AXIS_ACCEL", 6, 1),
    ]
    # NOT IN CONFIG [ASSUMPTION] - Panasonic EWTS5G counts per unit (default ranges). They equal the EDR
    # resolution: the ECU stores the IMU signal as it is (RstEdr_Lcfg.c rstedr_ConvertYawRate & co.).
    lsb_per_unit = {"deg/sec": 50, "g": 2000}
    sample_ms = 0.5         # NOT IN CONFIG [ASSUMPTION] - one curve line every 0.5 ms (2 kHz)
    # NOT IN CONFIG - RstEdr_Lcfg.c / RstEdr_Cfg.h (RSTEDR_500MS_PREDATA_ACQUIRED_OFFSET): the 2-per-second
    # elements are sampled on a free-running 500 ms tick; at T0 one more sample is taken when the last
    # tick is at least 100 ms old.
    tick_ms = 500
    t0_sample_after_ms = 100
    t0_margin_ms = 5        # NOT IN CONFIG - the ECU's T0 may lie a few ms from the rule R1 T0
    counts_tolerance = 1    # NOT IN CONFIG - one count of the record
    # NOT IN CONFIG - RstEdr_Cfg.h: a sample whose quality is not valid / that was not captured
    unobtainable_word, not_captured_word = 0xFFFF, 0x7FFF
    # NOT IN CONFIG - rule R1 (always-on algorithm): T0 is the first sample where the central X
    # delta-V over 20 ms, or central Y over 5 ms, reaches 0.8 km/h. GEN6_XY curve index (0 = Central Y,
    # 2 = Central X) and LSB per g (RstEdr_Cfg.h: 128 g / 64 g sensors).
    t0_kmh = 0.8
    central = {"X": (2, 20.0, 16), "Y": (0, 5.0, 32)}    # axis: (curve index, window ms, LSB per g)
    kmh_per_g_sample = 9.80665 * sample_ms / 1000.0 * 3.6
    # The record is complete once the longest series of the record (edr_config) has ended after T0 and
    # the record has been written.
    series_end_ms = 1000 * max(p["sample_range"]["end"] for p in EDR_PARAMETERS if p.get("sample_range"))
    record_write_ms = EDR_DECODER_CONFIG["read"]["record_ready_wait_ms"]
    sampling = EDR_PARAMETERS_BY_NAME[imu_axes[0][0]]["sample_range"]    # -5 s to +3 s every 0.5 s
    labels_ms = [round(1000 * (sampling["start"] + k * sampling["step"]))
                 for k in range(round((sampling["end"] - sampling["start"]) / sampling["step"]) + 1)]

    def interval_ms(label):
        """The instants after T0 (ms) at which the ECU can take the sample of this label."""
        start = label - t0_sample_after_ms if label <= 0 else label
        end = label + tick_ms - t0_sample_after_ms if label < 0 else label + tick_ms
        return start, end

    # -- 2. Expected results: the IMU curves over each sample's interval, in EDR counts ---------------
    # t0_ms[event]; inputs[event][axis] = per label the curve value held over its interval, or None
    # where the curve is not constant there (the set does not fit: BLOCKED).
    t0_ms, inputs = [], []
    for crash, folder, column in crashes:
        spi = build_spi_config(str(folder), M210_SPI_SPECS[crash])
        found = []
        for index, window_ms, lsb_per_g in central.values():
            curve_g = [lsb / lsb_per_g for lsb in read_curve(spi[index][0])]
            found.append(r1_t0(curve_g, int(window_ms / sample_ms), t0_kmh, kmh_per_g_sample))
        t0 = min(t for t in found if t is not None) * sample_ms + RSU_T0_OFFSETS.get(crash, RSU_T0_OFFSETS["default"])
        t0_ms.append(t0)
        held_by_axis = {}
        for axis in range(1, imu_axis_count):
            curve = read_curve(folder / imu_curve_name.format(axis=axis))
            held = []
            for label in labels_ms:
                start, end = interval_ms(label)
                first = int((t0 + start + t0_margin_ms) / sample_ms) + 1
                last = int((t0 + end - t0_margin_ms) / sample_ms)
                values = {curve[i] for i in range(first, last + 1) if 0 <= i < len(curve)}
                held.append(values.pop() if len(values) == 1 and last < len(curve) else None)
            held_by_axis[axis] = held
        inputs.append(held_by_axis)

    def edr_counts(element, curve_counts, sign):
        """The record counts of an IMU curve value driving this element."""
        spec = EDR_PARAMETERS_BY_NAME[element]
        return round(sign * curve_counts / lsb_per_unit[spec["unit"]] / spec["scaling_factor"])

    # -- 3. Report ----------------------------------------------------------------------------------
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    create_report_and_logging(test_case_file, can_ids=resolve_can_log_ids([]), tc_desc=tc_desc)
    aria_reports.add_report_info("#Test Case ID:", tc_id)
    for event, (crash, folder, column) in enumerate(crashes):
        aria_reports.add_report_info(f"#E{event + 1} {crash} crash, record {column + 1} ({records[column]}):",
                                     f"{folder}; T0 (rule R1) {t0_ms[event]:g} ms after the trigger")

    def check_record(event, column):
        """Every IMU element of the record against the IMU input of the event it holds."""
        record = records[column]
        title = f"Record {column + 1} ({record}), E{event + 1} {crashes[event][0]} crash"
        payload = read_edr_record_bytes(record)[RESPONSE_HEADER_BYTES:]
        if not payload or all(int(str(b), 16) == DECONFIGURED_BYTE_VALUE for b in payload):
            RESULT.InterpretEqualResult(f"BLOCKED - {title}", "empty", f"E{event + 1} recorded", False)
            return
        raw = (read_edr_parameters([row[0] for row in imu_axes], did=record, return_data=True) or {}).get("raw", {})
        summary = []
        for element, axis, sign in imu_axes:
            spec = EDR_PARAMETERS_BY_NAME[element]
            unit, scale = spec["unit"], spec["scaling_factor"]
            data = [int(str(b), 16) for b in raw.get(element) or [] if b is not None]
            words = [(data[2 * k] << 8) | data[2 * k + 1] for k in range(len(data) // 2)]
            aria_reports.add_group(f"{title}: {element}")
            RESULT.CommentStep(f"{element}: input", f"{imu_function} axis {axis} ({imu_curve_name.format(axis=axis)}), "
                                                    f"sign {sign:+d}, {lsb_per_unit[unit]} counts per {unit}")
            RESULT.InterpretEqualResult(f"{element}: samples in the record", len(words), len(labels_ms),
                                        len(words) == len(labels_ms))
            matching = 0
            for k, label in enumerate(labels_ms):
                held = inputs[event][axis][k]
                start, end = interval_ms(label)
                if held is None:
                    RESULT.InterpretEqualResult(f"BLOCKED - {element} at {label / 1000:+.1f} s: input not constant "
                                                f"from T0 {start:+g} to {end:+g} ms", "set", "constant input", False)
                    continue
                wanted = edr_counts(element, held, sign)
                word = words[k] if k < len(words) else None
                if word is None:
                    obtained = "no data"
                elif word == unobtainable_word:
                    obtained = "0xFFFF (unobtainable: IMU quality not valid)"
                elif word == not_captured_word:
                    obtained = "0x7FFF (not captured)"
                else:
                    obtained = f"{signed16(word) * scale:+g} (0x{word:04X})"
                passed = word is not None and abs(signed16(word) - wanted) <= counts_tolerance
                matching += passed
                RESULT.InterpretEqualResult(
                    f"{element} at {label / 1000:+.1f} s ({unit}; input held from T0 {start:+g} to {end:+g} ms)",
                    obtained, f"{wanted * scale:+g} (0x{wanted & 0xFFFF:04X})", passed)
            # Which Panasonic axis (and sign) the series follows: a wrong axis map or mounting sign shows here.
            scores = {(a, s): sum(1 for k in range(min(len(words), len(labels_ms))) if inputs[event][a][k] is not None
                                  and abs(signed16(words[k]) - edr_counts(element, inputs[event][a][k], s)) <= counts_tolerance)
                      for a in inputs[event] for s in (1, -1)}
            best = max(scores, key=lambda key: (scores[key], key == (axis, sign)))
            RESULT.CommentStep(f"{element}: the record follows", f"{imu_function} axis {best[0]}, sign {best[1]:+d} "
                                                                 f"({scores[best]} of {len(labels_ms)} samples)")
            summary.append((element, matching))
            aria_reports.close_group()
        aria_reports.add_group(f"{title}: summary")
        for element, matching in summary:
            RESULT.InterpretEqualResult(f"{element}: samples matching the input", f"{matching} of {len(labels_ms)}",
                                        f"{len(labels_ms)} of {len(labels_ms)}", matching == len(labels_ms))
        aria_reports.close_group()

    def check_empty(column):
        record = records[column]
        aria_reports.add_group(f"Record {column + 1} ({record}): no event yet")
        payload = read_edr_record_bytes(record)[RESPONSE_HEADER_BYTES:]
        written = len([b for b in payload if int(str(b), 16) != DECONFIGURED_BYTE_VALUE])
        RESULT.InterpretEqualResult(f"Record {column + 1} ({record}): bytes other than 0xFF (no event stored)", written, 0)
        aria_reports.close_group()

    try:
        fault_free_profile()    # NVM (EDR and DTCs) cleared, default EOL / variant code, power cycle
        read_software_version()

        # -- 4. Hand the ECU's IMU over to the Panasonic simulation, sensor at rest -------------------
        aria_reports.add_group(f"Hand the ECU's IMU over to the ARIA {imu_function} simulation")
        PS.IGN_OFF()
        SPI.TriggerEvtErrors(imu_function, "Stop")
        SPI.SimulateSensor(imu_function, "Start")
        RESULT.InsertComment(f"SPI sensor simulation: {imu_function} keeps the EVT the bench gave it and answers "
                             f"the ECU's IMU reads")
        RESULT.InterpretEqualResult("No SPI curve left loaded for a crash trigger to replay",
                                    SPI.RemoveAllCrashCurves()[0], "0000")
        PS.Power_Cycle()
        Wait(PROVEOUT_COMPLETION_TIME)
        Read_DTC("The ECU accepts the simulated IMU: no DTC", Read_DTC_Resp, Read_DTC_Req)
        aria_reports.close_group()

        for event, (crash, folder, column) in enumerate(crashes):
            # -- 5. Load the set with the ECU off, then switch the ECU on (the load_crash_curves sequence,
            #       the Panasonic curves first: LoadSpiCurves removes every SPI curve before it loads) ----
            rsu = build_rsu_config(str(folder), M210_RSU_CHANNEL_SPECS)    # ARIA RSU channel -> (curve, inverted)
            spi = build_spi_config(str(folder), M210_SPI_SPECS[crash])    # GEN6_XY curves 1-4 -> (curve, inverted)
            imu_curves = [(str(folder / imu_curve_name.format(axis=axis)), False)
                          for axis in range(1, imu_axis_count + 1)]
            aria_reports.add_group(f"E{event + 1}: load the crash set {folder.name} and switch the ECU on")
            PS.BATT_OFF()
            Wait(100)
            PS.IGN_OFF()
            if not LoadSpiCurves(imu_function, imu_curves):
                raise RuntimeError(f"{imu_function} curves of {folder.name} not loaded, so nothing is triggered")
            for rsu_channel, (path, inverted) in rsu.items():
                RSU.SendAcceleration(rsu_channel, path, inverted)
            Wait(2000)
            SPI.SendCrashData("GEN6_XY", *[item for pair in spi for item in pair])    # the SPI function load_crash_curves uses
            ResultStep(f"Crash files of {folder.name} loaded through ARIA", None, None)
            Wait(100)
            PS.BATT_ON()
            Wait(100)
            PS.IGN_ON()
            Wait(PROVEOUT_COMPLETION_TIME)
            aria_reports.close_group()

            # -- 6. The crash: one trigger starts every curve; wait until the record is complete -------
            aria_reports.add_group(f"E{event + 1}: {crash} crash, one trigger")
            TriggerCrash()
            Wait(t0_ms[event] + series_end_ms + record_write_ms)
            aria_reports.close_group()

            # -- 7. The record of this crash; record 2 still empty after E1, record 1 unchanged after E2 --
            check_record(event, column)
            if event == 0:
                check_empty(crashes[1][2])
            else:
                check_record(0, crashes[0][2])

    finally:
        # -- 8. No curve left, the ECU's own IMU again, NVM cleared and the bench fault free -----------
        try:
            PS.IGN_OFF()
            SPI.RemoveAllCrashCurves()
            SPI.SimulateSensor(imu_function, "Stop")
            RESULT.InsertComment(f"SPI sensor simulation: {imu_function} stopped, the ECU reads its own IMU again")
            PS.Power_Cycle()
        finally:
            fault_free_profile()
            aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()
