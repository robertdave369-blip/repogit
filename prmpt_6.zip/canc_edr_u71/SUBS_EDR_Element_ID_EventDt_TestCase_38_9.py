# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
    Under_Voltage,
    Over_Voltage,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    enter_ext_session,
    Internal_Security_Access,
    manage_variant_code,
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *
from Framework_IOEM_Py.projects.U171.config.variantcode_config import *



def run_test():
    tc_id = "38.9"
    tc_desc = 'Verify EDR records the latched EventDt value when over-voltage is induced before crash.'

    signal_def = MAH_CAN_SIGNAL_DEFS["EventDt"]
    msg = signal_def["frame"]
    signals = signal_def.get("signals") or str(signal_def["signal"]).split("/")
    values = signal_def["TestCase_38_values"]
    edr_param = signal_def.get("EDR_Parameter", "EventDt")
    edr_parameters = get_edr_parameters()
    event_params = ['EventDtYear', 'EventDt_Month', 'EventDt_Day']

    if not any(param.get("name") == event_params[0] for param in edr_parameters):
        edr_parameters.extend([
                {"name": "EventDtYear", "range": 20, "type": "int"},
                {"name": "EventDt_Month", "range": 21, "type": "int"},
                {"name": "EventDt_Day", "range": 21, "type": "int"},
            ])

    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        date_val, month_val, year_val = values[x] if x < len(values) else values[-1]

        aria_reports.add_group(f"EventDt Test Iteration {x + 1} - DID 0x{did}")

        
        load_crash_curves(crash_type)
        CAN.ChangeSignalValue(msg, signals[0], str(date_val))
        CAN.ChangeSignalValue(msg, signals[1], str(month_val))
        CAN.ChangeSignalValue(msg, signals[2], str(year_val))
        Wait(sample_interval_ms)

        received_date = CAN.GetSignalFromFrame(msg, signals[0])
        received_month = CAN.GetSignalFromFrame(msg, signals[1])
        received_year = CAN.GetSignalFromFrame(msg, signals[2])
        try:
            received_date_int = int(received_date, 16) if isinstance(received_date, str) and received_date.lower().startswith("0x") else int(received_date)
        except Exception:
            received_date_int = int(received_date)
        try:
            received_month_int = int(received_month, 16) if isinstance(received_month, str) and received_month.lower().startswith("0x") else int(received_month)
        except Exception:
            received_month_int = int(received_month)
        try:
            received_year_int = int(received_year, 16) if isinstance(received_year, str) and received_year.lower().startswith("0x") else int(received_year)
        except Exception:
            received_year_int = int(received_year)
        RESULT.InterpretEqualResult(f"Check {signals[0]} set for DID 0x{did}", str(received_date_int), str(int(date_val)))
        RESULT.InterpretEqualResult(f"Check {signals[1]} set for DID 0x{did}", str(received_month_int), str(int(month_val)))
        RESULT.InterpretEqualResult(f"Check {signals[2]} set for DID 0x{did}", str(received_year_int), str(int(year_val)))
        combined_fault_dtc = Over_Voltage + " " + DTC_status["DTC_active"]
        RESULT.InsertComment("Inducing over-voltage fault.")
        PS.SetVoltage(20.0)

        TriggerCrash()
        Sleep(3)

        combineDTC = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + combineDTC + " " + combined_fault_dtc, Read_DTC_Req)

        Sleep(5)

        edr_read = read_edr_parameters(event_params, did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_map = edr_read.get("decoded", {}) if isinstance(edr_read, dict) else {}
        decoded_year_values = decoded_map.get("EventDtYear", []) or []
        decoded_month_values = decoded_map.get("EventDt_Month", []) or []
        decoded_day_values = decoded_map.get("EventDt_Day", []) or []
        expected_date = f"DATE: {int(date_val):02}/{int(month_val):02}/{int(year_val) + 2020}"
        aria_reports.add_group("EDR Output Verification - Latched Value")
        if decoded_year_values and decoded_month_values and decoded_day_values:
            actual_date = f"DATE: {int(decoded_day_values[0]):02}/{int(decoded_month_values[0]):02}/{int(decoded_year_values[0]) + 2020}"
            RESULT.InterpretEqualResult(f"Compare simulated EventDt vs decoded EventDt for DID 0x{did}", actual_date, expected_date)
        else:
            RESULT.LogCustomAction("EventDt Decode", f"Missing decoded sample(s): Year={decoded_year_values}, Month={decoded_month_values}, Day={decoded_day_values}", expected_date, TestStatus.Failed)
        aria_reports.close_group()

        PS.SetVoltage(12.0)
        for signal in signals:
            CAN.ChangeSignalValue(msg, signal, "0")
        CAN.ReloadDefaultPeriodicFrame(msg)
        aria_reports.close_group()

    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
