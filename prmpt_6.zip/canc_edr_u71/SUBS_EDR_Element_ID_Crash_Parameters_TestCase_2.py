# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── MAGIC IMPORT: Gives access to everything in shared_libraries instantly ───
from Framework_IOEM_Py.shared_libraries.import_list import *

# ── ARIA bring-up ────────────────────────────────────────────────────────────
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import read_edr_parameters

# ── Config Imports (Project-specific configs) ────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import *
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "2"
    tc_desc = "Verify crash parameters are recorded for front, left, right, rear, and near crash events."

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = [0x730, 0x738, 0x2C0]
    create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False, tc_desc=tc_desc)
    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()

    aria_reports.add_group("Front Crash")
    NVM_Clear_L61()
    PS.Power_Cycle()
    Sleep(1)
    perform_crash("front")
    Sleep(3)
    combineDTC_front = (Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC("Front Crash", Read_DTC_Resp + " " + combineDTC_front, Read_DTC_Req)
    Sleep(5)
    read_edr_parameters(Crash_Parameters, crash_type="front", can_wakeup=False)
    aria_reports.close_group()

    aria_reports.add_group("Left Crash")
    NVM_Clear_L61()
    PS.Power_Cycle()
    Sleep(1)
    perform_crash("left")
    Sleep(3)
    combineDTC_left = (Side_Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC("Left Crash", Read_DTC_Resp + " " + combineDTC_left, Read_DTC_Req)
    Sleep(5)
    read_edr_parameters(Crash_Parameters, crash_type="left", can_wakeup=False)
    aria_reports.close_group()

    aria_reports.add_group("Right Crash")
    NVM_Clear_L61()
    PS.Power_Cycle()
    Sleep(1)
    perform_crash("right")
    Sleep(3)
    combineDTC_right = (Side_Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC("Right Crash", Read_DTC_Resp + " " + combineDTC_right, Read_DTC_Req)
    Sleep(5)
    read_edr_parameters(Crash_Parameters, crash_type="right", can_wakeup=False)
    aria_reports.close_group()

    aria_reports.add_group("rear")
    NVM_Clear_L61()
    PS.Power_Cycle()
    Sleep(1)
    perform_crash("rear")
    Sleep(3)
    combineDTC_rear = (Rear_Crash_DTC + " " + DTC_status["DTC_active"])
    Read_DTC("Rear Crash", Read_DTC_Resp + " " + combineDTC_rear, Read_DTC_Req)
    Sleep(5)
    read_edr_parameters(Crash_Parameters, crash_type="rear", can_wakeup=False)
    aria_reports.close_group()

    aria_reports.add_group("near")
    NVM_Clear_L61()
    PS.Power_Cycle()
    Sleep(1)
    perform_crash("near")
    Sleep(3)
    Read_DTC("NO DTC", Read_DTC_Resp, Read_DTC_Req)
    Sleep(8)
    read_edr_parameters(Crash_Parameters, crash_type="near", can_wakeup=False)
    aria_reports.close_group()
    aria_reports.write_to_file()

if __name__ == "__main__":
    run_test()

