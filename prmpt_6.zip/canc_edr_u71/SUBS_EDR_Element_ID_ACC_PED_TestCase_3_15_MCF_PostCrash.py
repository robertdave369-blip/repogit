# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "3.15"
    tc_desc = (
        "ACC_PED Message Content Failure (post-crash only): send values for all pre-crash "
        "and T0, then half post-crash, disable CRC (simulate message content failure) "
        "in post-crash, continue simulation till end, verify EDR latches values as "
        "expected after fault, and DTCs are set."
    )

    # ── Signal definition ──────────────────────────────────────────────
    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_3_values"]
    edr_param = signal_def["EDR_Parameter"]
    veh_edr_def = next(
        (p for p in get_edr_parameters() if p.get("name") == edr_param), None
    )
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # ── CRC / Message-content-failure specifics (direct from config) ──
    fault_logic = signal_def["fault_logic"]
    key_message = fault_logic.get("key_message")
    mcf_dtcs = fault_logic.get("message_content_failure_dtcs", {})

    crc_frame = signal_def["frame"]
    crc_ch = signal_def["ch"]

    crc_signal_name = None
    crc_dtc_value = None
    for dtc_key, dtc_val in mcf_dtcs.items():
        if "CRC" in dtc_key.upper():
            crc_signal_name = dtc_key
            crc_dtc_value = dtc_val
            break

    if not crc_signal_name:
        raise ValueError(
            f"No CRC entry in message_content_failure_dtcs for '{sig}'. "
            f"Available: {list(mcf_dtcs.keys())}"
        )

    combined_can_dtc_final = crc_dtc_value + " " + DTC_status["DTC_active_WLOFF"]

    print(f"Key message: {key_message}")
    print(f"CRC signal to disable: {crc_signal_name} on frame {crc_frame} ch {crc_ch}")
    print(f"Message content failure DTC: {crc_dtc_value}")
    print(f"Combined DTC (with WLOFF): {combined_can_dtc_final}")

    # ── Report / logging setup ─────────────────────────────────────────
    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file, can_ids=can_ids, direct_write=False
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # ── Time axis ──────────────────────────────────────────────────
        time_axis, T0_INDEX = build_time_axis_and_t0(
            edr_param, crash_type, RSU_T0_OFFSETS
        )
        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX
        )
        trigger_idx = t0_sample_idx - 1

        sample_interval_s = sample_interval_ms / 1000.0
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # ── Post-crash disable index (T0 + half of post-crash samples) ─
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        t0_index = next(
            (i for i, s in enumerate(sample_range) if abs(s) < 1e-9),
            len(pre_crash_samples),
        )
        post_crash_samples = [s for s in sample_range if s > 0]
        num_post_crash = len(post_crash_samples)

        disable_index = t0_index + (num_post_crash // 2)
        if disable_index >= len(values):
            disable_index = len(values) - 1
        if disable_index <= t0_index:
            disable_index = t0_index + 1

        latched_raw = (
            values[disable_index] if disable_index < len(values) else values[-1]
        )

        # Debug prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Post-crash samples (positive time): {post_crash_samples}")
        print(f"Number of post-crash samples: {num_post_crash}")
        print(f"T0 index: {t0_index}")
        print(
            f"Disable index (fault induced at, in post-crash): {disable_index}"
        )
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(
            f"Time at disable_index: "
            f"{time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}"
        )
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"{sig} {tc_id}: Send values for all samples, "
            f"disable CRC '{crc_signal_name}' on frame '{crc_frame}' at post-crash "
            f"index {disable_index}, verify EDR latches values after fault."
        )
        disabled_done = False

        # ── Simulation loop ────────────────────────────────────────────
        for idx, val in enumerate(values):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = (
                time_axis[idx]
                if idx < len(time_axis)
                else (idx * sample_interval_s)
            )

            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = (
                    int(received_val, 16)
                    if isinstance(received_val, str)
                    and received_val.startswith("0x")
                    else int(received_val)
                )
            except Exception:
                received_val_int = int(received_val)

            if not disabled_done:
                fault_status = ""
            else:
                fault_status = " [Message Content Failure Active - ECU latching]"

            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, "
                f"simulated from {simulation_start_time}s to {recording_time}s, "
                f"recorded at {recording_time}s){fault_status}",
                str(received_val_int),
                str(value_to_send),
            )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s)"
                f"{fault_status}",
                str(received_phys),
                str(expected_phys),
            )

            # ── Trigger crash one sample before T0 ─────────────────────
            if idx == trigger_idx:
                TriggerCrash()
                continue

            # ── Induce fault: disable CRC at post-crash disable index ──
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(
                    f"Disabling CRC signal '{crc_signal_name}' on frame "
                    f"'{crc_frame}' ch {crc_ch} at index {disable_index} "
                    f"(simulated from {simulation_start_time}s to "
                    f"{recording_time}s) to simulate message content failure "
                    f"in post-crash samples."
                )
                RESULT.InsertComment(
                    f"ECU will latch value {latched_raw} "
                    f"(physical: {latched_raw * factor + offset}) "
                    f"for remaining samples."
                )
                RESULT.InsertComment(
                    "CAN simulation continues with actual values, "
                    "but ECU will reject frames due to CRC failure."
                )
                CAN.DynamicDisableSignal(crc_frame,crc_signal_name)
                disabled_done = True

        # ── Post-simulation DTC verification ───────────────────────────
        Sleep(1)


        Sleep(6)
        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC(
            "Front Crash ",
            Read_DTC_Resp + " " + final_combined_dtc,
            Read_DTC_Req,
        )
        aria_reports.close_group()

        # ── EDR readout ────────────────────────────────────────────────
        Sleep(5)
        edr_read = read_edr_parameters(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = (
                edr_read.get("decoded", {}).get(edr_param, []) or []
            )

        scaling = veh_edr_def.get("scaling_factor", 1) if veh_edr_def else 1
        offset_edr = veh_edr_def.get("offset", 0) if veh_edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        # ── EDR verification ───────────────────────────────────────────
        aria_reports.add_group(
            "EDR Output Verification - Message Content Failure (Post-Crash)"
        )
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    f"{sig} Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue

            observed = decoded_samples[i]
            recording_time = (
                time_axis[i]
                if i < len(time_axis)
                else (i * sample_interval_s)
            )
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            else:
                expected_phys = expected_phys_latched
                description = "latched value (message content failure active)"

            RESULT.InterpretEqualResult(
                f"{edr_param} recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to "
                f"{recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys),
            )
        aria_reports.close_group()

    # ── Cleanup ────────────────────────────────────────────────────────
    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.DynamicEnableSignal(crc_frame,crc_signal_name)
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
