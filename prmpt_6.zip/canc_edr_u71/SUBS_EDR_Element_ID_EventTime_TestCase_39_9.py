# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
    Under_Voltage,
    Over_Voltage,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    enter_ext_session,
    Internal_Security_Access,
    manage_variant_code,
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *
from Framework_IOEM_Py.projects.U171.config.variantcode_config import *



def run_test():
    tc_id = "39.9"
    tc_desc = 'Verify EDR records the latched EventTime value when over-voltage is induced before crash.'

    signal_def = MAH_CAN_SIGNAL_DEFS["EventTime"]
    msg = signal_def["frame"]
    signals = signal_def.get("signals") or str(signal_def["signal"]).split("/")
    values = signal_def["TestCase_39_values"]
    edr_param = signal_def.get("EDR_Parameter", "EventTime")
    edr_parameters = get_edr_parameters()
    event_params = ['EventTime_Hour', 'EventTime_Min', 'EventTime_Sec']

    if not any(param.get("name") == event_params[0] for param in edr_parameters):
        edr_parameters.extend([
                {"name": "EventTime_Hour", "range": 22, "type": "int"},
                {"name": "EventTime_Min", "range": 23, "type": "int"},
                {"name": "EventTime_Sec", "range": 24, "type": "int"},
            ])

    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(
        test_case_file,
        can_ids=can_ids,
        direct_write=False,
    )

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    crash_type = CRASH_TYPES[0] if CRASH_TYPES else "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        hour_val, minute_val = values[x] if x < len(values) else values[-1]

        aria_reports.add_group(f"EventTime Test Iteration {x + 1} - DID 0x{did}")

        
        load_crash_curves(crash_type)
        CAN.ChangeSignalValue(msg, signals[0], str(hour_val))
        CAN.ChangeSignalValue(msg, signals[1], str(minute_val))
        Wait(sample_interval_ms)

        received_hour = CAN.GetSignalFromFrame(msg, signals[0])
        received_minute = CAN.GetSignalFromFrame(msg, signals[1])
        try:
            received_hour_int = int(received_hour, 16) if isinstance(received_hour, str) and received_hour.lower().startswith("0x") else int(received_hour)
        except Exception:
            received_hour_int = int(received_hour)
        try:
            received_minute_int = int(received_minute, 16) if isinstance(received_minute, str) and received_minute.lower().startswith("0x") else int(received_minute)
        except Exception:
            received_minute_int = int(received_minute)
        RESULT.InterpretEqualResult(f"Check {signals[0]} set for DID 0x{did}", str(received_hour_int), str(int(hour_val)))
        RESULT.InterpretEqualResult(f"Check {signals[1]} set for DID 0x{did}", str(received_minute_int), str(int(minute_val)))
        combined_fault_dtc = Over_Voltage + " " + DTC_status["DTC_active"]
        RESULT.InsertComment("Inducing over-voltage fault.")
        PS.SetVoltage(20.0)

        TriggerCrash()
        Sleep(3)

        combineDTC = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + combineDTC + " " + combined_fault_dtc, Read_DTC_Req)

        Sleep(5)

        edr_read = read_edr_parameters(event_params, did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_map = edr_read.get("decoded", {}) if isinstance(edr_read, dict) else {}
        decoded_hour_values = decoded_map.get("EventTime_Hour", []) or []
        decoded_min_values = decoded_map.get("EventTime_Min", []) or []
        decoded_sec_values = decoded_map.get("EventTime_Sec", []) or []
        expected_time = f"TIME: {int(hour_val):02}:{int(minute_val):02}:00"
        aria_reports.add_group("EDR Output Verification - Latched Value")
        if decoded_hour_values and decoded_min_values and decoded_sec_values:
            actual_time = f"TIME: {int(decoded_hour_values[0]):02}:{int(decoded_min_values[0]):02}:{int(decoded_sec_values[0]):02}"
            RESULT.InterpretEqualResult(f"Compare simulated EventTime vs decoded EventTime for DID 0x{did}", actual_time, expected_time)
        else:
            RESULT.LogCustomAction("EventTime Decode", f"Missing decoded sample(s): Hour={decoded_hour_values}, Minute={decoded_min_values}, Second={decoded_sec_values}", expected_time, TestStatus.Failed)
        aria_reports.close_group()

        PS.SetVoltage(12.0)
        for signal in signals:
            CAN.ChangeSignalValue(msg, signal, "0")
        CAN.ReloadDefaultPeriodicFrame(msg)
        aria_reports.close_group()

    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()
