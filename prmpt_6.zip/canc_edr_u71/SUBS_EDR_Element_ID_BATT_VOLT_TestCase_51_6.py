# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can,
    physical_to_raw,
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "51.6"
    tc_desc = (
        "To verify EDR recording for BATT_VOLT when Signal Invalid occurs"
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["BATT_VOLT"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    # Use invalid values for this test case (keyed by TestCase number)
    values = signal_def["TestCase_51_Invalid_Values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    # Use resolve_dtc_for_event to get correct DTC for signal_invalid event
    
    signal_invalid_dtc = resolve_dtc_for_event("signal_invalid", msg, sig)
    combined_can_dtc_final = signal_invalid_dtc + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Resolved Signal Invalid DTC for {sig}: {signal_invalid_dtc}, combined with WLOFF status: {combined_can_dtc_final}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Derive time axis and T0 index from definition and RSU offsets
        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX)
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis (one sample interval before recording time)
        sample_interval_s = sample_interval_ms / 1000.0

        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Invalid value to send
        invalid_raw_value = values[0]
        invalid_phys_value = (invalid_raw_value * factor) + offset

        # Debug/verification prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Total samples: {len(time_axis)}")
        print(f"Invalid raw value: 0x{invalid_raw_value:04X} ({invalid_raw_value})")
        print(f"Invalid physical value: {invalid_phys_value}")

        aria_reports.add_group(
            f"BATT_VOLT 51.6: Send invalid value for full duration, "
            f"trigger crash at T0, verify EDR records invalid in all samples. "
            f"DID={did}, Iteration={x+1}"
        )

        # Send invalid value and wait for DTC to be set
        CAN.ChangeSignalValue(msg, sig, str(invalid_raw_value))
        RESULT.InsertComment(
            f"Sending invalid value 0x{invalid_raw_value:04X} (physical: {invalid_phys_value}) "
            f"to simulate Signal Invalid fault."
        )

        # Loop through all samples - simulate entire duration with invalid value
        for idx in range(len(time_axis)):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = (
                time_axis[idx]
                if idx < len(time_axis)
                else (idx * sample_interval_s)
            )

            # Always send invalid value
            value_to_send = invalid_raw_value
            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = (
                    int(received_val, 16)
                    if isinstance(received_val, str) and received_val.startswith("0x")
                    else int(received_val)
                )
            except Exception:
                received_val_int = int(received_val)

            RESULT.InterpretEqualResult(
                f"Check {sig} set to 0x{value_to_send:04X} "
                f"(index {idx}, simulated from {simulation_start_time}s to "
                f"{recording_time}s, recorded at {recording_time}s)",
                str(received_val_int),
                str(value_to_send),
            )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s) - Invalid Value",
                str(received_phys),
                str(expected_phys),
            )

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                continue

        Sleep(1)
        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC(
            "Front Crash",
            Read_DTC_Resp + " " + final_combined_dtc,
            Read_DTC_Req,
        )
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        expected_invalid_raw = invalid_raw_value
        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0
        bits = edr_def.get("data_bit_length", 16) if edr_def else 16

        aria_reports.add_group(
            f"EDR Output Verification - Signal Invalid (Full Crash) DID={did}"
        )
        for i in range(len(time_axis)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    "BATT_VOLT Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue

            observed = decoded_samples[i]
            observed_raw = physical_to_raw(observed, scaling, offset_edr, bits)
            recording_time = (
                time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            )
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            RESULT.InterpretEqualResult(
                f"BATT_VOLT recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to {recording_time:g}s) "
                f"- expected Signal Invalid",
                f"0x{observed_raw:X}",
                f"0x{expected_invalid_raw:X}",
            )
        aria_reports.close_group()

        # Cleanup - restore signal and frame
        CAN.ChangeSignalValue(msg, sig, "0")
        CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()
    aria_reports.close_group()


if __name__ == "__main__":
    run_test()

# display_traceability(34981731)
# display_traceability(34984996)
