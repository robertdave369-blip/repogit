# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── U171 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "3.7"
    tc_desc = (
        "To verify EDR recording for ACC_PED when Signal Invalid occurs only in pre crash"
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_PED"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    valid_values = signal_def["TestCase_3_values"]
    invalid_values = signal_def["TestCase_3_Invalid_Values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)
    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)
    bits = edr_def.get("data_bit_length", 16) if edr_def else 16

    if not isinstance(valid_values, list):
        valid_values = [valid_values]
    if not isinstance(invalid_values, list):
        invalid_values = [invalid_values]

    # Invalid value
    invalid_raw_value = invalid_values[0]

    # Use resolve_dtc_for_event to get correct DTC for signal_invalid event
    
    signal_invalid_dtc = resolve_dtc_for_event("signal_invalid", msg, sig)
    combined_can_dtc_final = signal_invalid_dtc + " " + DTC_status["DTC_active_WLOFF"]
    print(
        f"Resolved Signal Invalid DTC for {sig}: {signal_invalid_dtc}, "
        f"combined with WLOFF status: {combined_can_dtc_final}"
    )

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        time_axis, T0_INDEX = build_time_axis_and_t0(edr_param, crash_type, RSU_T0_OFFSETS)
        t0_sample_idx = next(
            (i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), T0_INDEX
        )
        trigger_idx = t0_sample_idx - 1

        # Calculate simulation time axis
        sample_interval_s = sample_interval_ms / 1000.0
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Pre-crash sample identification (negative time values only)
        sample_range = get_sample_range(edr_param)
        pre_crash_samples = [s for s in sample_range if s < 0]
        num_pre_crash = len(pre_crash_samples)

        # Calculate disable index as half of pre-crash samples
        disable_index = num_pre_crash // 2
        if disable_index >= num_pre_crash:
            disable_index = num_pre_crash - 1
        if disable_index < 0:
            disable_index = 0

        last_valid_raw = (
            valid_values[disable_index]
            if disable_index < len(valid_values)
            else valid_values[-1]
        )

        # Debug prints
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"Sample range: {sample_range}")
        print(f"Pre-crash samples (negative time): {pre_crash_samples}")
        print(f"Number of pre-crash samples: {num_pre_crash}")
        print(f"Disable index (invalid value starts at): {disable_index}")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index (crash triggered at): {trigger_idx}")
        print(
            f"Time at disable_index: "
            f"{time_axis[disable_index] if disable_index < len(time_axis) else 'N/A'}"
        )
        print(f"Invalid raw value: 0x{invalid_raw_value:04X}")
        print(f"Last valid raw value before fault: {last_valid_raw}")

        aria_reports.add_group(
            f"ACC_PED 3.7: Send valid values, then invalid at index "
            f"{disable_index} (pre-crash), send valid values from T0, verify EDR behavior. "
            f"DID={did}, Iteration={x+1}"
        )
        fault_induced = False
        fault_cleared = False

        # Loop through ALL samples
        for idx in range(len(time_axis)):
            simulation_start_time = (
                simulation_time_axis[idx]
                if idx < len(simulation_time_axis)
                else ((idx * sample_interval_s) - sample_interval_s)
            )
            recording_time = (
                time_axis[idx]
                if idx < len(time_axis)
                else (idx * sample_interval_s)
            )

            # Determine value to send:
            # - Before disable_index: send valid values
            # - From disable_index to T0: send invalid value
            # - From T0 onwards: send valid values again (clear fault)
            if idx < disable_index:
                value_to_send = (
                    valid_values[idx] if idx < len(valid_values) else valid_values[-1]
                )
                value_type = "valid"
            elif idx < t0_sample_idx:
                value_to_send = invalid_raw_value
                value_type = "invalid"
            else:
                value_to_send = (
                    valid_values[idx] if idx < len(valid_values) else valid_values[-1]
                )
                value_type = "valid (fault cleared)"

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = (
                    int(received_val, 16)
                    if isinstance(received_val, str) and received_val.startswith("0x")
                    else int(received_val)
                )
            except Exception:
                received_val_int = int(received_val)

            if value_to_send == invalid_raw_value:
                RESULT.InterpretEqualResult(
                    f"Check {sig} set to 0x{value_to_send:04X} - {value_type} "
                    f"(index {idx}, simulated from {simulation_start_time}s to "
                    f"{recording_time}s, recorded at {recording_time}s)",
                    str(received_val_int),
                    str(value_to_send),
                )
            else:
                RESULT.InterpretEqualResult(
                    f"Check {sig} set to {value_to_send} - {value_type} "
                    f"(index {idx}, simulated from {simulation_start_time}s to "
                    f"{recording_time}s, recorded at {recording_time}s)",
                    str(received_val_int),
                    str(value_to_send),
                )

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value "
                f"(simulated from {simulation_start_time}s to {recording_time}s) - {value_type}",
                str(received_phys),
                str(expected_phys),
            )

            # At disable_index: Signal invalid fault is induced
            if not fault_induced and idx == disable_index:
                RESULT.InsertComment(
                    f"Sending invalid value 0x{invalid_raw_value:04X} at index {disable_index} "
                    f"(simulated from {simulation_start_time}s to {recording_time}s) "
                    f"to simulate Signal Invalid fault."
                )
                RESULT.InsertComment(
                    "EDR will record invalid value until valid value is sent again."
                )
                fault_induced = True

            # At trigger_idx: Clear fault by sending valid value and trigger crash
            if idx == trigger_idx:
                RESULT.InsertComment(
                    f"Sending valid value at T0 (simulated from {simulation_start_time}s to "
                    f"{recording_time}s) to clear Signal Invalid fault."
                )
                RESULT.InsertComment(
                    "Post-crash samples will record valid values from simulation."
                )
                fault_cleared = True
                TriggerCrash()
                continue

        Sleep(1)
        combined_crash_dtc = (
            Crash_DTC + " " + DTC_status["DTC_active"]
            + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        )
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC(
            "Front Crash",
            Read_DTC_Resp + " " + final_combined_dtc,
            Read_DTC_Req,
        )
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters(
            [edr_param], did=did, crash_type=crash_type, return_data=True
        )
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0
        bits = edr_def.get("data_bit_length", 16) if edr_def else 16

        # EDR verification:
        # - Samples up to disable_index: actual valid values
        # - Samples from disable_index to T0: invalid value (Signal Invalid)
        # - Samples after T0 (fault cleared): actual valid values
        aria_reports.add_group(
            f"EDR Output Verification - Signal Invalid (Pre-Crash) DID={did}"
        )
        for i in range(len(time_axis)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction(
                    "ACC_PED Decode",
                    f"Missing decoded sample {i}",
                    f"Missing decoded sample {i}",
                    TestStatus.Failed,
                )
                continue

            observed = decoded_samples[i]
            observed_raw = physical_to_raw(observed, scaling, offset_edr, bits)
            recording_time = (
                time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            )
            simulation_start_time = (
                simulation_time_axis[i]
                if i < len(simulation_time_axis)
                else ((i * sample_interval_s) - sample_interval_s)
            )

            if i < disable_index:
                expected_raw = (
                    valid_values[i] if i < len(valid_values) else valid_values[-1]
                )
                desc = "valid value (before fault)"
            elif i < t0_sample_idx:
                expected_raw = invalid_raw_value
                desc = "Signal Invalid (during fault)"
            else:
                expected_raw = (
                    valid_values[i] if i < len(valid_values) else valid_values[-1]
                )
                desc = "valid value (after fault cleared)"

            RESULT.InterpretEqualResult(
                f"ACC_PED recorded at {recording_time:g}s "
                f"(simulated from {simulation_start_time:g}s to {recording_time:g}s) "
                f"- {desc}",
                f"0x{observed_raw:X}",
                f"0x{expected_raw:X}",
            )
        aria_reports.close_group()

    CAN.ChangeSignalValue(msg, sig, "0")
    CAN.ReloadDefaultPeriodicFrame(msg)
    aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()

# display_traceability(34628279)
# display_traceability(34628686)
# display_traceability(34857064)
# display_traceability(34984476)
