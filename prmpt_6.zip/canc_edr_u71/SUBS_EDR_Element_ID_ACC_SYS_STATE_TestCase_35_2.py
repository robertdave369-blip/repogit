# Author: Christy, Krishna

import os
import sys
from pathlib import Path

# ── Make Framework_IOEM_Py importable as a top-level package ─────────────────
_FRAMEWORK_ROOT = Path(__file__).resolve().parents[5]
if str(_FRAMEWORK_ROOT.parent) not in sys.path:
    sys.path.insert(0, str(_FRAMEWORK_ROOT.parent))

# ── ARIA bring-up ────────────────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.apym_imports import (
    ensure_apym_on_path,
    init_aria,
)
ensure_apym_on_path()
init_aria()

from apym.connection import Instance as aria_instance
from apym.reports import ApymReports as aria_reports

# ── Shared library imports ───────────────────────────────────────────────────
from Framework_IOEM_Py.shared_libraries.ascent_batch_lib import RESULT
from Framework_IOEM_Py.shared_libraries.configuration_control import (
    TestStatus,
    Crash_DTC, PT_Crash_DTC, DTC_status,
    Read_DTC_Req, Read_DTC_Resp,
    RSU_T0_OFFSETS,
)
from Framework_IOEM_Py.shared_libraries.crash_configuration import CRASH_TYPES
from Framework_IOEM_Py.shared_libraries.core_functions import (
    Sleep, Wait,
    Read_DTC, TriggerCrash,
    create_report_and_logging,
    resolve_can_log_ids,
    load_crash_curves,
    read_software_version,
    fault_free_profile_classic_can
)
from Framework_IOEM_Py.shared_libraries.data_conversions import (
    get_sample_interval_ms,
    build_time_axis_and_t0,
    get_sample_range,
)
from Framework_IOEM_Py.shared_libraries.edr_decoding_functions import (
    get_edr_parameters,
    read_edr_parameters,
)
from Framework_IOEM_Py.shared_libraries.jscript_translation import CAN, PS

# ── Z121 project configuration ──────────────────────────────────────────────
from Framework_IOEM_Py.projects.U171.config.edr_config import (
    EDR_DIDS,
    EDR_PARAMETERS,
)
from Framework_IOEM_Py.projects.U171.config.canc_config import *


def run_test():
    tc_id = "35.2"
    tc_desc = (
        "ACC_SYS_STATE message-timeout scenario (full duration): send first non-zero value, disable non-key frame "
        "(simulate message timeout), trigger crash at T0, verify EDR latches non-zero value in all samples after fault, and DTCs are set."
    )

    signal_def = MAH_CAN_SIGNAL_DEFS["ACC_SYS_STATE"]
    msg = signal_def["frame"]
    sig = signal_def["signal"]
    periodicity = signal_def["periodicity"]
    values = signal_def["TestCase_35_values"]
    edr_param = signal_def["EDR_Parameter"]
    edr_def = next((p for p in get_edr_parameters() if p.get("name") == edr_param), None)

    # Sampling configuration for ACC_SYS_STATE
    # Recording interval: -3.0s to 2.0s
    # Sample interval: 227ms
    # Total samples: 22
    sample_interval_ms = get_sample_interval_ms(edr_param, default_ms=500)#227

    factor = signal_def.get("Factor", 1)
    offset = signal_def.get("Offset", 0)

    if not isinstance(values, list):
        values = [values]

    fault_logic = signal_def["fault_logic"]
    non_key_frame = fault_logic.get("non_key_timeout_frame")
    
    can_dtc_code = resolve_dtc_for_event("frame_disabled", non_key_frame)
    combined_can_dtc_final = can_dtc_code + " " + DTC_status["DTC_active_WLOFF"]
    print(f"Resolved CAN DTC for frame timeout: {can_dtc_code}, combined with WLOFF status: {combined_can_dtc_final}")

    test_case_file = os.path.splitext(os.path.basename(__file__))[0]
    can_ids = resolve_can_log_ids([signal_def])
    report_path, log_path = create_report_and_logging(test_case_file, can_ids=can_ids, direct_write=False)

    fault_free_profile_classic_can()
    PS.Power_Cycle()
    Sleep(1)
    read_software_version()
    crash_type = "front"

    for x in range(2):
        did = f"{0x455 + (x * 0x6):04X}"
        load_crash_curves(crash_type)

        # Build time axis based on recording interval configuration
        recording_start = -3.0
        recording_end = 2.0
        sample_interval_s = sample_interval_ms / 1000.0

        # Generate time axis from recording start to end
        time_axis = []
        t = recording_start
        while t <= recording_end + 0.001:
            time_axis.append(round(t, 3))
            t += sample_interval_s

        # Determine T0 index (where time = 0)
        t0_sample_idx = next((i for i, t in enumerate(time_axis) if abs(float(t)) < 1e-9), len(time_axis) // 2)
        trigger_idx = t0_sample_idx - 1

        # Build simulation time axis (shifted by one sample interval before recording time axis)
        simulation_time_axis = [t - sample_interval_s for t in time_axis]

        # Find first non-zero value index to disable non-key frame after simulating it
        first_nonzero_index = next((i for i, v in enumerate(values) if int(v) != 0), 0)
        disable_index = first_nonzero_index
        latched_raw = values[disable_index] if disable_index < len(values) else values[-1]

        # Debug/verification prints
        print(f"EDR Parameter: ACC_SYS_STATE")
        print(f"Recording interval: -3.0s to 2.0s")
        print(f"Recording time axis: {time_axis}")
        print(f"Simulation time axis: {simulation_time_axis}")
        print(f"Sample interval: {sample_interval_s}s ({sample_interval_ms}ms)")
        print(f"T0 sample index: {t0_sample_idx}")
        print(f"Trigger index: {trigger_idx}")
        print(f"Disable index: {disable_index}")
        print(f"Latched raw value: {latched_raw}")
        print(f"Total values to simulate: {len(values)}")

        aria_reports.add_group(
            f"ACC_SYS_STATE 35.2: Send first non-zero value, disable non-key frame '{non_key_frame}' (simulate message timeout), trigger crash at T0, verify EDR latches non-zero value in all samples after fault."
        )
        disabled_done = False

        for idx, val in enumerate(values):
            simulation_start_time = simulation_time_axis[idx] if idx < len(simulation_time_axis) else ((idx * sample_interval_s) - sample_interval_s)
            recording_time = time_axis[idx] if idx < len(time_axis) else (idx * sample_interval_s)

            value_to_send = val

            CAN.ChangeSignalValue(msg, sig, str(value_to_send))
            Wait(sample_interval_ms)
            received_val = CAN.GetSignalFromFrame(msg, sig)
            try:
                received_val_int = int(received_val, 16) if isinstance(received_val, str) and received_val.startswith("0x") else int(received_val)
            except Exception:
                received_val_int = int(received_val)
            RESULT.InterpretEqualResult(
                f"Check {sig} set to {value_to_send} (index {idx}, simulated from {simulation_start_time}s to {recording_time}s, recorded at {recording_time}s)",
                str(received_val_int),
                str(value_to_send))

            expected_phys = (value_to_send * factor) + offset
            received_phys = (received_val_int * factor) + offset
            RESULT.InterpretEqualResult(
                f"Check {sig} physical value (simulated from {simulation_start_time}s to {recording_time}s)",
                str(received_phys),
                str(expected_phys))

            # Disable non-key frame (simulate message timeout) immediately after first non-zero sample
            if not disabled_done and idx == disable_index:
                RESULT.InsertComment(f"Disabling CAN frame '{non_key_frame}' at index {disable_index} (simulated from {simulation_start_time}s to {recording_time}s) to simulate message timeout fault.")
                RESULT.InsertComment(f"ECU will latch value {latched_raw} (physical: {latched_raw * factor + offset}) for all remaining samples.")
                CAN.PeriodicDisableFrame(non_key_frame)
                disabled_done = True

            # Trigger crash one sample before T0 (at trigger_idx)
            if idx == trigger_idx:
                TriggerCrash()
                continue

        Sleep(1)
        combined_crash_dtc = Crash_DTC + " " + DTC_status["DTC_active"] + " " + PT_Crash_DTC + " " + DTC_status["DTC_active"]
        final_combined_dtc = combined_crash_dtc + " " + combined_can_dtc_final
        Read_DTC("Front Crash ", Read_DTC_Resp + " " + final_combined_dtc, Read_DTC_Req)
        aria_reports.close_group()

        Sleep(5)
        edr_read = read_edr_parameters([edr_param], did=did, crash_type=crash_type, return_data=True)
        Sleep(2)

        decoded_samples = []
        if isinstance(edr_read, dict):
            decoded_samples = edr_read.get("decoded", {}).get(edr_param, []) or []

        scaling = edr_def.get("scaling_factor", 1) if edr_def else 1
        offset_edr = edr_def.get("offset", 0) if edr_def else 0

        expected_phys_latched = latched_raw * scaling + offset_edr

        aria_reports.add_group("EDR Output Verification - Message Timeout (Full Duration - Latched Value)")
        for i in range(len(values)):
            if i >= len(decoded_samples):
                RESULT.LogCustomAction("ACC_SYS_STATE Decode", f"Missing decoded sample {i}", f"Missing decoded sample {i}", TestStatus.Failed)
                continue
            observed = decoded_samples[i]
            recording_time = time_axis[i] if i < len(time_axis) else (i * sample_interval_s)
            simulation_start_time = simulation_time_axis[i] if i < len(simulation_time_axis) else ((i * sample_interval_s) - sample_interval_s)

            if i <= disable_index:
                expected_phys = values[i] * scaling + offset_edr
                description = "actual value (before/at fault)"
            else:
                expected_phys = expected_phys_latched
                description = "latched value (after message timeout fault)"

            RESULT.InterpretEqualResult(
                f"ACC_SYS_STATE recorded at {recording_time:g}s (simulated from {simulation_start_time:g}s to {recording_time:g}s) - {description}",
                str(observed),
                str(expected_phys)
            )
        aria_reports.close_group()

        CAN.ChangeSignalValue(msg, sig, "0")
        CAN.ReloadDefaultPeriodicFrame(non_key_frame)
    aria_reports.write_to_file()
    aria_reports.close_group()

if __name__ == "__main__":
    run_test()

# # display_Tracability(34974759,34984870)
