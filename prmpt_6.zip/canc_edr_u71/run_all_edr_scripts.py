import argparse
import json
import os
import subprocess
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent

# Edit this list to choose which scripts run.
# To skip a script, comment that line with #.
# To run all scripts, leave all filenames uncommented.
SCRIPT_FILES = [

    # --- Param 1: Vehicle Speed ---
    # "SUBS_EDR_Element_ID_LifeTimeEventNb_TestCase_1.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_1.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_2.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_3.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_4.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_5.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_6.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_7.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_8.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_9.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_10.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_11.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_12.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_13.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_14.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_15.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_16.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_17.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_18.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_19.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_20.py",
    "SUBS_EDR_Element_ID_VehSpdLgt_TestCase_1_21.py",

    # --- Param 2: Brake Switch ---
    # "SUBS_EDR_Element_ID_Crash_Parameters_TestCase_2.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_1.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_2.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_3.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_4.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_5.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_6.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_7.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_8.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_9.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_10.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_11.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_12.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_13.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_14.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_15.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_16_MCF_Full.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_17_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_18_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_19.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_20.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_21.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_22.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_23.py",
    "SUBS_EDR_Element_ID_BRK_SWITCH_TestCase_2_24.py",

    # --- Param 3: Accelaration Pedal ---
    # "SUBS_EDR_Element_ID_Batt_Volt_TestCase_3.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_1.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_2.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_3.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_4.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_5.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_6.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_7.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_8.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_9.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_10.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_11.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_12.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_16.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_17.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_18.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_19.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_20.py",
    "SUBS_EDR_Element_ID_ACC_PED_TestCase_3_21.py",

    # --- Param 4: Motor Speed ---
    # "SUBS_EDR_Element_ID_MalFuntion_TestCase_4.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_1.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_2.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_3.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_4.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_5.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_6.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_7.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_8.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_9.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_10.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_11.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_12.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_16.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_17.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_18.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_19.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_20.py",
    "SUBS_EDR_Element_ID_MOTOR_SPD_TestCase_4_21.py",

    # --- Param 5: IGNCycle ---
    # "SUBS_EDR_Element_ID_IGNCycle_TestCase_5.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_1.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_2.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_3.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_4.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_5.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_6.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_7.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_8.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_9.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_10.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_11.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_12.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_13.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_14.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_15.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_16_MCF_Full.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_17_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_18_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_19.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_20.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_21.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_22.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_23.py",
    "SUBS_EDR_Element_ID_ABSOLUTE_ANGLE_TestCase_5_24.py",

    # --- Param 6: PADILamp ---
    # "SUBS_EDR_Element_ID_PADILamp_TestCase_6.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_1.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_2.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_3.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_4.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_5.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_6.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_7.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_8.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_9.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_10.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_11.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_12.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_13.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_14.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_15.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_16.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_17.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_18.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_19.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_20.py",
    "SUBS_EDR_Element_ID_GEAR_ACTUAL_TestCase_6_21.py",

    # --- Param 7: DCS ---
    # "SUBS_EDR_Element_ID_DCS_TestCase_7.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_1.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_1.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_2.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_3.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_4.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_5.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_6.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_7.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_8.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_TestCase_7_9.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_13.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_14.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_15.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_16.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_18.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_19.py",
    "SUBS_EDR_Element_ID_VehSpdLgtAtTimeZero_in_CANWAKEUP_TestCase_7_20.py",

    # --- Param 8: Velocity ---
    # "SUBS_EDR_Element_ID_Velocity_TestCase_8.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_1.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_Odometer_TestCase_8_2.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_3.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_4.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_5.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_6.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_7.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_8.py",
    "SUBS_EDR_Element_ID_Odometer_TestCase_8_9.py",

    # --- Param 9: VEHICLE_STATE ---
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_1.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_2.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_3.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_4.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_5.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_6.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_7.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_8.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['VEHICLE_STATE'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_VEHICLE_STATE_TestCase_9_9.py",

    # --- Param 10: STS_ENG ---
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_1.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_2.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_3.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_4.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_5.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_6.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_7.py",
    "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_8.py",
    # N/A (no MAH_CAN_SIGNAL_DEFS['CAN_STS_ENG'] (param not configured / not applicable)):
    # "SUBS_EDR_Element_ID_STS_ENG_TestCase_10_11_MCF_Full.py",

    # --- Param 11: DoorOpenStatus ---
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_1.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_2.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_3.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_4.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_5.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_6.py",
    "SUBS_EDR_Element_ID_DoorOpenStatus_TestCase_11_7.py",

    # --- Param 12: Clutch_Sts ---
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_1.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_2.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_3.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_4.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_5.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_6.py",
    "SUBS_EDR_Element_ID_Clutch_Sts_TestCase_12_7.py",

    # --- Param 13: ABS_Active ---
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_1.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_2.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_3.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_4.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_5.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_6.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_7.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_8.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_9.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_10.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_11.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_12.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_13.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_14.py",
    "SUBS_EDR_Element_ID_ABS_Active_TestCase_13_15.py",

    # --- Param 14: ESC_Active ---
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_1.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_2.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_3.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_4.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_5.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_6.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_7.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_8.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_9.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_10.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_11.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_12.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_13.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_14.py",
    "SUBS_EDR_Element_ID_ESC_Active_TestCase_14_15.py",

    # --- Param 15: STS_TPMS_LED ---
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_1.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_2.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_3.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_4.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_5.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_6.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_7.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_8.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_9.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_10.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_11.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_12.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_13.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_14.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_15.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_16.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_17.py",
    "SUBS_EDR_Element_ID_STS_TPMS_LED_TestCase_15_18.py",

    # --- Param 16: Door_Lock_Status ---
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_1.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_2.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_3.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_4.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_5.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_6.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_7.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_8.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_9.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_10.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_11.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_12.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_13.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_14.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_15.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_16.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_17.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_18.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_19.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_20.py",
    "SUBS_EDR_Element_ID_Door_Lock_Status_TestCase_16_21.py",

    # --- Param 17: TCS_ACTIVE_IEB ---
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_1.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_2.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_3.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_4.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_5.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_6.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_7.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_8.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_9.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_10.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_11.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_12.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_13.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_14.py",
    "SUBS_EDR_Element_ID_TCS_ACTIVE_IEB_TestCase_17_15.py",

    # --- Param 18: AEB_WARNING_MSG1 ---
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_1.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_2.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_3.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_4.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_5.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_6.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_7.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_8.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_9.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_10.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_11.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_12.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_13.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_14.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_15.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_16.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_17.py",
    "SUBS_EDR_Element_ID_AEB_WARNING_MSG1_TestCase_18_18.py",

    # --- Param 19: AEB_FCTA_WARN ---
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_1.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_4.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_5.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_6.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_7.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_8.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_9.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_10.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_11.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_12.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_13.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_14.py",
    "SUBS_EDR_Element_ID_AEB_FCTA_WARN_TestCase_19_15.py",

    # --- Param 20: AES_WARNING1 ---
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_1.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_2.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_3.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_4.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_5.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_6.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_7.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_8.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_9.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_10.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_11.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_12.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_13.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_14.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_15.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_16.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_17.py",
    "SUBS_EDR_Element_ID_AES_WARNING1_TestCase_20_18.py",

    # --- Param 21: AES_SYS_STS1 ---
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_1.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_2.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_3.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_4.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_5.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_6.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_7.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_8.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_9.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_10.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_11.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_12.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_13.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_14.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_15.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_16.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_17.py",
    "SUBS_EDR_Element_ID_AES_SYS_STS1_TestCase_21_18.py",

    # --- Param 22: ESA_SYS_STS1 ---
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_1.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_2.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_3.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_4.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_5.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_6.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_7.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_8.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_9.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_10.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_11.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_12.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_13.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_14.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_15.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_16.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_17.py",
    "SUBS_EDR_Element_ID_ESA_SYS_STS1_TestCase_22_18.py",

    # --- Param 23: LDW_LKA_WARNING1 ---
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_1.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_2.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_3.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_4.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_5.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_6.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_7.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_8.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_9.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_10.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_11.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_12.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_13.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_14.py",
    "SUBS_EDR_Element_ID_LDW_LKA_WARNING1_TestCase_23_15.py",

    # --- Param 24: LDW_LKA_SYS_STATE1 ---
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_1.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_2.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_3.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_4.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_5.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_6.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_7.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_8.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_9.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_10.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_11.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_12.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_13.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_14.py",
    "SUBS_EDR_Element_ID_LDW_LKA_SYS_STATE1_TestCase_24_15.py",

    # --- Param 25: LKA_HANDSOFF_DISPLAY_WARNING1 ---
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_1.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_2.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_3.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_4.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_5.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_6.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_7.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_8.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_9.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_10.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_11.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_12.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_13.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_14.py",
    "SUBS_EDR_Element_ID_LKA_HANDSOFF_DISPLAY_WARNING1_TestCase_25_15.py",

    # --- Param 26: LCF_SYS_STATE1 ---
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_1.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_2.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_3.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_4.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_5.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_6.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_7.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_8.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_9.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_10.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_11.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_12.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_13.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_14.py",
    "SUBS_EDR_Element_ID_LCF_SYS_STATE1_TestCase_26_15.py",

    # --- Param 27: SPA_SYS_STATE1 ---
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_1.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_2.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_3.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_4.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_5.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_6.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_7.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_8.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_9.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_10.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_11.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_12.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_13.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_14.py",
    "SUBS_EDR_Element_ID_SPA_SYS_STATE1_TestCase_27_15.py",

    # --- Param 28: SPA_LCF_HANDS_OFF_WARNING1 ---
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_1.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_2.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_3.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_4.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_5.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_6.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_7.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_8.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_9.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_10.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_11.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_12.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_13.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_14.py",
    "SUBS_EDR_Element_ID_SPA_LCF_HANDS_OFF_WARNING1_TestCase_28_15.py",

    # --- Param 29: NP_SYS_STS1 ---
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_1.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_2.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_3.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_4.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_5.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_6.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_7.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_8.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_9.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_10.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_11.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_12.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_13.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_14.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_15.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_16.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_17.py",
    "SUBS_EDR_Element_ID_NP_SYS_STS1_TestCase_29_18.py",

    # --- Param 30: RMS_MODE_STATE1 ---
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_1.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_2.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_3.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_4.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_5.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_6.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_7.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_8.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_9.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_10.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_11.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_12.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_13.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_14.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_15.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_16.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_17.py",
    "SUBS_EDR_Element_ID_RMS_MODE_STATE1_TestCase_30_18.py",

    # --- Param 31: LC_PATH_STATE1 ---
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_1.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_2.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_3.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_4.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_5.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_6.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_7.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_8.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_9.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_10.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_11.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_12.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_13.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_14.py",
    "SUBS_EDR_Element_ID_LC_PATH_STATE1_TestCase_31_15.py",

    # --- Param 32: ELK_ONCOMING_WARNING1 ---
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_1.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_2.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_3.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_4.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_5.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_6.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_7.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_8.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_9.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_10.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_11.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_12.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_13.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_14.py",
    "SUBS_EDR_Element_ID_ELK_ONCOMING_WARNING1_TestCase_32_15.py",

    # --- Param 33: ELK_SIDE_WARNING1 ---
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_1.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_2.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_3.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_4.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_5.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_6.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_7.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_8.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_9.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_10.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_11.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_12.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_13.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_14.py",
    "SUBS_EDR_Element_ID_ELK_SIDE_WARNING1_TestCase_33_15.py",

    # --- Param 34: ELK_OVERTAKING_WARNING1 ---
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_1.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_2.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_3.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_4.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_5.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_6.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_7.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_8.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_9.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_10.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_11.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_12.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_13.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_14.py",
    "SUBS_EDR_Element_ID_ELK_OVERTAKING_WARNING1_TestCase_34_15.py",

    # --- Param 35: ACC_SYS_STATE ---
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_1.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_2.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_3.py",
    # N/A (MTO not applicable (no non-key slave frame to time out)):
    # "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_4.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_5.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_6.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_7.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_8.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_9.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_10.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_11.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_12.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_13.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_14.py",
    "SUBS_EDR_Element_ID_ACC_SYS_STATE_TestCase_35_15.py",

    # --- Param 36: STS_HIGH_BEAM ---
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_1.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_2.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_3.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_4.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_5.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_6.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_7.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_8.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_9.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_10.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_11.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_12.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_13.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_14.py",
    "SUBS_EDR_Element_ID_STS_HIGH_BEAM_TestCase_36_15.py",

    # --- Param 37: STS_LOW_BEAM ---
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_1.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_2.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_3.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_4.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_5.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_6.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_7.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_8.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_9.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_10.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_11.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_12.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_13.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_14.py",
    "SUBS_EDR_Element_ID_STS_LOW_BEAM_TestCase_37_15.py",

    # --- Param 38: EventDt ---
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_1.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_2.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_3.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_5.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_6.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_EventDt_TestCase_38_7_MCF_Full.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_8.py",
    "SUBS_EDR_Element_ID_EventDt_TestCase_38_9.py",

    # --- Param 39: EventTime ---
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_1.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_2.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_3.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_5.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_6.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_EventTime_TestCase_39_7_MCF_Full.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_8.py",
    "SUBS_EDR_Element_ID_EventTime_TestCase_39_9.py",

    # --- Param 40: Engine_Speed ---
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_1.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_2.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_3.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_4.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_5.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_6.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_7.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_8.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_9.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_10.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_11.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_12.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_16.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_17.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_18.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_19.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_20.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_21.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_28.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_29.py",
    "SUBS_EDR_Element_ID_Engine_Speed_TestCase_40_30.py",

    # --- Param 41: STEERING_ABSOLUTE_ANGLE ---
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_1.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_2.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_3.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_4.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_5.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_6.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_7.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_8.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_9.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_10.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_11.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_12.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_16.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_17.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_18.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_19.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_20.py",
    "SUBS_EDR_Element_ID_STEERING_ABSOLUTE_ANGLE_TestCase_41_21.py",

    # --- Param 42: Tyre_Pressure_FL ---
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_1.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_2.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_3.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_4.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_5.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_6.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_7.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_8.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_9.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_10.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_11.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_16.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_17.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_18.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_19.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_20.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FL_TestCase_42_21.py",

    # --- Param 43: Tyre_Pressure_FR ---
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_1.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_2.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_3.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_4.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_5.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_6.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_7.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_8.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_9.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_10.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_11.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_16.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_17.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_18.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_19.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_20.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_FR_TestCase_43_21.py",

    # --- Param 44: Tyre_Pressure_RL ---
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_1.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_2.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_3.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_4.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_5.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_6.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_7.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_8.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_9.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_10.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_11.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_16.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_17.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_18.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_19.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_20.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RL_TestCase_44_21.py",

    # --- Param 45: Tyre_Pressure_RR ---
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_1.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_2.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_3.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_4.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_5.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_6.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_7.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_8.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_9.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_10.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_11.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_16.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_17.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_18.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_19.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_20.py",
    "SUBS_EDR_Element_ID_Tyre_Pressure_RR_TestCase_45_21.py",

    # --- Param 46: Master_Cylinder_Pressure ---
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_1.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_2.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_3.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_4.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_5.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_6.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_7.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_8.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_9.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_10.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_11.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_16.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_17.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_18.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_19.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_20.py",
    "SUBS_EDR_Element_ID_Master_Cylinder_Pressure_TestCase_46_21.py",

    # --- Param 47: YAW_RATE ---
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_1.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_2.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_3.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_4.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_5.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_6.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_7.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_8.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_9.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_10.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_11.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_12.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_16.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_17.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_18.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_19.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_20.py",
    "SUBS_EDR_Element_ID_YAW_RATE_TestCase_47_21.py",

    # --- Param 48: LATERAL_ACCEL ---
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_1.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_2.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_3.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_4.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_5.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_6.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_7.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_8.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_9.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_10.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_11.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_12.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_16.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_17.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_18.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_19.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_20.py",
    "SUBS_EDR_Element_ID_LATERAL_ACCEL_TestCase_48_21.py",

    # --- Param 49: LONG_ACCEL ---
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_1.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_2.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_3.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_4.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_5.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_6.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_7.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_8.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_9.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_10.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_11.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_12.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_13_MCF_Full.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_14_MCF_PreCrash.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_16.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_17.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_18.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_19.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_20.py",
    "SUBS_EDR_Element_ID_LONG_ACCEL_TestCase_49_21.py",

    # --- Param 50: ADAS_Des_StrWhl_Angle_Cmd ---
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_1.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_2.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_3.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_4.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_5.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_6.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_7.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_8.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_9.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_10.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_11.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_16.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_17.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_18.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_19.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_20.py",
    "SUBS_EDR_Element_ID_ADAS_Des_StrWhl_Angle_Cmd_TestCase_50_21.py",

    # --- Param 51: BATT_VOLT ---
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_1.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_2.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_3.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_4.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_5.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_6.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_7.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_8.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_9.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_10.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_11.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_12.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_13_MCF_Full.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_14_MCF_PreCrash.py",
    # N/A (MCF not applicable (frame has no CRC/alive-counter signal)):
    # "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_15_MCF_PostCrash.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_16.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_17.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_18.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_19.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_20.py",
    "SUBS_EDR_Element_ID_BATT_VOLT_TestCase_51_21.py",

    # --- Non-CANC sensor/additional cases (left disabled) ---
    # "EDR_Element_IDs_DeltavLateral_13.py",
    # "EDR_Element_IDs_DeltavLateral_14.py",
    # "EDR_Element_IDs_DeltavLatteral_08.py",
    # "EDR_Element_IDs_DeltavLatteral_09.py",
    # "EDR_Element_IDs_DeltavLatteral_10.py",
    # "EDR_Element_IDs_DeltavLatteral_11.py",
    # "EDR_Element_IDs_DeltavLatteral_12.py",
    # "EDR_Element_IDs_DeltavLongitudinal_01.py",
    # "EDR_Element_IDs_DeltavLongitudinal_02.py",
    # "EDR_Element_IDs_DeltavLongitudinal_03.py",
    # "EDR_Element_IDs_DeltavLongitudinal_04.py",
    # "EDR_Element_IDs_DeltavLongitudinal_05.py",
    # "EDR_Element_IDs_DeltavLongitudinal_06.py",
    # "EDR_Element_IDs_DeltavLongitudinal_07.py",
    # "SUBS_EDR_MultiEvent_NearCrash_NearCrash_Deployment.py",
    # "SUBS_EDR_MultiEvent_NearCrash_NearCrash_NearCrash.py",
    # "SUBS_EDR_PARAMETERS.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_CommFault.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_ConfigFault.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_InternalFault.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_OpenFault.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_OutOfRange.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_S2B.py",
    # "TC_EDR_Front_Crash_CTx_FRSU_Negative_OtherRSU_S2G.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_CommFault.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_ConfigFault.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_InternalFault.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_OpenFault.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_OutOfRange.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_S2B.py",
    # "TC_EDR_Left_Crash_Side_Negative_OtherRSU_S2G.py",
    # "TC_EDR_Rear_Crash_RSU_CTx_Positive_OtherRSU_OutOfRange.py",
    # "TC_EDR_Right_Crash_Side_Positive_OtherRSU_OutOfRange.py",
]


def get_python_scripts():
    scripts = []
    missing_files = []

    for script_name in SCRIPT_FILES:
        script_path = SCRIPT_DIR / script_name
        if script_path.is_file():
            scripts.append(script_path)
        else:
            missing_files.append(script_name)

    if missing_files:
        print("Missing script file(s) listed in SCRIPT_FILES:")
        for script_name in missing_files:
            print(f"- {script_name}")
        print()

    return scripts


def build_environment():
    env = os.environ.copy()
    framework_root = SCRIPT_DIR.parents[4]
    import_root = framework_root.parent
    existing_pythonpath = env.get("PYTHONPATH")

    if existing_pythonpath:
        env["PYTHONPATH"] = str(import_root) + os.pathsep + existing_pythonpath
    else:
        env["PYTHONPATH"] = str(import_root)

    return env


def run_script(script_path: Path, env):
    print("=" * 100)
    print(f"Running: {script_path.name}")
    print("=" * 100)

    completed = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(SCRIPT_DIR),
        env=env,
        capture_output=True,
        text=True,
    )

    if completed.stdout:
        print(completed.stdout, end="")
    if completed.stderr:
        print(completed.stderr, end="", file=sys.stderr)

    if completed.returncode == 0:
        print(f"PASSED: {script_path.name}")
    else:
        print(f"FAILED: {script_path.name} (exit code {completed.returncode})")

    return completed


def parse_args():
    parser = argparse.ArgumentParser(
        description="Run selected Python scripts from SCRIPT_FILES one by one."
    )
    parser.add_argument(
        "--stop-on-fail",
        action="store_true",
        help="Stop immediately when a script fails.",
    )
    parser.add_argument(
        "--failure-json",
        default=str(SCRIPT_DIR / "run_all_edr_failures.json"),
        help="Path to write JSON report with failed script terminal outputs.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    scripts = get_python_scripts()

    if not scripts:
        print("No scripts selected. Uncomment at least one filename in SCRIPT_FILES.")
        return 0

    env = build_environment()
    failures = []
    completed_count = 0

    print(f"Selected {len(scripts)} script(s) to run in: {SCRIPT_DIR}")

    for index, script_path in enumerate(scripts, start=1):
        print(f"\n[{index}/{len(scripts)}]")
        completed = run_script(script_path, env)
        return_code = completed.returncode
        completed_count += 1

        if return_code != 0:
            failures.append(
                {
                    "script": script_path.name,
                    "exit_code": return_code,
                    "stdout": completed.stdout,
                    "stderr": completed.stderr,
                }
            )
            if args.stop_on_fail:
                break

    report = {
        "script_dir": str(SCRIPT_DIR),
        "total_selected": len(scripts),
        "completed": completed_count,
        "passed": completed_count - len(failures),
        "failed": len(failures),
        "failures": failures,
    }
    with open(args.failure_json, "w", encoding="utf-8") as fp:
        json.dump(report, fp, indent=2, ensure_ascii=False)
    print(f"\nFailure JSON written to: {args.failure_json}")

    print("\n" + "=" * 100)
    print("Run summary")
    print("=" * 100)
    print(f"Total selected: {len(scripts)}")
    print(f"Completed: {completed_count}")
    print(f"Passed: {completed_count - len(failures)}")
    print(f"Failed: {len(failures)}")

    if failures:
        print("\nFailed scripts:")
        for failure in failures:
            print(f"- {failure['script']}: exit code {failure['exit_code']}")
        return 1

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
