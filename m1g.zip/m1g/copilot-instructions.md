# Copilot instructions - Framework_IOEM_Py (Mahindra SC3 2S Airbag ECU test framework)

> **Review copy.** This file integrates the repository instruction file and the supplied
> instruction file. Review it before replacing the active `copilot-instructions.md`.

## Interpretation and source reconciliation

- This file routes work; it does not replace the detailed engineering sources. Open the
  applicable referenced section before reaching a conclusion. Do not rely on memory when a
  source can be checked.
- **The canonical knowledge base is `.github\agents\agent_sc3.md`.** A legacy source referred
  to `agent_sc3.md` at the repository root; that file is not present. Interpret all references
  to `agent_sc3.md` in this document as `.github\agents\agent_sc3.md`.
- ARIA configuration guidance is `.github\agents\aria_agent.md`. EDR CAN-C on-fail validity
  guidance is `.github\agents\canc_onfail.md`. Operating and troubleshooting the ARIA bench is
  `.github\agents\aria-bench.agent.md`. A test-execution task (Codebeamer or manager task through
  bench run, triage, bug list and PTC push) is `.github\agents\test-execution-pipeline.agent.md`
  (prompt `/run-test-task`). Requirement review vs the customer L10: `requirement-review-pipeline`
  (`/review-requirements`). Writing test cases / adding traceability in the Codebeamer format:
  `test-case-writer-pipeline` (`/write-test-cases`). Reviewing existing test cases against
  requirements, L10, DBC and diag spec: `test-case-review-pipeline` (`/review-test-cases`).
  Reviewing HTML/XML reports and CAN logs:
  `report-review-pipeline` (`/review-test-results`). Their shared rules (automatic installs,
  keep-awake while locked, gates): `.github\agents\pipelines-common.md`.
- Instructions in a matching `.github\instructions\*.instructions.md` file are more specific
  than this file and must be followed.
- `shared_libraries\` and `projects\` are protected: do not add, delete, rename, or edit
  anything below either path. This includes a new wrapper. If a task genuinely requires a
  wrapper that does not exist, stop, describe the Section 18.4 project-agnostic proposal, and
  explain that it requires a protected-path policy decision. Do not create it under this
  instruction set.
- Policy decisions on protected paths (user, 2026-10-26, decisions.md D-2026-10-26-20): the
  `test-execution-pipeline` agent may correct **test scripts only**
  (`projects\<p>\modules\**\scripts\*.py`), only through its S11 step — git commit of the
  current file first, a `.bak-<time>` backup, the same file name. Config, generator-owned files
  and `shared_libraries\` stay protected. `shared_libraries\apym_imports.py` received one
  approved change (API-level fallback, `docs\improvements\apym-level-fallback.md`).

## Core engineering and evidence rules

- Operate under `agent_sc3.md` Section 0 at all times. Prefer engineering quality over speed.
- Treat requirements, tests, code, documents, DBC files, and diagnostic data as potentially
  wrong. Verify independently; the existence of a document is not proof that it is correct.
- Every conclusion must include evidence, or the exact statement **"Evidence unavailable."**,
  a confidence level from Very High through Unknown, and clear fact versus inference versus
  assumption labelling.
- Follow the Section 0.4 workflow; correlate all relevant documents rather than analysing
  sources in isolation. Report every contradiction with evidence, assess change impact for every
  artifact change, pass the Section 0.11 quality gates, self-review from the Section 0.13
  engineering perspectives, and complete work only when Section 0.15 is satisfied.
- Never invent a requirement ID, DTC, DID, signal, register, parameter, configuration key, or
  shared-library function name. Verify it in the source tracker or file and cite it. If it cannot
  be verified, mark it **UNKNOWN** rather than filling the gap.
- `req\` sources are read-only.
- Never hard-code a channel number, message ID, or timing value in a script. Resolve it from
  configuration; if it is missing, tell the user and propose a maintainable location for it.
- Never modify an existing shared-library wrapper signature.

## Safety and execution boundary

- Writing code is not permission to run it. This repository can actuate real hardware, including
  power, squib deployment, flashing, and irreversible NVM writes.
- Do not execute anything that reaches the bench or ECU unless the user explicitly requested
  execution. Deliver bench-facing scripts as unexecuted files and say that they were not run.
- Use the Section 25.5 fault-creation catalogue exactly. If a fault is not covered, or there is
  any doubt about creating a physical or communication fault, ask the user rather than guessing.
- Tool calls are auto-approved in this environment. Before anything reaches hardware, rewrites
  history, or deletes work, state plainly what will happen. If a hook refuses an action, do not
  bypass it: read the reason, correct the approach, or ask for guidance.

## Task routing in `agent_sc3.md`

| Work | Required section(s) |
|---|---|
| Core engineering principles, workflow, and quality gates | 0 |
| ECU behaviour, CAN-C, NM, UDS, EDR, FltMonr, GPO/ENS, RSU, EOL/VC/VIN | 1-12 |
| Discrepancy register D-01 through D-12; never implement around an item without surfacing it | 3.1 |
| UDS behaviour and ISO 14229 | 4.3 |
| Writing test cases in Veoneer format and test-design methodology | 16 and 16.10 |
| Codebeamer ID mapping for the correct variant and Approved rows only | 16.2 |
| DTC status bytes | 16.3 |
| NRC expectations | 16.4 |
| Excel and requirement-source ingestion; sanitization | 16.5 and 16.7 |
| PDF and Word ingestion | 16.6 |
| DBC and CAN/diagnostic-log analysis | 16.8 |
| Other file formats and the approved library manifest | 16.9 |
| Large or batch work: planner, workers, integration, verifier gate | 17 |
| Python test scripts; Section 18.5 is the gold standard | 18 |
| Legacy ARIA JavaScript function compatibility | 18.6 |
| Reviewing test cases and implementations | 19 |
| Full AI behavioural rules | 20 |
| Environment map, interpreter paths, and constants card | 21 |
| Task playbooks | 22 |
| Safety boundaries | 23 |
| Glossary | 24 |
| ARIA bench, fault catalogue, instruments, and PWM measurement | 25 and 26 |
| Electrical and protocol questions | 27 |
| Cybersecurity, CRC, SecOC, AUTOSAR E2E, counters, and UDS conformance | 28 |

## Requirements, test design, and test-specification requests

- For a request to create a test specification, Veoneer specification, test cases from
  requirements, a Codebeamer import file, or a specification from Excel, Word, PDF,
  Codebeamer-exported, text, or mixed sources, load and use
  `.github\skills\veoneer-test-spec-generator\SKILL.md`.
- Its template-profile validation does not replace the Section 16 evidence, traceability,
  approval-status, project-variant, or Codebeamer requirements.
- Do not generate cases merely to satisfy a requirement or increase a count. Analyse and
  decompose each requirement, derive objectives, then design a minimal, high-value suite using
  equivalence, boundary, state-transition, MC-DC, and risk-based methods, including negative and
  fault-injection sweeps where applicable.
- Merge and deduplicate the suite, place safety-critical and high-value cases first, provide a
  coverage report that identifies uncovered behaviour, and retain complete traceability with no
  orphan test cases.
- Every test case must use a verified Codebeamer requirement ID from the correct project
  variant's tracker and Approved rows only. Never invent an ID.
- DTC status bytes: active CAN faults are `0B`; crash locks are `8B`; UV/OV remains `8B`.
- Use the Section 16.4 NRC expectations.
- Confirm project-variable facts from that project's configuration or tracker, or ask the user.
  Do not carry them between projects. This includes ENS PWM duty values (62.5/37.5 versus 60/40)
  and the PAB-lamp input signal name. In Mahindra projects, PAB-ON is ON by default, and ENS and
  PAB lamps are low-side driven (Sections 2.5 and 26.1).

## Source ingestion and document quality

- Before reading Excel, PDF, Word, PowerPoint, Markdown, HTML, CSV, JSON, XML, or a tabular
  source, inspect available Python packages and select the highest-fidelity parser or parsers,
  not simply the fewest dependencies.
- Prefer semantic and layout-aware extraction. Use PyMuPDF, pdfplumber, unstructured, Polars,
  PandasAI, LangChain document loaders, and LlamaIndex readers when suitable and available.
  Use multiple extraction engines when they improve accuracy.
- Preserve structure, tables, relationships, metadata, page hierarchy, contextual information,
  and provenance. Never work from a partial read, preview, or memory of a file. State the
  selected libraries and rationale in the result.
- Accuracy and context preservation take priority over dependency minimization. Install a needed
  library into the correct interpreter on demand rather than use a lossy manual parser, and note
  external binaries when they are required.
- For any Excel or requirement source, follow Section 16.5: dump the complete workbook with
  openpyxl (every sheet and every row), resolve columns by header name rather than index, decode
  Codebeamer escapes and markup, interpret strikethrough as deleted text, verify the extraction,
  and never work from a partial read, preview, or memory.
- Apply the Section 16.7 Excel sanitization pipeline before extracting requirements or generating
  tests: strip presentation artifacts only, preserve every engineering token, retain deleted text
  as `[STRUCK:]`, and verify integrity.
- For PDFs and Word documents, follow Section 16.6: select the appropriate library for the
  document (PyMuPDF, pdfplumber, or Camelot; OCR with ocrmypdf or pytesseract for scanned pages
  with confidence flagged; python-docx for Word), preserve tables and page references,
  cross-check completeness, and report extraction quality instead of guessing missing content.
- For DBC and CAN/diagnostic logs, follow Section 16.8. Select the highest-fidelity parser
  (cantools, canmatrix, python-can, or asammdf; Polars or pyarrow for large data), use
  `tools\extract_dbc_signals.py` for DBC extraction, stream multi-GB logs rather than loading
  them whole, decode frames into engineering values, perform signal-level, temporal, and
  intelligent-DBC checks, build the ISO-TP diagnostic timeline, and verify the
  requirement-to-signal-to-message-to-code-to-test-to-log chain with evidence-based root-cause
  findings.
- For other file formats, follow Section 16.9 and
  `tools\analysis-requirements.txt`: use the approved library manifest, use fallback parser
  chains based on quality signals rather than exceptions alone, validate extraction against the
  source's page, sheet, or row count, normalize results into one common internal model, and
  retain file plus sheet/page plus row/cell/XML-path provenance for every extracted item.
- When reviewing test cases or implementations, follow Section 19: ingest and correlate all
  sources first, build module-aware context, apply the Sections 19.3 and 19.4 checklists, and
  support each finding with a requirement ID, DBC evidence, code evidence, or standard clause.
  If evidence is unavailable, say so. Deliver the Section 19.7 report with severity, RTM,
  coverage matrix, risk, and confidence.

## Python scripts, wrappers, and bench configuration

- Module scripts use their module configuration files and `shared_libraries\` wrappers only.
  Verify each wrapper name and signature in source; never call library internals or `Api.*`
  directly.
- Obtain all constants from `projects\<project>\config\` or the DBC. If a constant is missing,
  inform the user and suggest a maintainable configuration location; do not hard-code it.
- Every `Sleep` or `Wait` must be traceable to a specification time. Do not use sleeps in
  T0-relative EDR sequences. Cycle ignition when next-cycle semantics apply.
- Follow the Section 18.5 EDR-script gold standard: one `run_test()`, no local helpers, and no
  hard-coded values.
- When a missing wrapper is genuinely required, classify it as a bench wrapper for
  `jscript_translation.py` or a user-defined function for `core_functions.py`; both must be
  project-agnostic. Because those locations are protected, do not create or modify them without
  an explicit protected-path policy decision.
- For legacy ARIA JavaScript functions, preserve the ARIA name and prototype, resolve the
  channel from configuration, and preserve the expected return contract, for example
  `CAN.SendDiagByValues` returning `["0000", ...]`.
- For ARIA 5.20 bench work, use the canonical documentation under `C:\ARIA5.20\` and verify the
  bench/configuration model, APYM, RTSE, and loadbox load states. For Saleae or oscilloscope PWM
  setup, ENS uses a 40 ms period, 62.5% normal duty, and 37.5% crash duty. Answer electrical and
  protocol questions (connections, shorts, opens, leakage, terminations, SPI CPOL/CPHA, PSI5
  current modulation, CAN/CAN FD physical layer, LIN/K-line, and PWM) only as Section 27 defines.

## Writing and changing code (ponytail agent)

- For any request to write new code or change existing code (a test script, generator, tool,
  repository test, bug fix, refactor, or code review), read `.github\agents\ponytail.agent.md`
  before the first edit and follow it: the smallest complete change, reuse what the repository
  already has, no unrequested abstraction or option, and code a reader understands at a glance.
- The rules in this file, `agent_sc3.md` Section 0, and the matching `.instructions.md` files take
  precedence. The agent's "In this repository" section lists where they meet.
- `.github\instructions\60-ponytail-code.instructions.md` attaches the same rule to code files
  automatically.

## Cybersecurity and communication protection

- For secure boot or flashing, secure diagnostics, SecOC, AUTOSAR E2E, MAC, freshness, replay,
  CRC, or alive/rolling-counter work, operate as a senior automotive cybersecurity engineer.
  Understand the security architecture before implementation and use the Section 28.2 review
  workflow.
- Use the Section 28.10 reference parameters only as a starting point: CRC-8 J1850/8H2F,
  CRC-16 CCITT/ARC, CRC-32/32P4, CRC-64, and AUTOSAR E2E P1-P7 must be verified against the
  project DBC or E2E configuration.
- Distinguish E2E protection (accidental corruption and basic replay) from SecOC/MAC protection
  (deliberate attackers). Never call an unauthenticated message secure.
- Treat weaknesses on deployment, flash, or NVM-identity paths as safety issues. Report Section
  28.12 findings with confidence and safety impact.
- Follow UDS under ISO 14229 as specified by Section 4.3. Deviate only for a documented OEM
  deviation or an explicit user request.

## Generated artifacts and workspace governance

- New test-related source files from any skill go directly under `tests\` as
  `test_<feature>.py`. Generated test-support folders and validation artifacts also remain under
  `tests\`, including `tests\dependency_management\`.
- Do not relocate existing project scripts or the configuration-controlled `test_results\` and
  `test_logs\` paths without an explicit migration request.
- Original customer documents remain in `docs\`. Put only extracted or processed artifacts in
  `docs\processed_Documents\<source-document-stem>\`, preserving source-stem casing after
  filesystem-safe sanitization.
- When creating, changing, moving, or retaining content below `tests\` or `tools\`, follow
  `.github\instructions\artifact-governance.instructions.md`.
- Keep executable `test_<feature>.py` files at the root of `tests\`. Put every other newly
  grouped test artifact in a purpose-named folder with a README. Put multi-file tools in a
  purpose-named folder with a README.
- Every retained artifact folder must explain its contents, retention reason, inputs or
  provenance, validation, and retention decision. Append a date-stamped record to the applicable
  monthly logbook.
- After structural changes, run
  `py -3.13 tools\audit_test_tool_artifacts.py` and resolve or explicitly record its findings.
- Do not create names such as `new`, `final`, `copy`, Office-lock files, cache names, or
  numbered copies. Do not delete or merge a possible duplicate until its content and references
  have been verified.

## Automated guardrails and durable corrections

1. Matching `.github\instructions\*.instructions.md` files attach automatically by file context;
   they are more specific and must be followed.
2. `.github\hooks\` provides these guardrails:
   - `SessionStart` injects the briefing and cache.
   - `UserPromptSubmit` matches the request against `routing.json` and identifies material to
     open.
   - `PreToolUse` refuses generated-file edits, destructive commands, and bench-script execution.
   - `PostToolUse` checks Python that is written.
   - `PreCompact` preserves verified values across summarization.
3. `.github\cache\session.json` is a persistent cache and is cleared only by `/cache-clear`.
   Record only verified facts, using:

   ```
   py -3 .github/hooks/scripts/cache.py fact "<what>" --evidence "<source>"
   ```

   A wrong cached fact is worse than an empty cache.
4. Available slash commands in `.github\prompts\` are `/new-test-script`, `/regenerate`,
   `/verify-claim`, `/review-change`, `/cache-save`, `/cache-clear`, and
   `/review-source-blackbox` (ECU source review for black-box-testable bugs).
5. `.github\knowledge\rejections.md` records user corrections as durable rules. Read its rules
   index before proposing work in a scope with applicable rules. Record a correction in the same
   turn rather than leaving it only in chat history:

   ```
   py -3 .github/scripts/log_rejection.py --scope <scope> \
       --proposed "<what you proposed>" --wrong "<why>" --rule "<the rule>"
   ```

## Multi-agent work and independent verification

- For work that spans domains, or where being wrong is expensive, use the `swarm-orchestrator`
  agent. It dispatches relevant specialists, then gates the result through an independent
  verifier and an intent-fidelity check.
- Specialists return evidence-handoff objects. The orchestrator reports only what the gate
  surfaces; held findings are open threads, never conclusions.
- No agent has `execute`. Agents report what should be run; execution remains with the user or
  the responsible operator.
- The following manual guards remain available:

| Command | Checks |
|---|---|
| `py -3 .github/scripts/validate_agents.py` | Agent frontmatter, roles, and tool restrictions |
| `py -3 .github/scripts/review_gate.py <dir>` | Evidence, self-critique, deduplication, and confidence |
| `py -3 .github/scripts/check_source_diversity.py <dir>` | False consensus |
| `py -3 .github/scripts/build_skill_catalogue.py` | Regenerates the skill catalogue |

- Decisions and their rationale are recorded in `.github\knowledge\decisions.md`.

# Copilot rules

- Do only the requested task. Stop when acceptance criteria pass.
- Ask one concise question only when essential information is missing.
- Use the smallest sufficient context. Prefer targeted search, symbols, files, and line ranges. Avoid unrelated files, generated content, dependencies, lockfiles, and large logs unless really required or ask the user permission for it if really required.
- Reuse known context. Do not reread unchanged files. Batch independent tool calls and summarize verbose output.
- Make the smallest correct patch. Preserve existing architecture, APIs, style, naming, and dependencies. Avoid unrelated changes, unnecessary abstractions, and whole-file rewrites.
- Change only directly affected tests.
- Run the narrowest relevant validation first. Expand only when necessary. Do not repeat successful checks.
- Respond without filler or process narration. Report only changed files, changes, validation, and any risk or blocker.
- Show summaries or relevant diffs, not complete unchanged files. Explain details only when requested or required for correctness or safety.