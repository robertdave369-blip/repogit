---
name: 'review-source-blackbox'
description: 'Review ECU source code for bugs a black-box bench test can expose; write a classified bug list and one reproduction test document per bug'
agent: 'agent'
argument-hint: 'Source folder (read-only); project; governing spec(s) with version; functionalities to verify first; output folder'
---

Review this source code for bugs that a black-box test can detect and reproduce:

${input:task:Source folder, project, governing requirement documents (with version), functionalities to verify first, release/variant, output folder}

Work from the code to the outside of the ECU. A finding only counts if it changes something a
bench can see: a DID byte or bit, a transmitted CAN signal, a DTC, a lamp, or a timing. Every
finding ends as a test that a tester can run without the source.

## Ground rules

- The source tree is **read-only**. So are `shared_libraries\` and `projects\` (configs and
  libraries) of this framework. A problem found there is a *test-side finding*: report it, do
  not fix it.
- Never run anything on the bench, never flash, never commit. Writing a test document is not
  running it.
- Every statement is labelled fact, inference or assumption. Evidence is `file:line` for code
  and document / sheet / row (or cell) for requirements. When there is none, write
  "Evidence unavailable."
- Do not call anything Confirmed unless it meets the Confirmed rule below.
- Ask once, at the start, for any missing input. Then work hands-free to the end.

## Inputs

| Input | Why it is needed |
|---|---|
| Source folder(s) and the component boundary | What is in scope, and which modules it calls that are not in the tree |
| Framework project (`projects\<p>`) | DID layout, DBC, variant and calibration data the tests will use |
| Governing requirements: customer spec and its version, diag spec, DBC(s), SRS | The expected behaviour. If several versions exist, Phase 0 decides which one the code follows |
| Functionalities to verify first, in priority order | Order of work and of the README |
| Release identity: build configuration, variant, record count, calibration set | Code that the release does not run is not a finding for that release |
| Output folder | Default `review\<Project>_<Component>_BlackBox_Review\` |

## Phase 0 - Baseline (before any finding)

1. **Inventory.** List the source files with sizes. Separate generated configuration
   (`*_Lcfg.c`, `*_PBcfg.c`, `*_Cfg.h`, ARXML) from hand-written code. List every module the
   code calls that is **not** in the tree (CAN manager, Dcm/diag manager, NvM, EcuM, algorithm
   libraries, ...). These set the limits of what can be concluded.
2. **Release configuration.** Find the values the shipped build uses: `#define`s, link-time
   tables, variant switches, record counts. Check that any build output in the tree is the
   release and not another variant (compare with the release map or notes). Dead code for
   another variant is not a finding.
3. **Spec version.** Compare 5-10 distinguishing layout facts (byte positions, bit order,
   field lengths, element lists) between the spec versions and the code. Record which version
   the code follows and use it as the baseline. A difference that exists only against an older
   version is not an ECU bug. If the framework's own config follows a different version,
   that is a test-side finding.
4. **Timing and units.** Pin down the main-function period (behaviour ARXML / OS config), tick
   units, scaling constants (for example internal units per km/h), and where every timer is
   started and reset. Put them in a units table. Most black-box defects are unit or timing
   defects.
5. **Numbering.** Fix the conventions used in every document: spec byte numbering (for example
   a 0-based offset after the `62 xx xx` response header), the framework offset to it, bit
   numbering (bit 0 = LSB), and how multi-bit fields are referenced.

Read workbooks with `openpyxl`, resolving columns by header name. Read whole functions, not
grep hits. A grep filter that drops comment lines with `^\s*\*` also drops pointer writes
(`*ptr = ...`); use a stricter pattern or read the function.

## Phase 1 - Map the data path of each functionality

For each functionality trace input -> processing -> storage -> output:

- **Input:** RTE port, Rx signal or sensor channel; raw or physical; qualifier; which module
  writes it (in the tree or not).
- **Trigger and state:** start and end conditions, timeouts, priorities, locks, windows.
- **Storage:** buffers, indices, sampling timers relative to T0, the moment of the NVM write.
- **Output:** DID bytes and bits, Tx frame and signal, DTC, lamp, with their timing.

Keep one short table per functionality. It becomes the README section "Verification per
functionality".

## Phase 2 - Verify the focus functionalities first

Walk each requirement row against the code and mark it: *implemented as specified*,
*deviation* (becomes a finding), or *cannot be determined from this tree* (say which missing
module decides it).

For an EDR use the checklist below. For another component, derive the same kind of list from
its requirements.

- **Multi-event:** record allocation for each combination of event types, priority and lock
  rules, overwrite strategy, multi-event window boundaries (`<=` or `<`, and measured from
  what), parallel-event threshold, a third and later event, MultiEventNumber, time between
  events, lifetime counter, effect of an EDR clear, power-down or reset during an event, a
  diagnostic read during recording.
- **Bus-recorded data (CAN-C):** sample count, rate and window around T0; phase of the sampling
  timer at T0 (free-running or started at T0); first and last sample; pre-event buffers (is
  every rate group present?); buffer clearing between events; scaling, offset and length;
  invalid, not-available and not-captured encodings; qualifier handling; hard-coded values.
- **On-fail recording** (timeout, invalid value, node absent, DTC active): which module
  substitutes the value (in the tree or not), what ends up in the record, and when the
  substitution starts and ends relative to fault maturity and healing.
- **Sensor recording:** sample time and alignment to T0, length, delta-V integration (units,
  limits, saturation, resultant), firing and deployment times (units and reference), which
  event a sensor DID shows.
- **Other record content:** completion status (bits and timing), crash type and location bits,
  occupant and belt status, ignition cycles, time stamps and year offsets, lock rules, and the
  no-event content (for example all `FF`).
- **Transmitted signals:** every crash-related signal the ECU sends: trigger condition, gating,
  duration or pulse length, encoding, and whether the EDR records the same signal consistently.

## Phase 3 - Sweep the whole component for defect patterns

Then go through the rest of the component, including the inputs and dependencies the focus
functionalities rely on. Look for:

| Pattern | Typical black-box symptom |
|---|---|
| Ticks stored where the spec asks for ms; wrong scaling constant | Value off by a fixed factor |
| `<=` vs `<`; window measured from the wrong reference; completion before the window ends | Wrong result at an exact boundary |
| Unsigned underflow (`idx - 1U` at 0), u8/u16 wrap, signed/unsigned compare | Wrong slot or value after N events or a long time |
| Free-running timer not aligned to T0; reset only at init | Sample series shifted, jitter between runs |
| State not reset after clear, power-down or event end; one-way latches | Next event missing or wrong until a reset |
| Buffer OR-ed or accumulated without zeroing; shared buffer between events | Data from an earlier event leaks in, or is wiped |
| Priority or lock changed after allocation | A later event cannot be stored |
| Hard-coded constant instead of the input | Field never follows the input |
| Copy length differs from buffer or DID length | Truncated or padded field |
| First sample discarded, index starting at 1, off-by-one in a series | Every series shifted by one sample |
| Record written at T0+N while the requirement window runs past N | Tail of the series always default |
| Producer/consumer order in one task | Value one cycle stale |
| Sign or axis convention | Sign inverted for one direction |
| Default value on a qualifier failure | Unexpected value while a fault is active |
| Behaviour that depends on calibration | Note the calibration value you assumed |
| Diagnostic read or clear during capture; NVM write moment | Record lost or mixed across a power cycle |

For each hit decide whether it changes something observable outside the ECU. If it does not,
drop it (list it briefly under "Not black-box testable" if it matters for a code review).

## Phase 4 - Verify every finding independently

You may run parallel reviews (for example one subagent per functionality), but their output is
a list of leads. Before a finding enters the list, the main reviewer:

1. Re-reads the whole function at the cited lines and corrects the line references.
2. Confirms the path is active in the release: configuration values, variant switch, and the
   call path from the scheduler.
3. Quotes the requirement in the baseline spec version.
4. Works out the concrete stimulus and the observable value: byte or bit, expected value,
   suspected value.
5. Looks for a reason it is **not** a bug: other code compensating, an out-of-tree module, a
   spec note, a deliberate design, an older spec version.

Keep withdrawn findings in a table with the reason. They stop the same lead being reported
again.

## Classification

| Class | Rule |
|---|---|
| **Confirmed** | Active in the release build; the defect is proven by reading the full code path; it contradicts a quoted requirement in the baseline spec; the outcome does not depend on code outside the tree or on calibration you have not seen. Without a bench log say "confirmed by code review, not on the bench". |
| **Reproducible** | Deterministic: a defined test shows it every time. But the requirement is open or ambiguous, the behaviour may be deliberate, or it assumes an out-of-tree module passes the bytes through unchanged. |
| **Potential** | Inferred from the code; depends on timing, phase, a rare stimulus or calibration. The test decides. |
| **Needs investigation** | The requirement is unclear, or the outcome depends mainly on modules outside the tree. The test collects the evidence. |

Give each item a confidence (High / Medium / Low) as well. Never move an item up a class
without new evidence; a bench result moves it only when the log shows the defect.

**Test-side findings** (T1, T2, ...): problems in the framework's configs, scripts or spec
copies that would make a test fail a correct ECU or pass a faulty one. Report only.

## Output

```
<output folder>\
  README.md
  COMMON_TEST_SETUP.md
  bugs\<PREFIX>-NN_<short-slug>.md     one file per finding, IDs stable
```

**README.md**
1. Scope and method: files reviewed, software version if known, reviews run, what was
   re-verified.
2. Baseline: spec version decision with its evidence, release configuration, units table,
   numbering conventions.
3. Classification rules and totals.
4. Verification per functionality: verdict, what works, what deviates, what cannot be
   determined and why.
5. Bug list table: ID | Title | Class | Confidence | Area | Observable | Document.
6. Bug details: symptom, triggering condition, expected (with source), actual or suspected,
   code evidence.
7. Withdrawn findings with reasons.
8. Test-side findings.
9. Limits: out-of-tree modules, calibration assumptions, nothing run on the bench.
10. Recommended run order: cheapest high-value tests first, tests sharing a set-up grouped.

**COMMON_TEST_SETUP.md:** DUT and how to read its software version; the bench (take equipment
from the project knowledge base, never invent it); standard preconditions; available stimuli
(crash curves, fault recipes) from the framework; the evidence every test collects; a check
that the ECU runs the release build; how to read the results (numbering conventions).

**Per-bug document**

```
# <ID> - <title>

| Class | Confidence | Area | Variant | Verified | Related |
|---|---|---|---|---|---|
| ... | ... | ... | ... | what was re-checked | other IDs |

## Summary
## Expected behaviour            (source: document, sheet, row)
## Code evidence                 (file:line, minimal quote, fact/inference labels)
## Suspected behaviour
## Observable                    (DID byte/bit, Tx signal, DTC, timing: expected vs suspected value)
## Test setup                    (only what adds to or changes COMMON_TEST_SETUP)
## Preconditions
## Input signals
## Triggering conditions
## Steps                         (numbered; each step an action and a check)
## Expected results
## Actual / suspected results
## Pass / fail criteria
## Evidence to collect
## Notes                         (other explanations; what would change the class)
```

Writing rules:
- Byte numbers in the baseline spec's numbering, framework offset in brackets.
- No value that does not come from the source, a spec or a framework config.
- Keep the findings in one data file and generate README and bug documents from it with a
  script in the scratchpad (assert unique IDs and that the totals match), so the list, the
  totals and the documents cannot drift apart.
- Generated scripts follow the repo header rule (no GENERATED line); documents need none.

## Final reply

Keep it short. Give:
- where the files are;
- counts per class;
- each Confirmed item in one line, then the most important Reproducible ones;
- one line per focus functionality: works / deviates / cannot be proven from this tree;
- the spec-version decision and how many findings it withdrew;
- the test-side findings;
- the limits, and that nothing was run on the bench or committed;
- at most one question, when a decision is needed from the user.
