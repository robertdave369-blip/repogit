# EDR CAN-C open points for review

Date: 2026-10-22. Scope: the EDR CAN-C work on U171, Z121 and M310_M314_M110 (EV, = M210 / M314),
plus the configuration of UPP_EV, W610 and W616.

Everything below was checked by offline simulation and file inspection only. No script has run
on a bench, and nothing is committed.

How to answer: write your decision under each point (`Decision:`), or just reply with the IDs.
Round 8 (2026-10-22): your decisions are kept as written; what was done is under each one
("Outcome"), and section H lists what this round found.
"Fact" means verified on 2026-10-22. "Carried" means taken from earlier notes and not re-checked
today.

---

## A. Decisions needed before a bench run

### A1. Default variant code: some node bits are already clear (signal never received cannot be created)
- **Finding (Fact):** In `project_config.DEFAULT_VARIANT_CODE`, these node bits are already 0.
  Clearing them changes nothing, so the SNR cases of their signals cannot create the fault; the
  scripts report "unchanged".
  - U171: EMS (ACC_PED, BRK_SWITCH, Clutch_Sts, MOTOR_SPD, STS_ENG), TCU (GEAR_ACTUAL).
  - Z121: the same, plus HPCAD (18 ADAS elements: ADAS_Des_StrWhl_Angle_Cmd, AEB_*, AES_*, ELK_*,
    ESA_SYS_STS1, LCF/LC_PATH/LDW/LKA/NP/RMS/SPA_*).
  - EV: none.
- **Question:** Are these the real default variant codes? If so, what should the SNR cases of those
  signals do (set the bit first, or drop the case)?
- Decision: Those are just kept 0 for now, which i will populate while running it on the HIL remote bench setup which i run this scripts on
  - **Outcome (2026-10-22):** No change: the bits stay as DEFAULT_VARIANT_CODE has them until you set them on the HIL bench. Until then those SNR cases still report "unchanged" in simulation (U171 6, Z121 24, EV 0).

### A2. Message content failure on EV breaks the CRC where the frame has a counter
- **Finding (Fact):** `choose_message_content_failure_signal` (canc_config) picks a signal named
  `MSG_CNT` before the CRC. In 7 EV frames the counter is named differently (`MSG_COUNT` or
  `COUNTER`), so the CRC is broken instead: EPS1_FD_10, FR_ZONE3_100, HPCAd_1_10, HPCAd_2_50,
  HPCAd_3_50, HPCAd_4_10, HPCC_1_100. The spec names the counter. The DTC is the same either way.
- **Question:** Counter or CRC for these frames? If counter, the selection in canc_config should also
  accept `MSG_COUNT` / `COUNTER`.
- Decision: Message content failure can either be achieved through disabling the crc signal or as well as the counter signal of that message, check the dbc file if the counter or crc exist and take action accordingly, for now try to disable the crc signal if applicable for that message, if not consider message content failure is not applicable for this message , and counter spelling could be different in few, this needs to be taken cared by understanding it
  - **Outcome (2026-10-22):** Done. canc_config `choose_message_content_failure_signal()` (U171, Z121, M310) returns the frame's CRC signal (CRC / CHKSUM / CHECKSUM) and None when the frame has none: no message content case then. New `get_message_counter_signal()` finds the counter whatever its spelling (MSG_CNT, MSG_COUNT, COUNTER, ALIVE). Checked against the DBCs: every U171 / EV frame with a counter also has a CRC; MBFM7_100 (BATT_VOLT) has neither, so its MCF cases are dropped (simple set and COMBINED). The DTC is the same for CRC and counter in every frame. The scripts disable the CRC with `CAN.DynamicDisableSignal`.

### A3. Out-of-range values that record as all ones
- **Finding (Fact):** EV VCU_TRQ_CMD out of range = 0xFFFF (65535) and TORQUE_SPLIT_RATIO = 0xF (15).
  Both are out of the DBC range and fit the record, but all ones is also what a not-configured
  element records, so the record cannot tell the two apart.
- **Proposal:** 0xFFFE (2047.875 Nm) and 0xE (1.4), which also fit and are not all ones.
- Decision: for these cases expect the outcome or EDR output as per the EDR onfail of out of range only 
  - **Outcome (2026-10-22):** No change: 0xFFFF / 0xF kept; the OOR scripts expect the out-of-range on-fail outcome (the value recorded, converted like any other). oor_fit2: every OOR value fits its record field.

### A4. RSU T0 offsets are all 0
- **Finding (Fact):** `rsu_config.RSU_T0_OFFSETS` is 0 for every crash type in all six projects
  (0 = not known). The scripts handle any offset, simulated at 0, 180 and 600 ms.
- **Question:** The real T0 offset per crash type (time from trigger to the algorithm's T0) for each
  project.
- Decision: These are 0s for now, while performing the real crash test, i will add the offset 
  - **Outcome (2026-10-22):** No change (0 until the crash tests give the offsets; the scripts take any offset, simulated at 0 / 180 / 600 ms).

### A5. CAN wakeup: expected behaviour and timings
- **Assumptions (to confirm):**
  1. Under a CAN wakeup or CAN NM wakeup (hardware ignition OFF), the record is written exactly as
     with ignition ON, and only the crash DTCs are set.
  2. The bus-sleep wait before waking is U171/Z121 10000 ms (canc_config says "set generously -
     confirm against the ECU") and EV 11000 ms. The start-up wait is 2000 ms
     (NM_IGN_ON_STARTUP_DELAY_MS).
  3. The wakeup report is read from the ECU's own frame through `CAN.GetSignalFromFrame`
     (U171: SRS1_20 / IGN_STS_SRS = 2; EV: SRS1_FD_10 / IGN_STS_SRS = 2).
  4. EV NM: `CAN.ReceiveFrame(SRS_CANNM)` returns the frame when the ECU sends it, and error text
     when it does not.
- **Fact:** ICE has no NM frame in the U171 DBC, so ICE has CAN wakeup cases only, no CAN NM.
- Decision: 1. Yes, only CANWAKEUP scenario is available for normal value simualtion for the duration, so only that to be checked 2. For M314 , M210 projects the canwakeup is done by hardwre ignition off while the active wakeup bit is set as 1, this to be considered while creating the can wakeup function in shared library ACTIVE_WAKEUP_BIT =1 and while hw ignition is turned on, do not forget to make this bit to 0 
  - **Outcome (2026-10-22):** Done. Shared `CAN_Wakeup(project, via_nm)`: IGN OFF, restbus stopped on every simulated bus (CAN_WAKEUP_BUS_SLEEP_WAIT_MS), restbus started, then on M314 / M210 VCU_CANNM ACTIVE_WAKEUP_BIT = 1 (new canc_config CAN_WAKEUP_REQUEST_FRAME / _SIGNAL / _VALUE / _CHANNEL, CAN_WAKEUP_RELEASE_VALUE = 0), start-up wait; via_nm the ECU must send SRS_CANNM; then SRS1_FD_10 / IGN_STS_SRS = 2. `CAN_Wakeup_Restore()` sets ACTIVE_WAKEUP_BIT = 0 first, then hardware IGN ON. The simple scripts wake after each load_crash_curves() and release after each record. The wakeup cases stay nominal, full duration. Call order mock-tested offline; not run on a bench.
3. yes, 4. correct when the ecu is wakeup through can, this message pops up on bus
---

## B. Specification updates (V5 EDR CAN-C ICE / EV workbooks)

### B1. Configuration values that now differ from the spec on purpose
- **Fact:** These come from your own rules and should go into the spec.
  - Non-zero rule: ICE 58 cases (MASTER_CYL_PRESSURE, YAW_RATE, LATTERAL_ACCEL, LONG_ACCEL,
    ADAS_DES_STRWHL_ANGLE_CMD1, STS_LOW_BEAM). EV 384 cases (22 signals), plus 8 STS_HIGH_BEAM
    snapshot cases where the 0 was dropped.
  - EV ACC_PED first value 0x001 -> 0x004 (16 cases): 0.1 % records 0 at the record's 0.4 %/count.
  - Out of range (values must fit the record): ICE Engine Speed 0xFFFE -> 0x1F40 (8000 rpm);
    EV ACC_PED 0x3FF -> 0x3EC (100.4 %).
- **Question:** Update the specs? The EV spec is generated by `tools/build_edr_canc_ice_ev_spec.py`;
  the ICE spec is maintained by hand.
- Decision: Update the spec later, but for now ensure the correctness in the scripts, then we can update spec 
  - **Outcome (2026-10-22):** No spec change. Scripts checked against the specs: ICE 791 cases, 60 differ (58 non-zero rule, 1 OOR, 1 spec defect 52.2); EV 1157 cases, 427 differ (384 + 8 non-zero rule, 16 ACC_PED, 1 OOR, and 18 AES_SYS_STS1 from C5).

### B2. EV cases the EV spec does not have yet
- **Fact:**
  - 29 message-timeout cases on FR_ZONE3_100 signals (series 3, 5, 13-16, 19, 49-52), per your
    FR_ZONE rule (node absent on FR_ZONE2_100, message timeout on FR_ZONE3_100).
  - 7 DoorsOpenStatus cases (series 5): STS_DOOR is in the M314 DBC.
- Decision: ensure to have the script upon which we can update the spec for these cases , few projects do not support FRZONE message as it is not defined in dbc, so accordingly we need to verify it
  - **Outcome (2026-10-22):** Scripts in place: EV scripts_simple has the 29 FR_ZONE3_100 message-timeout cases and the 7 DoorsOpenStatus cases; COMBINED EV now covers DoorsOpenStatus too. The ICE own scripts name no FR_ZONE2_100 / FR_ZONE3_100 frame (checked).

### B3. Spec defects found
- **Fact:**
  - ICE `EDR_Element_ID_BATT_VOLT_TestCase_52_2_NA_Full`: the input list has 21 entries for an
    11-sample element, with broken tokens (`%20FAULT_ACTIVE`, `FAULT_ACTIVE|FAULT_ACTIVE`).
  - ICE BATT_VOLT 52.3 NA_Pre text names "Node key message: FR_ZONE3_100" (EV text) for ICE.
  - ICE BATT_VOLT 52.8-52.10 (message content failure): MBFM7_100 has no CRC or counter, so the
    scripts drop these cases.
- **Carried:** In the EV spec, 38 node absent / SNR cases name FR_ZONE3_100 as the key frame; the
  config (bench-verified 2026-10-15) uses FR_ZONE2_100.
- Decision: ICE specific project do not have FRZONE message where as only EV specific has this, so these wont be in ICE projects like Z121, U171, W616
  - **Outcome (2026-10-22):** Confirmed: no FR_ZONE2_100 / FR_ZONE3_100 in the U171 DBC or in the U171 / Z121 own scripts; W616 has the U171 structure (no FR_ZONE frames). The BATT_VOLT 52.8-52.10 message content cases are dropped (no CRC on MBFM7_100).

### B4. DoorsOpenStatus in the diagnostic spec sheet
- **Fact:** `tools/check_edr_config_common.py` flags DoorsOpenStatus as 6 bits / 15.0-15.5 against
  the spec sheet's 5 bits / 15.0-15.4. The configs follow your corrected common gaps (6 bits,
  0..63, all door states in the DBC). `tools/build_edr_config_from_diag.py` still reads the older
  sheets.
- Decision:update it as per the 6bit so it acomodate all 
  - **Outcome (2026-10-22):** Done: tools/build_edr_config_from_diag.py `SHEET_CORRECTIONS` gives Doors Open Status 6 bits (15.0-15.5, maximum 63); tools/check_edr_config_common.py: 0 problems in U171, Z121 and M310.

---

## C. Configuration

### C1. UPP_EV, W610, W616: no DBC in the repository
- **Fact:** No DBC exists for any of the three; `project_config.CAN_DB_PATH` points to
  `C:\CAN_DB\...` placeholders.
  - UPP_EV and W610 got only the common names they lacked, from M310 (marked block at the end of
    canc_config / edr_config). Their own values are unchanged (verified).
  - W616 got the U171 structure. W616 shares the U171 / Z121 requirement set
    (`project_reuirements/u171_w616_z121`). Its template stubs (EDR_PARAMETERS dict, EDR_DIDS
    0x0401-0x0420) were replaced.
- **Left out for UPP_EV / W610 (they don't fit those projects' data):** CANC_CRC_FRAMES (no frame
  IDs), INTERVAL_PARAMETERS / SNAPSHOT_PARAMETERS (their EDR entries lack `sample_range`), and the
  helpers that share names with the shared library.
- **Question:** Provide the DBCs and EDR diag specs of UPP_EV, W610 and W616 so the reference values
  can be replaced. Is W616 really U171-like on CAN? Its project_config says HS only, no FD.
- Decision: i will provide them later, first let us focus on M314, M210, U171 and Z121 for now which are EV and ICE projects currently running
  - **Outcome (2026-10-22):** No change.

### C2. UPP_EV / W610 EDR elements use an older schema
- **Fact:** UPP_EV has 33 and W610 77 EDR elements, against 179 in the common record. Their signal
  dicts carry 16-18 fields against 26-37 (no TestCase arrays or fault_logic in most). Their 475
  EDR / Fault_List scripts read these as they are.
- **Question:** Migrate them to the common record, which needs their record layout, or leave them?
- Decision: Do not do anything and keep them as is for UPP_EV and W610
  - **Outcome (2026-10-22):** No change.

### C3. Dummy values in project / variant configs
- **Fact:** W610 EOL and variant code, and W616 variant code, are DUMMY 20 x 0x00
  (`project_config.py`, `variantcode_config.py`).
- Decision: I will update them later, for now let it be dummy values 
  - **Outcome (2026-10-22):** No change.

### C4. U171 / Z121 canc_config entries not in the U171 DBC
- **Fact (11 per project):** SEAT_OCCUPANT_STS (SRS2_100), SEAT_OCCUPANT_FAULTY_STS (SRS_TEST1),
  RESERVED_SRS (SRS_ACTIVE), STS_ESC (ESC5_10), STS_ABS / STS_TCS (ESC2_10), RESERVED_2 (MBFM_SLEEP /
  MBFM_ACTIVE), MBFM_WAKEUP_REASON (MBFM_WAKEUP), and the composite EventDt / EventTime (IS3_500).
- **Question:** Keep or remove? STS_ESC / STS_ABS / STS_TCS are EV elements; the ICE scripts treat
  them as not configured.
- Decision:  check if the dbc file of U171 support these paramters as per its can signal, if yes, keep them if not keep and comment out
  - **Outcome (2026-10-22):** Done. Against the U171 DBC: IS3_500 carries CLOCK_YEAR / _MONTH / _DATE / _HOUR / _MIN, so EventDt / EventTime stay. The other nine are absent and are commented out in U171 and Z121 canc_config (the dictionary, its MAH_CAN_SIGNAL_DEFS entry, the frame entries MBFM_SLEEP / MBFM_ACTIVE / MBFM_WAKEUP / SRS_ACTIVE, KEY_TX_FRAMES and the frames' signal lists): RESERVED_2 x2, MBFM_WAKEUP_REASON, STS_ESC, STS_ABS, STS_TCS, SEAT_OCCUPANT_FAULTY_STS, SEAT_OCCUPANT_STS, RESERVED_SRS. No script used them (the STS_ESC / ABS / TCS scripts read NOT_APPLICABLE_CAN_SIGNAL_DEFS). W616 still has them (C1).

### C5. Unused test arrays from the old series numbering
- **Fact:** U171 and Z121 each have 46 signal dicts, and EV 35, holding TestCase_<n>_* arrays for a
  series no script uses. Examples: ABSOLUTE_ANGLE 5 and 41, ENG_SPD1 4 and 40, RMS_MODE_STATE1 30
  (22 out-of-range codes).
- **Question:** Remove them, or keep them for the CANC / other suites?
- Decision: Make sure to have all the arrays as per how the spec for U171, M210 is made, so that all normal, signal invalid, oor, reserved are all correctly populated across all as per the dbc values 
  - **Outcome (2026-10-22):** Done. New check of every array the simple scripts drive against the DBC: values in range and never an invalid / reserved code; invalid = the DBC's "Signal Invalid" codes; reserved = reserved or undefined codes; OOR outside the range and fitting the record. Result: 0 problems after one fix: EV AES_SYS_STS1 series 30 drove 7, which the value table calls "Failure" but which is outside the DBC range [0|6]; it now drives 1, 2, 3, 5, 6 as U171 does (see H3). Coverage: every DBC invalid / reserved code has its SCF / Reserved case. The old-numbering arrays are kept (no EDR script reads them).

### C6. EV GEAR_ACTUAL message-timeout frame
- **Fact:** GEAR_ACTUAL is on VCU11_FD_10 (the key frame), but fault_logic names VCU2_FD_100 as its
  timeout frame. By the on-fail rule there is no MTO case (correct), but the field is misleading.
- Decision: ok if the VCU2_FD_100 is key, then there is not MTO for this param and can be ommited for  now
  - **Outcome (2026-10-22):** Done: EV GEAR_ACTUAL `non_key_timeout_frame` is None (the signal is on its key frame VCU11_FD_10, so there is no MTO case; VCU2_FD_100 dropped).

### C7. EV CLUTCH_STS in the not-configured check
- **Fact:** CLUTCH_STS is an ICE-only element (`variants: ['ICE']`) at byte 884. What an EV ECU
  writes there is not stated, so the EV check 9000.1 lists only STS_ENG (must record all ones).
- **Question:** What does the EV record hold at byte 884 (0xFF, 0x00, other)?
- Decision:
  - **Outcome (2026-10-22):** Open: no decision yet.

### C8. EV YAW_RATE / LATERAL_ACCEL / LONG_ACCEL
- **Inference:** EV takes these from the IMU (series 20-22, EV IMU spec), so they are neither CAN-C
  cases nor not-applicable scripts for EV.
- Decision (confirm):These require simulation through EVT to simulate IMU values and then trigger crash accordingly, check if any such function is available to use from shared library files, if not keep it as incomplete or work in progress file
  - **Outcome (2026-10-22):** Kept as work in progress: the shared library has no function that drives IMU values through EVT (only SPI.SendEvt, SPI.iUpdate_EVTWrapper, SPI.TriggerEvtErrors). 15 files in projects/M310_M314_M110/modules/EDR_CANC/scripts_wip (EV IMU spec series 20-22), profiles in imu_config `EDR_IMU_STIMULUS`; each works out its expectation and stops with NotImplementedError before the bench is touched; in no runner. 20.5 / 21.5 / 22.5 (IMU fault) are also on hold in the spec.

### C9. Unit spellings
- **Fact (cosmetic):** CAN 'kmph' vs record 'Km/h' (vehicle speed, all projects); EV 'volt' vs
  record 'V' (BATT_VOLT). The values decode correctly.
- Decision:use kmph and V
  - **Outcome (2026-10-22):** Done: vehicle-speed units in edr_config 'Km/h' -> 'kmph' (U171, Z121, M310); EV ZONAL_BATT_VOLT UNIT 'volt' -> 'V'. No code compares these strings.

### C10. Carried from earlier notes
- U171 CAN DTC tables are unconfirmed: the ICE list was copied from the EV one.
- M310: 93 signal dicts still have Default_Value None (CANC / Fault_List read it as the recovery
  value).
- M310 working-tree `power_config.py` lost UNDERVOLTAGE_TEST_VOLTAGE / OVERVOLTAGE_TEST_VOLTAGE
  (HEAD has them). The EV EDR scripts use the canc_config CANC_* levels instead.
- Decision:check this file for any dtc related info and do not use this file in script, this is for dtc reference only, keep the variables, but use the variable presnet in configuration control in the scripts 
  - **Outcome (2026-10-22):** Settled in the follow-up (section I): supply levels from power_config (UNDERVOLTAGE_TEST_VOLTAGE / OVERVOLTAGE_TEST_VOLTAGE / NOMINAL_VOLTAGE), voltage DTCs from configuration_control. power_config holds no DTC information. The U171 CAN DTC tables and M310 Default_Value None are not changed.

---

## D. Shared library (only CAN_Wakeup was changed, on your request)

### D1. CAN_Wakeup changed
- **Fact:** `CAN_Wakeup(project=None, via_nm=False)` and `CAN_Wakeup_Restore()` replace the old
  alias `CAN_Wakeup = CAN_Wakep_UPP`. UPP_EV, which has no wakeup settings in canc_config, keeps the
  old VCU_WAKEUP / VCU_ACTIVE behaviour. Backup: session scratchpad `backup_round7/core_functions.py`.
- **Please review:** the restbus is stopped and started on each bus that project_config enables
  (CAN_FD / CAN_HS) and the bench simulates; the default channel is used when none matches.
- Decision: as mentioned above please handle the wakeup by enabling the active wakeup bit for M314, M210 project ev cases while HW ign is off 
  - **Outcome (2026-10-22):** Done (see A5). core_functions.py had been replaced at 03:50 by a copy without the earlier CAN_Wakeup change; it was re-applied on top of that copy, nothing else in it changed.

### D2. Gaps seen, not changed (carried, verified when found)
- `CAN.DisableSignal` does not exist; the real call is `CAN.DynamicDisableSignal`.
- `manage_variant_code` returns `{"status": "FAIL"}` instead of raising. It has no HPCC alias (EV
  passes HPC_C).
- Bench wrappers return error text instead of raising; scripts must check the returned text.
- `Sleep()` truncates to whole seconds (use `Wait(ms)`).
- `Read_DTC` assumes status mask 0xCB.
- `edr_sample_records` ignores `data_first_bit_offset`.
- `load_crash_curves_can_wakeup_condition` hard-codes the UPP frames VCU_WAKEUP / VCU_ACTIVE.
- `LogCustomAction` shows TestStatus.Failed as PASSED; the new scripts use InterpretEqualResult.
- `wake_ecu_over_can`, `wake_ecu_over_can_nm` and `restore_can_nm_wakeup` are gone from the working
  tree (HEAD has them).
- `tools/build_edr_canc_ice_ev_spec.py` builds the out-of-range candidate as MAX + 1, treating MAX
  as raw. MIN / MAX are now the DBC physical range in every project.
- Decision:1. use CAN.DynamicDisableSignal to disable, is it because evrything in the variant code config is dummy? figure out and fix it :manage_variant_code
  - **Outcome (2026-10-22):** 1. CAN.DisableSignal / EnableSignal do not exist: replaced by DynamicDisableSignal / DynamicEnableSignal in 294 files (old scripts U171 49, Z121 49, EV 189; 4 templates; the COMBINED, CANC-C and ICE_01 generators). 2. manage_variant_code: not the dummy values (U171, Z121, EV have real defaults). It returned FAIL for target "HPCC" (canc_config's node name; the variant code calls it HPC_C): alias HPCC -> HPC_C added in manage_variant_code. W610 / W616 dummy (all 0x00) codes would make every SNR "unchanged". 3. The simple scripts use Wait(ms) only; COMBINED Sleep(1) / Sleep(5) -> Wait(1000) / Wait(5000); the old scripts' whole-second Sleep(N) calls are left. 4. No change. 5. Not required: no element of the U171 / Z121 / M310 edr_config sets data_first_bit_offset (SEB_WARNING_RIGHT follows the common reference: byte 590, no offset). 6. load_crash_curves_can_wakeup_condition left; wake_ecu_over_can, wake_ecu_over_can_nm and restore_can_nm_wakeup are back in core_functions.py exactly as at HEAD. Wakeup bit: wake_ecu_over_can does not touch it; wake_ecu_over_can_nm sets ACTIVE_WAKEUP_BIT = 1; restore_can_nm_wakeup reloads VCU_CANNM's default (no DBC start value, so 0).
3.use Wait(ms) 4. Let it assume it as CB for now 5. take care of it if really required :`edr_sample_records` ignores `data_first_bit_offset`.
6. let it be for now :load_crash_curves_can_wakeup_condition consider , keep wakeup_ecu_over can ,can_nm and restore_can_nm_wakeup as how it was and esnure to check about the wakeup bit 

---

## E. Scripts and generators not updated

### E1. Old CAN wakeup scripts call removed functions
- **Fact:** These call `wake_ecu_over_can*`, which no longer exists, and fail at run time:
  - old `scripts/` folders: U171 47, Z121 47, EV 120 scripts;
  - the templates `tools/edr_canc_templates/{interval,snapshot}_{CAN_Wakeup,CAN_NM}.py`;
  - `tools/build_canc_config_from_dbc.py`, `tools/generate_canc_scripts.py`.
- **Proposal:** Switch them to `CAN_Wakeup()` / `CAN_Wakeup(via_nm=True)` + `CAN_Wakeup_Restore()`.
- Decision: ok add these:CAN_Wakeup()` / `CAN_Wakeup(via_nm=True)` + `CAN_Wakeup_Restore(), but also keep the older ones, just mention them as legacy and keep in the comments
  - **Outcome (2026-10-22):** Done: the old CAN wakeup / NM scripts (U171 47, Z121 47, EV 120) and the 4 templates call CAN_Wakeup() / CAN_Wakeup(via_nm=True) / CAN_Wakeup_Restore(); every old call is kept as a "Legacy call, kept for reference" comment. Also fixed in them: they woke the ECU once before the crash loop, but each crash's load_crash_curves() power-cycles with ignition ON, so no crash was recorded under a CAN wakeup (and the EV wake bit would be 1 with ignition ON). The wakeup now follows each load_crash_curves() and is released after each record (214 scripts, offline simulation clean).

### E2. Old `scripts/` vs new `scripts_simple/`
- **Fact:** Both sets are kept: U171 / Z121 `modules/EDR/`, EV `modules/EDR_CANC/`. The new runners
  exist only in `scripts_simple/`. The old runner `run_all_u171_edr_canc_scripts.py` still names
  `py -3.14 tools/generate_edr_canc_scripts.py` in its docstring.
- **Question:** Retire the old sets?
- Decision: do not retire yet unless i check the scritps properly first
  - **Outcome (2026-10-22):** Not retired.

### E3. COMBINED scripts
- **Fact:** Regenerated (U171, EV; Z121 = U171 with the name replaced). The signal-never-received
  run now clears node names, not frame names, and there is no GENERATED header. The parameter set
  still comes from the old `scripts/` folder, plus the new message-timeout tags. EV DoorsOpenStatus
  and the not-applicable elements are not in the COMBINED runs. The simulator cannot see the A1
  default-VC issue in COMBINED, because it assumes all bits set.
- Decision: Make sure that the combined scripts for U171/Z121 is correct and correctly decodes all applicable canc parameter of EDR and as well as all the onfail ones correctly, make sure to double check these scripts as these are critical for testing and the correctness is very important for checking the recording and is useful when there is less time available
  - **Outcome (2026-10-22):** Done. The COMBINED generator now reads the parameter set from scripts_simple: ICE 47 parameters = every CAN-fed EDR element U171 / Z121 configure (INDC_PADL is the ECU's own SRS1_20 output), BATT_VOLT out of the MCF runs (no CRC); EV 61 with DoorsOpenStatus. Fixed the state label of the snapshots that follow an interval element ("valid input" under a fault; the values were right). Sleep -> Wait. Regenerated U171, EV and Z121 (U171 renamed). Offline: 45 scripts, 0 failures at T0 offsets 0 / 180 / 600 ms; a record with one sample one count off is caught (240 failing steps). The simulator does not see A1 (it assumes the bits set).

### E4. Not-applicable scripts: confirm the interpretation
- **Fact:** U171 / Z121 have 365 scripts for the 19 EV-only elements (EV numbering, M314 names), and
  EV has 22 for STS_ENG and Clutch_Sts (U171 names). Definitions are in canc_config
  `NOT_APPLICABLE_CAN_SIGNAL_DEFS`. They are in no runner, and on a bench of the other variant they
  cannot pass. The ICE copies include CAN_NM cases, which ICE has no NM frame for.
- **Question:** Is a full case set what you wanted, or one "records not-configured value" check per
  element?
- Decision: For each project the not applicable varies and so i would like to for now focus on U171/Z121 and M210/M314 ones and make sure those scritps are correct as it should be , do not keep CANNM related script in ICE fodler as it is not relevant there
  - **Outcome (2026-10-22):** Done: the ICE not-applicable set has no CAN NM cases (19 removed): U171 / Z121 1136 scripts = 790 own + 346 not applicable; EV 1217 = 1195 + 22. Under the foreign model they pass apart from the default-VC SNR finding (Z121 HPCAD 4, EV EMS 2).

---

## F. Bench verification still to do
1. A smoke run: `run_nominal.py`, then one runner per fault family, on U171 and EV.
2. Run CAN_Wakeup / CAN_NM once and confirm A5.
3. Run one SNR case on U171 to see A1 on a real ECU.
4. Run one UV_Pre case with a real RSU offset once A4 is known.
- Decision (who / when):
  - **Outcome (2026-10-22):** Open.

---

## G. Housekeeping

### G1. Renderer and tools live in a temporary session folder
- **Fact:** The simple scripts, runners and checkers are produced by tools in the session scratchpad:
  render_simple.py, write_runners.py, bench_sim2.py, spec_vs_config.py, oor_fit2.py,
  decode_check.py, dbc_vs_canc.py, add_common_names.py and write_not_applicable_defs.py. The folder
  may be cleaned up.
- **Proposal:** Move them into `tools/` so the sets can be re-rendered later.
- Decision:
  - **Outcome (2026-10-22):** Open: the renderer, runner writer, simulator and checkers are still only in the session scratchpad (round 8 adds r8/bench_sim3.py, r8/arrays_vs_dbc.py, r8/render_imu_wip.py, r8/wakeup_mock_r8.py).

### G2. Sample HTML report
- **Fact:** 20 reports for U171 ABSOLUTE_ANGLE, marked "OFFLINE SIMULATION", in the session
  scratchpad `html_ABSOLUTE_ANGLE_U171/`. Move them if you want to keep them.
- Decision:
  - **Outcome (2026-10-22):** Open: round-8 sample reports in the scratchpad r8/html_U171 (20) and r8/html_EV (5).

### G3. Nothing is committed
- **Fact:** The working tree also holds changes that are not from this work. Examples are deleted
  xlsx files under `project_reuirements/m310_m314_m110` and `project_testcases/m310_m314_m110/CANC`,
  and removed `__pycache__` files. Review them before any commit.
- **Backups:** `.py.bak` next to the U171 / Z121 / M310 canc / edr configs; session scratchpad
  `backup_round7/`.
- Decision:After making all these changes mentioned above, commit it to main branch 
  - **Outcome (2026-10-22):** Committed to master (the repository has no main branch; master is its main line): this work only. The other uncommitted changes stay as they were (see H5).

---

## H. New findings, 2026-10-22 (round 8)

### H1. UPP_EV / W610 carry M310's CAN wakeup settings
- **Fact:** The common names copied into UPP_EV and W610 canc_config in round 7 include
  CAN_WAKEUP_STATUS_FRAME / _SIGNAL / _VALUE and the NM settings (M310 values), so the shared
  `CAN_Wakeup()` would run the M310 sequence there instead of CAN_Wakep_UPP(). Their scripts do
  not call `CAN_Wakeup()` (they call CAN_Wakeup_Disable_UPP() / CAN_Wakep_UPP() directly), so
  nothing changes on those benches today. Replace with their own values with the DBCs (C1).
- Decision:

### H2. EV ECALL_PWM_ACK_CRASH has no CAN-C case
- **Fact:** ECALL_PWM_ACK_CRASH (E_CALL1_100 / E_CALL_PWM_SIGNAL_ACK, record byte 873, -1 to +1 s)
  is fed over CAN on EV but is in neither V5 spec, so no script covers it.
- **Question:** Add it to the EV spec (and the scripts)?
- Decision:

### H3. EV AES_SYS_STS value 7
- **Fact:** The M314 DBC value table names 7 "Failure" but the signal's range is [0|6]. The config
  now follows the range (1, 2, 3, 5, 6, as U171); the V5 EV spec drives 7 (18 cases).
- **Question:** Is 7 a valid state (then the DBC range is wrong) or out of range?
- Decision:

### H4. Old U171 / Z121 BATT_VOLT message content scripts
- **Fact:** scripts/EDR_Element_ID_BATT_VOLT_TestCase_52_8/9/10_MCF_* cannot create the fault
  (MBFM7_100 has no CRC or counter). Left in the old sets (E2); the simple set and COMBINED drop them.
- Decision:

### H5. Shared-library files changed outside this work
- **Fact:** During this work other edits reached the shared library: core_functions.py was
  replaced at 03:50 (fault-time measurement, HS CAN, Wait(150)) and later got the PROVEOUT Wait,
  the squib TTF read and the RSU 0 LSB curve; check_sequence.py (04:39) and jscript_translation.py
  (03:53) changed too. None of these is from this work. The commit holds only this work's
  core_functions.py changes (CAN_Wakeup, CAN_Wakeup_Restore, the legacy wakeup functions kept,
  `__all__`, the HPCC alias); the rest stays uncommitted for your review.
- Decision:

### H6. W616
- **Fact:** W616 has the U171 structure, so it still has the nine entries C4 commented out in
  U171 / Z121, and the M310 / U171 placeholder values (C1).
- Decision:

---

## I. Follow-up decisions, 2026-10-22

- **Supply levels:** "supply levels like the voltage number can come from power config, but dtc
  to be taken from configuration control". The UV / OV scripts import NOMINAL_VOLTAGE and
  UNDER/OVERVOLTAGE_TEST_VOLTAGE from power_config and Under_Voltage / Over_Voltage from
  configuration_control. The CANC_*_VOLTAGE names round 8 added to canc_config are removed
  again (EV keeps its own CANC_UNDER/OVERVOLTAGE_TEST_VOLTAGE, which the CANC suite uses).
- **DTC read margin:** a CAN fault's DTC (node absent, message timeout, message content, signal
  content) is read after `Wait(qualification)` and then
  `Wait(record_ready_ms + tolerance_ms + DTC_READ_EXTRA_WAIT_MS)`: tolerance_ms is
  CAN_FAULT_TIMING_TOLERANCE_PERCENT (10 %) of the qualification time, record_ready_ms is
  edr_config's record_ready_wait_ms (5 s), DTC_READ_EXTRA_WAIT_MS is 2000 (canc_config). In
  the simple scripts (U171 / Z121 452, EV 495) and the COMBINED scripts. U171 / Z121 had no
  tolerance setting; they take the M314 / M210 value, 10 % (assumed, to confirm). The old
  scripts/ sets are not changed.
- **Commit:** the shared-library and config updates outside this work are committed too.

---

## J. Round 9, 2026-10-22: one configuration per DBC

User: "I now correctly added the dbc files of each of the project, M210 is having HSCAN as well"
and "keep seperate configs for EVs as the dbc are different, and also for ICE U171 and Z121 as
well". DBCs in `project_dbc/`: u171 (unchanged), z121 (new, its own), m314 (`SVNID_41243`;
GEAR_ACTUAL on VCU11_FD_10 now names the SRS as receiver, node / bus-type attributes renamed),
m210 (`40250_22042026` FD + HS, no longer a copy of m314's). Offline only, nothing on a bench.

### J1. M310_M314_M110 = M314 DBC
- **Fact:** canc_config already matches the M314 DBC (only its "Reserved (raw N)" labels and the
  V unit differ, on purpose). Only comments changed: "M314 / M210 DBC" now reads "M314 DBC".

### J2. New project `projects/M210` (EV, M210 DBC)
- **Done:** every EV config copied with the project name and variant keys M210. canc_config keeps
  the M314 body and ends with an "M210 DBC ALIGNMENT" block (statements, as the M310 hand blocks):
  E_CALL1_100 on CAN-FD with a 1-bit E_CALL_PWM_SIGNAL_ACK (0 PWM_Signal_Ok, 1 Not_Ok); the six
  SRS2_100 signals, E_CALL_CRASH_ACK, SRS_OCS_PASS_CLASS_FAULT_STS, VCU2_FD_100 BRK_SWITCH,
  CTRL_BRAKE_LIGHT and PIB_ACTIVE not configured (kept in M210_DBC_ABSENT_DEFS); STPS zone default
  zone 2. Checked against the M210 DBCs: 0 mismatches.
- **Inference (to confirm):** the GEAR_ACTUAL element is fed from VCU2_FD_100, the only frame that
  brings GEAR_ACTUAL to the SRS in M210. Node absent still stops VCU11_FD_10 (VCU key frame), so the
  set gains GEAR_ACTUAL message timeout cases (18.22-18.24).
- **Scripts:** EDR CAN-C simple 1220 (1163 own + 57 not applicable: STS_ENG, Clutch_Sts,
  CTRL_BRAKE_LIGHT, PIB_ACTIVE) with runners; COMBINED 15 (59 parameters); Fault_List per-DTC 137
  ready + 180 review. Offline simulation: own set 0 failing steps at T0 offsets 0 / 180 / 600 ms;
  COMBINED 0; not-applicable set passes under the foreign model apart from the default-VC SNR
  finding (EMS, as EV).
- **Question:** the values the M210 bench has not supplied yet are the M314 ones, marked "M314
  value": EOL and variant-code bytes, ECU identities (W613 software numbers), bench paths, crash
  curves (config/crash_curve_config.py uses the EV set: the shared crash_configuration has no M210
  entry). The M210 fault_list_config has only the common EV DTC section (the M310 Fault List
  workbook's FM_ monitors are not confirmed for M210). Please supply or confirm them.
- Decision: 1. "yes it is fine to take gear from VCU2_100 for M210, i will look into it while running
  them" 2. "EOL, VC and crash curves will be updated on my remote environment pc and hil setup and in the
  project config" 3. "Fault list of EVs are common, but the Dtcs to be taken from the Canc_config only, do
  not use faultlist config for these scripts" - meaning the EDR CAN-C scripts: their on-fail DTCs come from
  the existing canc_config, nothing is added to canc_config.
  - **Outcome (2026-10-22):** GEAR_ACTUAL stays on VCU2_FD_100 for M210. EOL / VC / crash curves left
    to you (the "M314 value" placeholders stay). M210 fault_list_config is now the EV fault list (1055
    faults, the same as M310_M314_M110): tools/build_m310_fault_list_config.py writes both EV projects
    (build_common_dtc_dictionary OWN_BUILDER: M310_M314_M110, M210); M210 FAULT_TIME_MEASUREMENT_LAG_MS
    is 0 (not measured on its bench). Checked: every on-fail DTC of the EDR CAN-C simple and COMBINED
    scripts (U171, Z121, M310_M314_M110, M210) comes from canc_config (its DTC tables, or a
    not-applicable definition's fault_logic in canc_config); the crash / variant-code DTCs from
    configuration_control; none reads fault_list_config.

### J3. Z121 = Z121 DBC
- **Done:** the nine entries round 8 (C4) commented out against the U171 DBC are back - the Z121
  DBC carries them all (MBFM_SLEEP / MBFM_ACTIVE RESERVED_2, MBFM_WAKEUP_REASON, STS_ESC, STS_ABS,
  STS_TCS, SEAT_OCCUPANT_FAULTY_STS, SEAT_OCCUPANT_STS, RESERVED_SRS); SEAT_OCCUPANT_FAULTY_STS MAX
  15 (4-bit). Checked against the Z121 DBC: 0 new mismatches.
- **Done:** STS_ABS / STS_TCS (ESC2_10) and STS_ESC (ESC5_10) are now Z121's own EDR elements (state
  values from the Z121 DBC, the EV series 53 / 56 / 55 arrays). The ICE spec has no case for them,
  so their 48 scripts follow the EV numbering; ESC2_10 has no CRC, so STS_ABS / STS_TCS have
  message timeout cases instead of message content. Z121 set 1136 = 838 own + 298 not applicable;
  COMBINED 50 parameters. Offline: own set fails only on the known default-VC SNR bits (24).
- **Question:** the Z121 per-DTC U100400 message timeout script now stops MBFM_WAKEUP (the first
  MBFM frame that is not the key frame and carries a real signal; MBFM_ACTIVE / MBFM_SLEEP carry
  only RESERVED_2, which the generator now skips). U171 stops MBFM5_100. Which MBFM frame should
  the ECU's message timeout be tested on?
- **Question:** the Z121 DBC carries MBFM_WAKEUP / MBFM_ACTIVE / MBFM_SLEEP / SRS_ACTIVE (no
  NmMessage attribute). E4 keeps CAN NM cases out of ICE; does that still hold for Z121?
- Decision: "there is no can wakeup in z121, the message says wakeup but it is not supported".
  - **Outcome (2026-10-22):** Z121 canc_config: MBFM_WAKEUP / MBFM_WAKEUP_REASON commented out (in the
    DBC, not supported). Z121 simple set without CAN wakeup cases: 1070 = 788 own + 282 not applicable
    (66 CAN wakeup scripts and run_CAN_Wakeup_Full removed); added message timeout cases numbered after
    the spec's last case (STS_ABS / STS_TCS 18-20). U100400 message timeout stops MBFM5_100 again, as in
    U171. E4 stands: no CAN NM cases in ICE. Offline: own set fails only on the 24 default-VC SNR
    bits, COMBINED 0. The old Z121 scripts/ set (E2, kept) still has 55 CAN wakeup scripts.

### J4. Found, not changed
- U171 and Z121 CAN_TX_MESSAGE_CONFIG list STS_HIGH_BEAM / STS_LOW_BEAM under MBFM7_100 (the DBCs
  have them on MBFM1_100) and a frame SAS1_10 no DBC has (EPS_SAS1_10 is the real one; nothing
  reads SAS1_10). Older U171 structure, not caused by the new DBCs.
- vin_config.py of M310_M314_M110 (and its M210 copy) fails to import on its own: READ_SID is not
  defined. No script imports it.
- tests/test_common_edr_canc_specification.py points at m314_dbc/SRS_FD_40777.dbc and
  SRS_HSCAN_40250_22042026.dbc, which no longer exist there (renamed in 7841f8e48).
- Decision: "In U171, Z121 change the STS_High and Low beam to DBC defined MBFM1_100 only".
  - **Outcome (2026-10-22):** U171 / Z121 CAN_TX_MESSAGE_CONFIG MBFM7_100 now lists BATT_VOLT only (the
    beams stay on MBFM1_100). The EDR CAN-C scripts are unchanged by it (they read fault_logic). SAS1_10,
    vin_config and the spec test DBC paths are still open.

