# Framework_IOEM_Py — HIL Bench Framework Review Points

| | |
|---|---|
| Date | 2026-10-22 |
| Scope | `shared_libraries/` (19,847 lines), the generated and hand-written test scripts under `projects/`, the suite runners, the repository structure |
| Product | Airbag ECU (SRS / SC3 2S ACU) HIL bench automation on ARIA 5.20 through the `apym` 2.6.7 SDK |
| Method | Static reading of the code, cross-checked against the `apym` SDK source (`C:\Python 3.14.0\Lib\apym-2.6.7\src\apym`); offline measurements (import time, config-lookup cost, call-site counts); the existing offline wrapper checker |
| Bench | **Nothing was run on a bench, and no framework file was changed.** The only file written is this one. |

**Evidence labels used throughout**

- **Fact** — read in the code or measured on 2026-10-22; the location is given.
- **Inference** — follows from facts but was not observed on a bench (for example timing drift whose size was not measured).
- **Assumption** — a project value or bench property this review could not confirm. It needs your confirmation.
- **Confidence** — H / M / L, how sure the conclusion is.

**Relationship to earlier records.** `docs/improvements/` already holds reviewed items:
`jscript-wrapper-review.md` (applied 2026-10-22: the RESULT verdict mapping, UDS single-send and security-access no-retry), `bootstrap-layer.md` (split-brain project detection) and `shared-library-blockers.md`.
Items already recorded there are referenced here, not repeated. One update to them: `shared-library-blockers.md` item 1 (`configuration_control` NameError) **is resolved**. Fact: `import_list` imports cleanly with a project set (measured, §3.12).

---

## 1. Executive Architecture Summary

### 1.1 How the framework is layered (as built)

```
 Runners (94 subprocess runners + 12 in-process runners)          projects/*/modules/*/scripts*/run_*.py
   │  one Python process per script (subprocess) or runpy in one process
   ▼
 Test scripts (~12,100 .py on disk under projects/; generated + hand-written)
   │  from Framework_IOEM_Py.shared_libraries.import_list import *   (1,367 names)
   ▼
 Layer 3  core_functions.py (5,702 lines)   power, UDS/security, DTC, fault-free profile,
          fault_monitor.py, check_sequence.py, edr_decoding_functions.py, data_conversions.py ...
   │  lazy proxies (CAN, RESULT, PS, RSU, SPI ...) to break an import cycle
   ▼
 Layer 4  jscript_translation.py (4,552 lines)   CAN / PS / RSU / SPI / SQUIB / LAMPS / RD / ACL / RESULT
   │  ensure_runtime() → module globals (Api, channel ids)
   ▼
 apym SDK  (apym.connection.Instance, apym.functions.Api, apym.reports.ApymReports)
   ▼
 ARIA host (TCP)  →  bench cards: power, CAN/CAN-FD restbus, RSU, SPI sensors, squib loads, lamps

 Configuration: shared configuration_control.py (legacy, partly project-specific)
                + projects/<P>/config/*.py resolved by project_config_loader (call-stack walk)
 Reporting:     RESULT.*  →  ApymReports (static, single report per process)  →  test_results/<P>/<day>/
```

### 1.2 Strengths (keep and standardise on these)

| Strength | Evidence |
|---|---|
| Project data is moving into per-project config modules, with generators and `--check` drift guards (Fault_List, IO-control, UDS, CAN-C config). | `tools/`, `projects/*/config/`; Fact |
| The newer generated EDR CAN-C scripts restore the bench in `finally`, check the return of every fault-injection call, and always call `write_to_file()`. | `projects/U171/modules/EDR/scripts_simple/EDR_Element_ID_ACC_PED_TestCase_8_6_MTO_Pre.py:108-176`; Fact |
| The M310 CANC runner judges a script by the verdict apym writes in the report (`<!--PASSED-->`), streams output live, saves results after every script and handles Ctrl+C cleanly. It is the reference runner. | `projects/M310_M314_M110/modules/CANC/scripts/run_all_canc_automatic_scripts.py:455-505`; Fact |
| The UDS path sends a request exactly once and never repeats a seed/key exchange. This respects ISO 14229-1 suppressPosRspMsgIndicationBit and the NRC 0x36 attempt counter. | `jscript_translation.py:413-461`, `:464-515`; Fact |
| `faultTimeMeasurement` uses a monotonic clock, an explicit configurable timeout, and logs its polling cadence. | `core_functions.py:2286-2366`; Fact |
| The EDR record parser is strict: it raises on a wrong positive-response prefix or a short record instead of decoding garbage. | `edr_decoding_functions.py:162-192`; Fact |
| Reports and logs are time-stamped per run and per project, so earlier evidence is never overwritten. | `core_functions.py:571-600`; Fact |
| An offline wrapper checker exists and passes. | `tools/check_jscript_wrappers_offline.py` → **94/94 pass** (run 2026-10-22); Fact |

### 1.3 High-level bottlenecks

1. **Verdict integrity is not guaranteed end-to-end.** 92 of 94 subprocess runners count a script as PASSED when its process exits 0. Scripts never exit with the report's verdict. apym writes `PASSED` for any report without a failed step, including a report with zero steps or one cut short by an exception (C-01, C-02).
2. **The DTC read used 25,608 times treats a negative response as "no DTC".** A "no DTC expected" check passes when the ECU rejected the request (C-03).
3. **The hardware wrappers have no single error contract.** Success and failure both come back as strings, `None`, an `Exception` object, `"0000"`/`"1111"` or a list. Callers mostly ignore them, so a fault injection that did not happen goes unnoticed (H-01).
4. **Preconditions and teardown are not verified.** The fault-free profile, used at 18,436 call sites, ignores security-access and write results. Several suites leave faults injected after an exception (H-02, H-03).
5. **A shared library holds project and personal data.** Examples: a UPP_EV loadbox path used for every project, three different DTC availability masks, personal network paths, and UPP-only power cycling in `NVM_Clear_L61` (2,759 calling files) (H-05, H-09).
6. **Fixed sleeps are used where conditions should be polled, and the same work is repeated per script.** Every EDR simple script runs the fault-free profile twice: at least 9 s of fixed sleeps × 3,489 scripts ≈ **8.7 h per full pass** of the three EDR suites (§3.12).
7. **The repository structure slows every developer action.** 102,761 tracked files, 83,558 of them converted ARIA documentation; 1,423 tracked `.pyc` files; `git status` takes more than 2 minutes; 437,720 lines of near-identical hand-maintained EDR scripts (§3.12).
8. **Flashing can power-cycle the ECU while Memtool is still programming it** (C-04).

**Overall assessment.** The framework drives the bench capably. In its current state, however, a green regression summary is not reliable evidence for safety-critical ECU verification. The four Critical items are all about verdict integrity or bench safety and should be closed before the next bench regression whose results will be used as evidence. Confidence: **H** for the existence of every Critical item, all of which are Facts with code locations. How often they bite in practice is **Inference** and needs bench data.

---

## 2. Critical Bugs, Safety Risks & Edge Cases

### 2.1 Summary register

| ID | Sev | Finding | Location | Basis | Conf |
|---|---|---|---|---|---|
| C-01 | **Critical** | Runner verdict = process exit code; scripts never exit with the report verdict, so a FAILED report counts as PASSED | 92 runners, e.g. `U171/.../scripts_simple/run_master.py:422-435` | Fact | H |
| C-02 | **Critical** | Aborted or empty test produces a PASSED HTML report | apym `report_generator.py:74-82`, `reports.py:285-292`; EDR simple scripts `:108-176` | Fact | H |
| C-03 | **Critical** | `Read_DTC` treats an NRC as "no DTC present"; the availability mask is hard-coded 0xCB; the bus-capture fallback can return a final 0x78 "pending" as the answer | `core_functions.py:2575-2639`; `jscript_translation.py:344-349` | Fact | H |
| C-04 | **Critical** | `Software_Flashing` power-cycles the ECU 3 s after starting Memtool asynchronously; the flashing thread reports concurrently with the main thread | `winidea.py:421-438`, `:441-463` | Fact | H |
| H-01 | High | Wrapper error contract is inconsistent; fault injection and crash-curve loading are not verified; a false pass in the NM wakeup check | `jscript_translation.py:1272-1534`; `core_functions.py:2777-2934`, `:4139` | Fact | H |
| H-02 | High | Fault-free profile (precondition) is not verified: security and write results ignored, no wait after the last power-on, no DTC check after clear | `core_functions.py:2684-2764`, `:3361-3440` | Fact | H |
| H-03 | High | Teardown gaps: injected faults stay after an exception (Z121 CAND); the CAN log is never stopped; runners have no timeout or safe-state reset | Z121 CAND scripts `:100-192`; `core_functions.py:626`; runners | Fact | H |
| H-04 | High | Power sequencing: BATT is removed before IGN, fixed 4 s off-time, no shutdown/NvM wait, `POWER_OFF` External branch is a no-op, `POWER_ON` swallows errors | `jscript_translation.py:3206-3233`; `core_functions.py:748-823` | Fact (code) / Inference (NvM effect) | M |
| H-05 | High | Shared `configuration_control` carries project and legacy data: UPP_EV loadbox used by `RSU.ResetRSU` for every project; three DTC availability masks; duplicate definitions | `configuration_control.py:187-192`, `:331/353`, `:367`, `:494-506`, `:671` | Fact | H |
| H-06 | High | ARIA init masking: "already initialized" counted as success, while apym marks itself initialized *before* the handshake; init is retried on every wrapper call when it fails | `apym_imports.py:61-75`, `:219-229`; apym `connection.py:31-51`; `jscript_translation.py:525-646` | Fact | H |
| H-07 | High | EDR sampling loops sleep a full interval *after* doing work, so samples drift away from the T0 grid (3,489 generated scripts) | `EDR_..._8_6_MTO_Pre.py:119-143` (all simple scripts share the template) | Fact (structure) / Inference (size) | M |
| H-08 | High | Steps that cannot fail (tautologies, verdicts recorded before the action) | `core_functions.py:1265`, `:1274`, `:1899`, `:1971`, `:2079`, `:2091`, `:3423`, `:4320-4321` | Fact | H |
| H-09 | High | Project-specific, personal or broken data inside shared helpers (IMU calibration typo, ENS curve paths, UPP-only power cycle in `NVM_Clear_L61`) | `core_functions.py:1459-1467`, `:2640-2681`, `:3065-3558`, `:4222`, `:4245` | Fact | H |
| M-01 | Medium | Importing the shared library needs an active project (eager `DTC_CODES`), which defeats the lazy design | `core_functions.py:305-319` | Fact (measured) | H |
| M-02 | Medium | Each project-config lookup walks the call stack: 0.9–1.7 ms per lookup (≈1,000× slower than with the env var) | `project_config_loader.py:59-75`; `framework_registry.py:20-48` | Fact (measured) | H |
| M-03 | Medium | Every `SendDiagByValues` makes about 8 ARIA calls and sleeps a fixed 20 ms; channel ids are re-resolved per request | `jscript_translation.py:200-208`, `:352-372`, `:413-461`, `:1600-1614` | Fact (code) / Inference (latency) | M |
| M-04 | Medium | `faultTimeMeasurement` times from function entry, not from fault injection; the resolution is not reported | `core_functions.py:2325-2346` | Fact | M |
| M-05 | Medium | Legacy `SecurityAccess` is broken in every branch (latent: no direct project caller) | `core_functions.py:966-1098` | Fact | H |
| M-06 | Medium | `GetSWInfo` / `ReadPlatformSoftwareVersion` always raise (`chr()` on a `str`) (latent) | `core_functions.py:1289-1299`, `:1317-1337`, `:2375-2388` | Fact | H |
| M-07 | Medium | `ExpectInternalErrors`: the retry has no effect; an `Exception` response crashes it; unconditional 1 s sleeps; the error list file is a platform path | `fault_monitor.py:83-92`, `:300-302`; `configuration_control.py:335` | Fact | H |
| M-08 | Medium | Report groups left open on exception or early return, so later steps nest under the wrong group | `core_functions.py:748-776`, `:894-925`, `:1981-2015`, `:2061-2126`, `:2640-2764`; `winidea.py:438` | Fact | H |
| M-09 | Medium | Star-import copies runtime globals that are still `None` (`Api`, `CurveData`, `simulation_id`, `diag_ch*`) | `jscript_translation.py:46-58`, `:67-84`; `import_list.py` | Fact | H |
| M-10 | Medium | No timeout on any subprocess (Ascent, Memtool, Saleae, all runners) | `ascent_batch_lib.py:228-231`; `infineon_memtool.py:39,74,100`; `core_functions.py:3480`; runners | Fact | H |
| M-11 | Medium | `MakeJsonFlashFile` edits its module-level template in place, so a second call reuses the first call's S37 paths | `ascent_batch_lib.py:188`, `:234-256` | Fact | M |
| M-12 | Medium | Test infrastructure: no `pytest` in the bench interpreter, no CI, no dependency manifest, `pyrightconfig.json` points at a missing interpreter | repo root; `pyrightconfig.json` | Fact | H |
| M-13 | Medium | `manage_variant_code` defaults its base to all `0xFF` (every node enabled) | `core_functions.py:4745` | Fact | H |
| M-14 | Medium | In-process runners (`runpy`) share module state across scripts and produce no verdict summary | `*/Fault_List/scripts/dtc/run_dtc_fault_list.py:195-222` | Fact | M |
| M-15 | Medium | ISO-TP reassembly in the bus-capture fallback lacks the CAN-FD SF escape and 32-bit FF length; a late answer can be attributed to the current request | `jscript_translation.py:291-349` | Fact | M |
| M-16 | Medium | PS / RSU actions are verified by acknowledgement only; the apym `Power.is_set` readback is unused | `jscript_translation.py:3188-3273`, `:2947-3010` | Fact | M |
| L-01..L-14 | Low | Hygiene items, listed in §2.4 | — | Fact | H |

### 2.2 Critical items in detail

#### C-01 — A FAILED report is counted as PASSED by 92 of 94 subprocess runners

- **Fact.** `run_master.py:433` sets `status = "PASSED" if completed.returncode == 0 else "FAILED"`. The same exit-code rule is in **92** runners (found by classifying every `run_*.py` that uses `subprocess`). Only the 2 M310 CANC runners read the report verdict.
- **Fact.** Test scripts never call `sys.exit` with the verdict. Of 1,136 U171 EDR simple scripts, 0 do; the 25 matches are the runners themselves.
- **Fact.** A step failure is written to the report but does not raise, so the process exits 0.
- **Failure scenario.** `EDR_..._ACC_PED_TestCase_8_6_MTO_Pre.py` records 40 FAILED sample checks and exits 0 → `run_master_results.json` has `0` → the summary line says "passed". A regression summary therefore says "N passed" for tests whose reports are red.
- **Fix.** Use R-1 (harness that exits with the report verdict) and R-2 (runners read `<!--PASSED-->` plus the step count, as the CANC runner already does).

#### C-02 — An aborted or empty test leaves a PASSED report

- **Fact (apym).** `report_generator.py:75-77`: `result = "PASSED"` unless `root_node.passed == False`. `reports.py:285-292`: `passed=None` steps compare expected with obtained. A report with no step, or with comments only, is therefore `PASSED`.
- **Fact (scripts).** The EDR simple scripts use `try: … finally:` with **no `except`** (`…8_6_MTO_Pre.py:108-176`). An exception during step 4 runs the restore and `write_to_file()`, so the HTML says **PASSED** for the samples taken so far. The exception itself is never recorded as a step. The process exits 1, so only the exit code reveals the abort.
- **Fact (opposite case).** Z121 CAND scripts catch the exception and record a FAILED step, but exit 0 (`testCase_DIDList_Testcase129.py:186-187`). That gives the opposite mismatch.
- **Fact.** The CANC runner accepts a report with `successStepsCount` `0/0` as PASSED (`run_all_canc_automatic_scripts.py:498-499`).
- **Fix.** R-1: an exception becomes a FAILED step, a report with zero steps is an error, and the exit code follows the verdict.

#### C-03 — `Read_DTC` passes "no DTC expected" when the ECU answered with an NRC

- **Fact.** `core_functions.py:2590-2595`: `dtcSplit()` strips the header only when it is exactly `0x59 0x02 0xCB`, then groups the remaining tokens in fours.
  - An NRC `0x7F 0x19 0x31` has 3 tokens, gives no group, so the obtained list is `[]`.
  - With an expectation of no DTC (`Read_DTC(..., Read_DTC_Resp, ...)`), `mismatches` and `extras` are empty, and `:2630-2636` records **two PASSED steps**: "The Expected DTCs are obtained" and "Check No DTC Number" (`"[]" == "[]"`).
- **Fact (apym).** `Diagnostics.Uds.request` *returns* negative responses as bytes and raises only on timeout (`functions.py:1346-1367`). The NRC path is therefore reachable on every DTC read.
- **Fact.** `jscript_translation.py:344-349`: when a request times out and the bus capture saw only `7F 19 78` (responsePending), `_decode_logged_diag_response` skips the 0x78 frames but then **returns the last one anyway** (`return messages[-1]`). A timed-out request is then reported as a negative answer, which feeds straight into the false pass above.
- **Fact.** The availability mask is hard-coded `0xCB` in `Read_DTC`, while `G_Var.DTCStatusAvailabilityMask = 0xFF` (`configuration_control.py:671`) and `Read_customer_DTC` expects `0x59 0x02 0xFF` (`core_functions.py:2503`).
  - On an ECU reporting a different mask, the header is not stripped and every record is misaligned. That causes false FAILs with DTCs present, and false PASSes without.
- **Blast radius (Fact).** 25,608 `Read_DTC(` call sites under `projects/`. At least 746 pass only the header (`Read_DTC_Resp`/`Read_DTC_Resp_CANC`), meaning "no DTC expected". Many more compute expectations that can be empty.
- **Fix.** R-3: a strict 19 02 parser that rejects an NRC, an empty answer, an odd length and a wrong availability mask, and compares DTC→status maps. R-13: never return a 0x78 as the final answer.

#### C-04 — The ECU can be power-cycled while Memtool is still flashing

- **Fact.** `winidea.py:425-427`: `p = subprocess.Popen([G_Var.IMTMemtool, mtb])` → `Wait(3000)` → `POWER_CYCLE(POWERSOURCE)`. The process is never waited for. Flashing that takes longer than 3 s is interrupted by a power cut.
- **Fact.** `mtb = r'C:\sura2\auto.mtb'` (`configuration_control.py:579`) is a personal path.
- **Fact.** `StartSoftwareFlashing` (`winidea.py:441-463`) runs this in a **daemon thread**. That thread calls `CommentStep` / `POWER_CYCLE` → `RESULT`, while the main thread also writes to `ApymReports`. `ApymReports` is a static class with one shared insertion node (`reports.py:46-50`), so concurrent reporting corrupts the group tree.
  - Being a daemon, the thread is also killed abruptly if the main script ends mid-flash.
- **Fact.** `rep.close_group()` at `winidea.py:438` has no matching `add_group`, so it closes the caller's group.
- **Inference (H).** An interrupted flash leaves the ECU partly programmed (application or calibration), so later results are not attributable to a known software build.
- **Blast radius (Fact).** 3 call sites. Until fixed, do not use `Software_Flashing` / `StartSoftwareFlashing`.
- **Fix.** R-11.

### 2.3 High items in detail

#### H-01 — No single error contract in the hardware wrappers

- **Fact. What the wrappers return:**
  - `CAN.PeriodicDisableFrame` returns a success *string* or `str(ex)` (`jscript_translation.py:1272-1283`).
  - `ChangeSignalValue` returns `None` on success, `str(ex)` on failure (`:1484-1534`).
  - `SendDiagByValues` returns a string, or the **`Exception` object** (`:1600-1614`).
  - `PeriodicChangeSignal` returns a string or the `Exception` (`:1401-1431`).
  - `SetPeriodicFrame` returns `None` or a string (`:1795-1840`).
  - The PS leakage calls return `"0000"`/`"1111"`.
  - The newer wrappers return `["0000", …]` / `["1111", …]`.
- **Fact. False pass:** legacy `wake_ecu_over_can_nm` checks `CAN.ReceiveFrame(...) is not None` (`core_functions.py:4139`). `ReceiveFrame` returns `str(ex)` on error (`:1666-1674`), so an **error counts as "ECU sent its NM frame"**. 63 call sites, all in M310. The newer `CAN_Wakeup` does it right (`:3935`, `not isinstance(seen, str)`).
- **Fact. Load reported without checking:** `perform_crash` / `load_crash_curves` / `load_crash_curves_can_wakeup_condition` ignore the result of every `RSU.SendAcceleration` and `SPI.SendCrashData` call, then record "Crash Files … successfully loaded" (`core_functions.py:2805`, `:2868`, `:2925`). The wrappers do record a FAILED step on exception, so the report shows both a failure and a success line, and the crash is still triggered with whatever curves the cards hold. Blast radius: 8,643 `load_crash_curves(` call sites.
- **Fact.** `disable_all_*_frames` / `enable_all_*_frames` log the result string without checking it (`:3000-3056`); the enable variants log the literal `"enable_frame"`.
- **Fix.** R-4 (strict action layer that raises and records) and R-5 (fault context manager).

#### H-02 — The fault-free profile (the precondition of almost every test) is not verified

- **Fact. Where it fails silently:**
  - `fault_free_profile_classic_can` / `_can_fd` (`core_functions.py:2684-2764`) call `Internal_Security_Access(0x61)` and `(0x01)` and ignore the `TestStatus.Failed` they return.
  - EOL, variant-code and VIN writes go through `DataIdentifier_Read_Write`, which on an NRC **returns without recording any verdict** (`:3435-3438` writes; `:3415-3416` reads). The results are then only `LogAction`ed.
  - `fault_free_profile_can_fd` sends `14 FF FF FF` straight after the last `PS.Power_Cycle()`, with no wait for ECU start-up (`:2762-2763`).
  - No DTC read confirms the bench is actually fault-free.
- **Blast radius (Fact).** `fault_free_profile(` has 16,214 call sites, `_classic_can(` 2,185, `_can_fd(` 37.
- **Inference (M). What that does to a test:**
  - A test can start with security locked, the wrong variant code, or DTCs that qualify during start-up *after* the clear.
  - In the EDR scripts, which compare the full DTC set, this shows up as intermittent FAILs.
  - In "no DTC" checks combined with C-03, it can hide a real fault.
- **Fix.** R-7 (ready-poll after power-on) and R-3. Make the profile end with a strict "no DTC except the configured optional ones" check, and return a bool the harness can act on.

#### H-03 — Teardown and bench-state gaps

- **Fact.** Z121 CAND `testCase_DIDList_*` (184 scripts) inject a squib fault and `PS.SetLeakageGNDBusLow()`, but remove them inside the `try`, not in `finally` (`testCase_DIDList_Testcase129.py:100-149`, `:188-192`). After an exception the squib fault and the leakage stay on for the next script.
- **Fact.** `create_report_and_logging` discards the log id that `StartLoggingToFile` returns (`core_functions.py:626-632`). No script can stop the per-test CAN log. This is already recorded as an open item in `jscript-wrapper-review.md` ("Problems found in callers").
- **Fact.** No runner has a timeout. Not one `timeout=` occurs in any `run_*.py`. None resets the bench to a safe state between scripts.
  - A hung ARIA call blocks the regression forever.
  - A script killed by the operator leaves frames disabled, RSU faults set or voltage changed.
- **Fact.** `run_master.py` buffers each script's whole output (`capture_output=True`), so an operator instruction in a semi-automatic script is not shown until the script ends.
- **Fix.** R-1, R-2 and R-5, plus a `bench_safe_state()` routine the runners call after any non-PASSED script.

#### H-04 — Power sequencing

- **Fact. Order and timing:**
  - `PS.Power_Cycle` and `PS.Power_OFF` switch **BATT off before IGN** (`jscript_translation.py:3214-3215`, `:3225-3226`); `load_crash_curves` does the same (`core_functions.py:2847-2849`).
  - The off-time is a fixed `Sleep(4)` (`:3227`).
  - There is no wait for ECU shutdown or NvM write-back.
- **Inference (M).** Cutting KL30 before KL15 is a hard power loss rather than an orderly shutdown. Whether DEM/EDR data written just before the cut survives then depends on how far the ECU's NvM write-back got. DTC "historic after power cycle" checks and EDR-record checks therefore depend on timing.
- **Assumption.** This needs confirming against the ECU's shutdown and NvM requirement: the KL15→KL30 delay and the shutdown time.
- **Fact. Legacy path:**
  - `POWER_OFF` with `Power_Type == External` is `#TODO … pass`, a silent no-op (`core_functions.py:756-759`).
  - `POWER_ON` catches every exception and only `print`s it (`:820-821`), so a failed power-on is invisible in the report.
  - The `power_supply` argument of both is ignored.
- **Fact.** apym offers `Chassis.Power.is_set()` for readback (apym `functions.py:3393+`); no wrapper uses it.
- **Fix.** R-7.

#### H-05 — Project data inside the shared `configuration_control.py`

- **Fact. Values that belong to one project:**
  - `AriaFileConfig = r"C:\AriaConfigFile_UPP_EV\…\UPP_EV_LOADBOX1.ldbx"` (`:367`) is read by `RSU.ResetRSU`, `RSU.SetStartUpFile` and `RSU.SetConfigFile` for every project (`jscript_translation.py:2904`, `:2930`, `:3071`).
  - `fault_free_profile_classic_can` calls `RSU.ResetRSU()` (`core_functions.py:2719`). On U171/Z121/M310 it either resets the slots found in UPP_EV's loadbox or fails with "file not found".
- **Fact. Three DTC availability masks:** `0xCB` (`DTC_StatusMask`, `:190`), `0xFF` (`G_Var.DTCStatusAvailabilityMask`, `:671`), and `0xFF` hard-coded in `Read_customer_DTC`. Plus the 0xCB literal in `Read_DTC` (C-03).
- **Fact. Values defined twice; the later definition silently wins:**
  - `TEST_SANDBOX_DIRECTORY` (`:331` vs `:353`)
  - `WarningLampCheck` (`""` at `:495`, `"YES"` at `:500`)
  - `PROVEOUT_COMPLETION_TIME` (`:491`, `:506`)
  - `ReadDtcStatusMask` (`:494`, `:499`)
  - `Internal_Fault_Active` (`:489`, `:504`)
- **Fact. Legacy values from other programs:** `G_Var.MainFolder = r"C:\Project\Geely_GEEA3_L946"`, MKS sandbox paths, `SC31_0IA_R33` software versions, P2/P2\* bytes, platform DTCs (`Crash_DTC = 0x906196` …).
- **Fix.** Move every project-variable value into `projects/<P>/config/`. Leave `configuration_control` with protocol constants only (ISO 14229 SIDs, sub-functions). Add a checker that fails on duplicate top-level assignments.

#### H-06 — ARIA initialisation can report success on a dead connection; init is retried on every wrapper call

- **Fact (apym).** `Instance.init()` sets `Instance.__aria_instance = AriaInstance(channel)` **before** `initialize()` runs the handshake (`connection.py:48-51`). If the handshake fails, the instance stays set, and every later `init()` raises "Aria apis manager already initialized".
- **Fact (framework).** `init_aria()` and `_try_load_real_apym()` treat that message as success (`apym_imports.py:66-72`, `:224-229`). `ensure_runtime()` then proceeds with `Api` bound to a broken instance.
- **Fact.** When `ensure_runtime()` fails, `_runtime_initialized` stays `False`. Every following wrapper calls `require_runtime()` → `ensure_runtime()` → `refresh_apym_exports()` → `Instance.init()` again (`jscript_translation.py:525-646`). With the bench down, that is one reconnect attempt per wrapper call.
- **Fix.** Make `init_aria()` the single explicit entry point; run it once per process and fail hard. Verify the connection with one cheap call (for example `Api.Configuration.get_communication_channels()`) instead of matching message text. Make `ensure_runtime()` fail fast after one failed attempt.

#### H-07 — EDR sampling loops drift away from the T0 grid

- **Fact.** In every generated EDR simple script (`…8_6_MTO_Pre.py:119-143`), each sample does `ChangeSignalValue` → `Wait(interval_ms)` → `GetSignalFromFrame` → `RESULT.InterpretEqualResult`. `Wait` sleeps the **full** interval, and the ARIA calls and report entries come on top of it, so every window is `interval_ms + overhead`. The error accumulates: sample *k* is late by about *k* × overhead.
- **Fact.** T0 is placed by `trigger_index` / `trigger_wait_ms` computed from the ideal grid (`:63-64`).
- **Inference (M).** The overhead per sample was not measured. At 10–50 ms per iteration, a 10–20-sample pre-crash window drifts 0.1–1 s, enough to move samples into the neighbouring window. That causes false FAILs at value changes, or values passing for the wrong reason.
- **Fix.** R-6: a deadline scheduler on `time.monotonic()`, which also flags any window that overran. One template change in the generator fixes all 3,489 scripts.

#### H-08 — Steps that cannot fail

| Location | Why it always passes | Callers (Fact) |
|---|---|---|
| `send_uds_frame` `:1899`, `Send_UDSFrame` `:1971` | `InterpretEqualResult(name, resp, resp)`; even an `Exception` object equals itself | 0 in projects (latent, exported) |
| `DataIdentifier_Read_Write` read without `DataRecord` `:3423` | `ret_str` vs `ret_str`; NRC paths return with no verdict (`:3415-3416`, `:3435-3438`) | 99 + every fault-free profile |
| `SteeringWheelPosition_Config` `:1265`, `:1274` | `response[0] == "0"`; every formatted response starts with `"0"` (`"0x7F …"` too) | 0 direct (latent) |
| `Load_RSU_CrashData` `:2079`, `LoadCrashCurve` `:2091`, `GenerateCurveFile` `:2537` | PASSED step recorded **before** the action | legacy |
| `log_snapshot_byte_after_did` `:4320-4321` | expected = obtained, `TestStatus.Passed` | snapshot helpers |
| `printErrorNames` `fault_monitor.py:289` | `ExpectTestResult(..., True)` | internal-error display |

The PS/RSU `ExpectTestResult(..., True)` / `ResultStep(..., True)` rows are **not** tautologies: apym raises on failure, and the exception path records a FAILED step (apym `Power.set` docstring). They are acknowledgement-only (M-16).

#### H-09 — Project-specific, personal or broken data in shared helpers

- **Fact.** `IMUCalibration_Routine` (`core_functions.py:1459-1467`) hard-codes calibration payloads. `YCalibration` contains the typo `"0x2E 0xFD 0x35 x00 …"`, which `_prepare_diag_payload` rejects as an odd hex run, so **the Y-axis calibration is never sent** and the step fails with a ValueError text.
- **Fact.** `NVM_Clear_L61` (`:2640-2681`) says `### comment this part for projects other than UPP EV ###` above an unconditional `PS.Power_Cycle()`. It is called from **2,759 files** in M310 (1,158), U171 (800), Z121 (790), UPP_EV (7) and W610 (4).
- **Fact.** These functions in the shared library hard-code network paths with personal names:
  - `Front_2sec_*`, `Near_2sec_*`, `Right_2sec_Left` (`:3065-3268`, `V:\…\Christy\…`)
  - `load_front/left/right_crash_curves_ens` (`:3485-3558`, `V:\…\Krishna Girish\…`)
- **Fact.** `Create_Variant_code_error` / `clear_Variant_code_error` / `induce_signal_never_received` hard-code 20-byte DID 0x0101 payloads (`:4222`, `:4245`, `:4266`). `perform_crash` and `load_crash_curves*` hard-code sensor `"GEN6_XY"`. `RunSaleaeCapture` hard-codes `C:\saleae_Automation\saleae_Automation.exe`.
- **Fix.** Move these into `projects/<P>/config/` (paths into `crash_curve_config` / `rsu_config`, payloads into `variantcode_config`, IMU values into `imu_config`). Delete the W616-only ENS and multi-event helpers from the shared module, or move them to `projects/W616/`.

### 2.4 Low items

| ID | Finding | Location |
|---|---|---|
| L-01 | `RESULT.InsertComment("POWER_OFF not handler … {G_Variables.Power_Type}")`: missing `f`, and the variable name is wrong | `core_functions.py:774`, `:818` |
| L-02 | `Set_ECU_PowerVoltage` sets the voltage twice (`:915-916`), has no range check for the 12-bit voltage-box DAC (`:909`), and its exception text names "PeriodicDisableAllFrames" | `core_functions.py:894-925` |
| L-03 | `enable_all_*_frames` log the literal `"enable_frame"` | `core_functions.py:3040`, `:3054` |
| L-04 | `@staticmethod` on module-level functions `TriggerCrash` and `Read_DTC` | `core_functions.py:1592`, `:2575` |
| L-05 | 158 `print()` calls in `core_functions` and `jscript_translation` (for example `"Debug print: I am here--after before crash"` at `:2869`); errors go to stdout instead of the report | both modules |
| L-06 | `Read_DTC` positive step passes expected and obtained swapped | `core_functions.py:2615` |
| L-07 | `ReadEdrDataStructure` prints `edr_structure[100]` (IndexError on short sheets), copies cell by cell with `iloc`, and returns before `close_group()` | `core_functions.py:1981-2015` |
| L-08 | `perform_crash` writes `builtins.CURRENT_CRASH_TYPE` (process-global state) | `core_functions.py:2780` |
| L-09 | `CAN_Wakeup_Disable_UPP` docstring says "disabling" but enables the frames; duplicate `LogAction` in `CAN_Wakeup_Cycle_UPP` | `core_functions.py:3838-3858` |
| L-10 | `create_report_and_logging`: full `inspect.stack()` (reads source context), env-var names different from `framework_registry`, discarded `report_path.exists()`, second-resolution file names | `core_functions.py:539-643` |
| L-11 | apym `direct_write=True` rewrites the whole HTML on every insert (O(n²)). Latent: no script passes `True` today | apym `report_generator.py:65-72` |
| L-12 | `_NoOpReporter` swallows every call, verdicts included, when apym is missing and `strict=False` | `apym_imports.py:140-162` |
| L-13 | `ForceCloseAllExcel` terminates the first `EXCEL.EXE` on the PC, which can be an operator's unsaved workbook | `excel_handler.py:86-93` |
| L-14 | Dead legacy in `configuration_control` (Geely path, MKS sandboxes, `C:\sura2`) and in `core_functions` (about 100 lines of commented-out functions) | — |

---

## 3. Module-by-Module & Function-Level Analysis

### 3.1 `apym_imports.py` (325 lines) — SDK shim

- **How it works.** It locates the apym sdist (`ensure_apym_on_path`, path globbing at import), discovers the offline surface (reports, types) at import, and leaves the hardware connection to `init_aria()`.
- **Good.** Importing never opens a connection. Strict and non-strict accessors.
- **Falls short.**
  - The "already initialized" string match makes a failed handshake look like success (H-06).
  - `init_aria()` → `refresh_apym_exports()` → `Instance.init()` a second time; this is recorded in `bootstrap-layer.md` §3.
  - `_NoOpReporter.__getattr__` turns any typo or verdict call into a no-op (L-12).
  - The apym location depends on `sys.prefix\Lib\apym-*`, with no version pin. ARIA 5.20 ships 2.6.4, the interpreter has 2.6.7 (`jscript-wrapper-review.md`).

### 3.2 `framework_registry.py` / `project_config_loader.py` — project resolution

- **How it works.** Precedence: override → `IOEM_FRAMEWORK_PROJECT` → a walk of the call stack for a `projects/<NAME>/` segment. Modules are cached per `(project, module)`.
- **Falls short.**
  - The project name itself is **not** cached. Every lookup runs `inspect.stack(0)` + `Path.resolve()` per frame. Measured at 0.9–1.7 ms per lookup, against 0.0008 ms with the env var (M-02, §3.12).
  - Helpers such as `_can_wakeup_settings` make 9 lookups per call.
  - The split-brain issue between `infer_project_name()` and `get_active_project()` is recorded in `bootstrap-layer.md` §1. Decide its precedence before adding caching (R-8).

### 3.3 `configuration_control.py` (794 lines)

- **How it works.** Shared constants, enums, `G_Var`, `TestStatus`, imported everywhere through `import_list`.
- **Falls short.** It mixes ISO 14229 protocol constants (good to share) with project values, other programs' legacy and personal paths (H-05, L-14).
  - Duplicate definitions make it impossible to know which value is live without reading to the end.
  - `G_Var` is a mutable class used as a process-global singleton (`IG_Counter`, `Power_Type`).
  - Module-level names `time = 0`, `i = 0`, `timestamp = ""` (`:545-546`, `:582`) are not exported today, but shadow standard names inside the module.

### 3.4 `jscript_translation.py` (4,552 lines) — the hardware abstraction layer

| Area | How it works | Where it falls short |
|---|---|---|
| Runtime (`ensure_runtime`, `:525-625`) | Binds `Api`, simulation and UDS channel ids into module globals once | Retry storm and init masking (H-06); star-import copies stale `None` globals (M-09) |
| Channel resolution (`:89-220`) | Name normalisation (`"HS CAN"` → `HSCAN`, `"Level 61"` …) and preferred defaults | Resolved per call, with one ARIA round trip each (`get_uds_channel_id`, `get_simulation_id`); nothing cached (M-03); `channel-architecture.md` covers the wider design |
| UDS request (`_request_diag_response`, `:413-461`) | Sends once, with a passive bus capture as fallback | Per request: about 8 ARIA calls, `time.sleep(0.02)`, a logger create/stop/remove; the fallback can return a 0x78 (C-03) and lacks the CAN-FD SF/FF escapes (M-15) |
| `RESULT` (`:991-1237`) | Maps verdicts to apym's bool (`_step_passed`, fixed 2026-10-22) | Every comment opens, fills and closes its own group (3 report operations); reporter errors are `print`ed and lost; apym's "no failed step = PASSED" rule is not guarded (C-02) |
| `CAN` simulation (`:1272-1534`) | Thin apym calls with legacy argument shuffling | No single error contract (H-01); legacy positional shuffling (`PeriodicChangeSignal`, `ChangeSignalValue`, `PlayPhysicalValuesCurve`, `SetPeriodicFrame`) guesses argument roles by trying to match a channel name, so a frame named like a channel is misread |
| `CAN` diagnostics (`:1600-1664`) | Formatted `"0x.. 0x.."` strings | Failure returns the `Exception` object, not a string: callers that slice or index it crash or misjudge (for example `DisplayInternalErrors` `[1]`) |
| `CAN.CheckSingleDTC` (`:2099-2164`) | Strict 19 02 parse; rejects an NRC | Good. It is the model for R-3; `Read_DTC` should use the same parser |
| `SPI` / `RSU` (`:2665-3185`) | Curve upload, faults, config files | `SendCrashData` / `SendAcceleration` return `None` both ways (a FAILED step is recorded on exception); `ResetRSU`, `SetStartUpFile` and `SetConfigFile` parse the UPP_EV loadbox (H-05) |
| `PS` (`:3188-3850`) | Power lines, leakage, U-cut | BATT-before-IGN order, fixed 4 s (H-04); acknowledgement-only verdicts (M-16) |
| `ARIA` (`:2307-2660`) | Trigger, deploy times, ODS | `AFT_iTriggerWrapper` returns `None` on success and the `Exception` on failure; `ClearAllDeployTime` loops `LOOP1..15` while the benches number from `LOOP0` (open item in `jscript-wrapper-review.md`) |

### 3.5 `core_functions.py` (5,702 lines) — Layer 3 helpers

A god-module. One file holds report creation, power, UDS/security, DTC reading, the fault-free profiles, crash execution, CAN wake-up, VIN, variant/EOL management, RSU comparison and W616/UPP-only helpers. Its `__all__` exports about 150 names.

| Function group | Finding | IDs |
|---|---|---|
| Import-time block (`:178-319`) | Lazy mappings are defeated by eager `DTC_CODES` / `message_frame_ids`, so importing needs a project; each `.items()` on a lazy mapping performs N+1 config lookups | M-01, M-02 |
| `create_report_and_logging` (`:523-643`) | Log handle discarded; full `inspect.stack()`; its own env-var names | H-03, L-10 |
| `POWER_OFF/ON/CYCLE`, `Set_ECU_PowerVoltage` (`:748-925`) | No-op branch, swallowed errors, no `finally` for report groups | H-04, M-08, L-01, L-02 |
| `SecurityAccess` (`:966-1098`) | `respSessionRequest[0] != "0000"` compares the first character of a string, so it always returns early with only a comment (no FAILED step); levels 01–04/30 call `int(list, 16)` (TypeError); 31–34 pass channel `2`; P2 bytes and the key algorithm are hard-coded | M-05 |
| `Internal_Security_Access` (`:1115-1175`) | Returns `None` (neither Passed nor Failed) on empty input; a non-list return is assumed successful (`status = "0000"`) | — |
| `FaultFreeCalibration`, `SteeringWheelPosition_Config`, `IMUCalibration_Routine` (`:1194-1575`) | Tautological checks, typo payload, about 16 s of fixed `Wait(1000)` | H-08, H-09 |
| `GetSWInfo`, `ReadPlatformSoftwareVersion` (`:1317`, `:2375`) | `ConvertByteStringToASCII` treats a `str` as bytes, so `chr()` raises a TypeError on every call | M-06 |
| `faultTimeMeasurement` (`:2286-2366`) | Sound design. Reference = function entry; resolution = poll interval + request round trip, not reported | M-04 |
| `Read_DTC`, `Read_customer_DTC` (`:2483-2639`) | NRC → "no DTC"; mask literals disagree; `Read_customer_DTC` calls `.split()` on a possible `Exception` | C-03 |
| `NVM_Clear_L61`, `fault_free_profile*` (`:2640-2764`) | Unverified precondition, UPP-only power cycle, no `finally` | H-02, H-09, M-08 |
| `perform_crash`, `load_crash_curves*` (`:2777-2934`) | Results ignored; `Sleep(8)` instead of a configured readiness or proveout time; debug prints; `builtins` state | H-01, L-05, L-08 |
| `DataIdentifier_Read_Write` (`:3361-3440`) | Read-without-expected tautology; NRC returned with no verdict | H-08, H-02 |
| `CAN_Wakeup` / `CAN_Wakeup_Restore` (`:3878-3994`) | Good: every step is a verdict and the values come from config. Gaps: a missing config silently falls back to the UPP sequence and returns `True`; restbus start results are unchecked | — |
| Legacy wake-up (`:4060-4205`) | `ReceiveFrame(...) is not None` false pass | H-01 |
| Variant/VIN helpers (`:4208-4580`, `:4708+`) | Hard-coded payloads; default base all `0xFF` | H-09, M-13 |
| Not reviewed in depth | `manage_eol_code` (`:5287-5702`), `compare_rsu_did_results`, `decode_DID_0446` | see §3.13 |

### 3.6 `fault_monitor.py` (323 lines)

- `ExpectInternalErrors` (`:66-245`) has these problems:
  - The retry assigns `input_string` but tests the stale `input_string1` (`:83-92`), so the retry can never succeed.
  - A diag failure (an `Exception` object) raises a TypeError at `input_string[:15]`.
  - An unconditional `time.sleep(1)` (`:86`).
  - `internalErrorsListFile` points to `C:\SC3_Platform\…` (`configuration_control.py:335`), so on benches without it every call FAILs with "File not found".
- `DisplayInternalErrors` indexes `CAN.SendDiagByValues(...)[1]`, one character of a string (`:302`).
- `CAN.ReadAllDTCNamesWithStatus` has the same unconditional `time.sleep(1)` (`jscript_translation.py:1683`).
- The module defines its own copy of `_LazyObjectProxy`; there are three copies across `core_functions`, `fault_monitor` and `ascent_batch_lib`.
- **Blast radius (Fact).** `ExpectInternalErrors` 1 call site, `DisplayInternalErrors` 0 in projects. Mostly latent.

### 3.7 `edr_decoding_functions.py` (1,517 lines) — read path only

- `read_edr_parameters` (`:1182-1289`) is solid. Config-driven request, strict prefix check, decoded and raw values returned.
- The session/security preparation result is ignored (`_prepare_diagnostic_read`, `:154-159`), but the strict prefix check then catches a locked ECU. Acceptable.
- `:711` and `:1160` record informational summaries as PASSED steps (expected = obtained). They inflate the step count but cannot hide a failure.

### 3.8 Flashing: `winidea.py`, `infineon_memtool.py`, `ascent_batch_lib.py`

- `Software_Flashing` / `StartSoftwareFlashing`: C-04.
- `ISYS.connect`: retries only after an exception. A "could not connect" result retries immediately, with no delay (`winidea.py:124-143`).
- Memtool / Ascent use `subprocess.run(..., check=True)` with **no timeout** (M-10). `MakeJsonFlashFile` mutates the module-level `FLASH_INPUT_JSON` (M-11).

### 3.9 Other shared modules

- `excel_handler.py`: imports `openpyxl` at module level (0.19 s per process, §3.12). `ForceCloseAllExcel` (L-13).
- `check_sequence.py`: caller problems are already recorded in `jscript-wrapper-review.md`: a numeric channel, `[1]` on a string, a wrong arity.
- `data_conversions.py`, `crash_configuration.py`, `did_decoder.py`, `infineon_memtool.py`, `report_theme.py`, `edr_did_library.py`: outline only (§3.13). `data-conversions-review.md` covers `data_conversions`.

### 3.10 Test scripts

| Family | Count | Observations |
|---|---|---|
| Generated EDR CAN-C simple (`U171/Z121 EDR/scripts_simple`, `M310 EDR_CANC/scripts_simple`) | 1,136 + 1,136 + 1,217 | Good structure (config-driven, `finally` restore, fault injection checked). Issues: no verdict exit code (C-01); `except` missing (C-02); drift (H-07); **`fault_free_profile()` at both start and `finally`** (§3.12); two `load_crash_curves` per script |
| Generated M310 CANC | 456 | Good runner. Each logging step repeats about 25 lines of inline CAN-log parsing; it should be one shared helper (`capture_frames(ids, window_ms, channel)`) |
| Z121 CAND `testCase_DIDList_*` | 184 | Faults not removed in `finally`; log never stopped (`simulation_id` used as a log handle); `Sleep(1)` after a power cycle, then a DTC read (no proveout wait); `Sleep(4)` instead of the configured qualification time |
| Legacy U171 EDR (`EDR/scripts`, hand-maintained, no generator) | 841 | **437,720 lines.** Two sampled 562-line scripts differ in 16 lines (98.6 % identical), so every fix must be applied 841 times. The same requirements are covered by the 1,136-script simple suite |

### 3.11 Runners

| Runner type | Count | Verdict source | Timeout | Live output | Bench reset between scripts |
|---|---|---|---|---|---|
| `run_master.py` and the per-suite `run_*.py` (EDR, Fault_List …) | 92 | exit code (C-01) | no | no (`capture_output`) | no |
| M310 CANC `run_all_canc_*` | 2 | report `<!--PASSED-->` + exit code | no | yes | no |
| In-process `runpy` (DTC fault list, UPP_EV EDR …) | 12 | none: stops on the first exception | no | yes | no |

The in-process runners share `ApymReports` static state, `ensure_runtime` globals, the config cache, `G_Var` and `builtins.CURRENT_CRASH_TYPE` across scripts (M-14). A `sys.exit()` inside a script would end the whole suite (`SystemExit` is not an `Exception`).

### 3.12 Repository structure and the things that slow work down

You asked specifically for this. Everything below is **Fact** (measured or counted on 2026-10-22) unless labelled.

#### A. Where bench time goes (lower bounds from fixed sleeps only)

| Item | Per occurrence | Occurrences | Lower bound per full pass |
|---|---|---|---|
| `fault_free_profile()` repeated in `finally` of every EDR simple script (CAN-FD profile: `Power_Cycle` `Sleep(4)` × 2 + `Sleep(1)`) | ≥ 9 s | 3,489 scripts (U171 1,136 + Z121 1,136 + M310 1,217; all three projects have `CAN_FD_ENABLED = True`) | **≥ 8.7 h** |
| `load_crash_curves()` fixed waits (`Wait(100)` × 3 + `Sleep(2)` + `Sleep(8)`) | ≥ 10.3 s | 2 records × 3,489 scripts | ≥ 20.0 h (the `Sleep(8)` share is 15.5 h; it is needed only if it is the proveout time, see the note below) |
| Shared-library import per process (`import_list`, U171) | 1.37 s measured | 3,489 processes | ≈ 1.3 h |
| `DisplayInternalErrors` / `ExpectInternalErrors` / `ReadAllDTCNamesWithStatus` unconditional `time.sleep(1)` | 1 s | per call | — |
| `SendDiagByValues` fixed capture sleep | ≥ 20 ms + about 7 extra ARIA round trips | about 15 per fault-free profile, more per test | ≈ 0.3 s per profile, plus round trips (Inference) |
| `IMUCalibration_Routine` `Wait(1000)` after each request | about 16 s | per call | latent |

Note on `Sleep(8)` after power-on: **Assumption.** It stands in for ECU readiness and proveout before the crash trigger. Replace it with `PROVEOUT_COMPLETION_TIME` from config plus a readiness poll (R-7). Do not simply delete it.

**Inference (H).** Removing the second `fault_free_profile()` saves at least 8.7 h per full pass of the three EDR simple suites. Restore only what the script changed in `finally`; run the full profile at the start of the next script, or after a FAILED/ERROR script.

#### B. Where developer time goes

| Observation | Measurement | Effect |
|---|---|---|
| Tracked files | 102,761 tracked: `docs/` 83,558 (82,739 under `docs/processed_Documents/Aria Documentation`), `projects/` 10,745, `graphify-out/` 9,698 | `git status` / `git ls-files` exceeded 120 s in this session (two commands timed out); `.git` is 543 MB |
| Tracked bytecode | 1,423 `.pyc` tracked although `.gitignore` lists `__pycache__/` (they were committed before the rule) | Every interpreter run dirties the working tree (see the `M …cpython-314.pyc` lines in `git status`) |
| Duplicates and backups in the tree | `canc_config - v1.py`, `edr_config - v1.py` tracked; `*.bak.py`, `*.py.bak` and `(2)` copies of spec workbooks and tests (`tests/test_common_edr_canc_specification (2).py`, `README (2).md`) | Pyright indexes them (it includes `projects`); readers cannot tell which copy is live |
| Pyright scope | `include: ["shared_libraries","projects","tests"]` covers about 12,100 `.py` under `projects/` alone; `extraPaths` points at `C:/Python 3.14.6`, which does not exist (installed: 3.14.0) | Slow analysis; unresolved apym types |
| Star-import surface | `import_list` exports **1,367 names** into every script | Name collisions; stale bindings (M-09); slow completion; no visible dependencies per script |
| Generated vs hand-written drift | 437,720 lines of legacy U171 EDR scripts at 98.6 % similarity; inline log parsing repeated in 456 CANC scripts | Any fix costs ×841 or a regeneration |
| Uncommitted bench scripts | 12,101 `.py` on disk under `projects/` vs 9,338 tracked; large uncommitted change set at session start | A report cannot be traced to the script revision that produced it; see R-1 (record `git rev-parse HEAD` + "dirty" flag in report info) |
| God modules | `core_functions` 5,702 lines, `jscript_translation` 4,552 lines | Merge conflicts, slow review, unclear ownership |
| Eager heavy imports | `pandas` 0.31 s, `openpyxl` 0.19 s of the 0.74 s module import time (`-X importtime`) | Paid by every script process; used by few functions |
| Config lookup cost | 0.9 ms (depth 5) / 1.3 ms (15) / 1.7 ms (30) per lookup via the stack walk; 0.0008 ms with `IOEM_FRAMEWORK_PROJECT` set (benchmark: scratchpad `bench_lookup.py`) | Avoidable work in every helper; the runners could set the env var at no cost |

#### C. Structural recommendations (detail in §4 and §5)

1. Move `docs/processed_Documents/` and `graphify-out/` out of the code repository: a separate docs repo, Git LFS, or a release artefact share. `git rm -r --cached` all `.pyc`. Delete or archive `* - v1.py`, `*.bak*` and `(2)` copies.
2. Split `core_functions.py` by concern: `power.py`, `uds.py`, `dtc.py`, `preconditions.py`, `crash.py`, `can_wakeup.py`, `vin_variant.py`. Move project-only helpers into `projects/<P>/lib/`. Keep `core_functions` as a compatibility re-export for existing scripts.
3. Replace star imports in *generated* scripts with explicit imports. The generators make this free.
4. Retire or generate the legacy U171 `EDR/scripts` suite. Keep one EDR CAN-C suite per project.
5. One shared runner module, based on the CANC runner, imported by all 106 runners (R-2).

### 3.13 Coverage of this review and the gaps

| Area | Depth |
|---|---|
| `apym_imports`, `framework_registry`, `project_config_loader`, `import_list`, `__init__`, `fault_monitor` | Read in full |
| `core_functions.py` | Lines 1–4,340 read in full; 4,340–5,702 skimmed (`manage_variant_code` head only; `manage_eol_code`, `compare_rsu_did_results`, `decode_DID_0446` **not reviewed**) |
| `jscript_translation.py` | Lines 1–3,305 read in full; 3,305–4,552 (rest of PS leakage, SQUIB, SLS, LAMPS, RD, ACL) **outline only**; partly covered by `jscript-wrapper-review.md` |
| `configuration_control.py` | Outline plus DTC/G_Var/path sections |
| `edr_decoding_functions.py` | UDS read path and parser only |
| `winidea`, `ascent_batch_lib`, `excel_handler` | Flashing / subprocess / process-kill paths only |
| `data_conversions`, `crash_configuration`, `did_decoder`, `infineon_memtool`, `report_theme`, `edr_did_library`, `check_sequence` | **Outline only** |
| Scripts | One U171 EDR simple script (template of 3,489), one M310 CANC, one Z121 CAND (template of 184), legacy U171 EDR (size and duplication only). **Not sampled:** DCS, GPO, SQUIBS, IMU, VIN, PlantMode, Scrap, E_CALL, OCS/ODS suites |
| `tools/` generators, `.github/` harness, `tests/` content | **Not reviewed** (only the offline checker was run) |
| Bench behaviour | **Evidence unavailable.** No bench run; all timing impacts other than the measured ones are Inference |

---

## 4. Code Optimization & Refactoring Recommendations

All snippets are written against the current APIs (`RESULT`, `CAN`, `PS`, `aria_reports`, `create_report_and_logging`, `_get_optional_project_config_symbol`). New config keys named here (`ECU_SHUTDOWN_TIME_MS`, `DTC_STATUS_AVAILABILITY_MASK` …) are **proposals**. Their values must come from each project's specification, and must not be copied between projects.

### R-1 — One run contract per script: exception = FAILED step, exit code = report verdict (C-01, C-02, H-03)

**Before** (`…8_6_MTO_Pre.py`, every simple script):

```python
    fault_free_profile()
    read_software_version()

    try:
        for did in EDR_RECORD_DIDS:
            ...                                   # an exception here is never a report step
    finally:
        CAN.PeriodicEnableFrame(fault_frame)
        CAN.ReloadDefaultPeriodicFrame(frame)
        fault_free_profile()                      # second full profile, >= 9 s
        aria_reports.write_to_file()


if __name__ == "__main__":
    run_test()                                    # exits 0 whatever the report says
```

**After** (new `shared_libraries/bench_test.py`, star-exported through `import_list`):

```python
"""One run contract for every bench script: report, body, restore, verdict, exit code."""

from __future__ import annotations

import re
import sys
import traceback
from pathlib import Path
from typing import Any, Callable

from .core_functions import RESULT, aria_reports, create_report_and_logging

EXIT_PASSED, EXIT_FAILED, EXIT_ERROR = 0, 1, 2
_VERDICT = re.compile(r"<!--(PASSED|FAILED)-->\s*$")
_STEPS = re.compile(r'id="successStepsCount">(\d+)/(\d+)<')

__all__ = ["run_bench_test", "read_report_verdict", "EXIT_PASSED", "EXIT_FAILED", "EXIT_ERROR"]


def read_report_verdict(report_path: str | Path) -> tuple[str | None, int]:
    """The verdict apym wrote on the report's last line and the number of steps in the report."""
    with open(report_path, "rb") as handle:
        handle.seek(0, 2)
        handle.seek(max(0, handle.tell() - 512))
        tail = handle.read().decode("utf-8", "replace")
    verdict, steps = _VERDICT.search(tail), _STEPS.search(tail)
    return (verdict.group(1) if verdict else None), (int(steps.group(2)) if steps else 0)


def run_bench_test(
    test_case_file: str,
    body: Callable[[], None],
    restore: Callable[[], None],
    **report_kwargs: Any,
) -> None:
    """Run body() in a report, always run restore(), then exit with the report's verdict.

    An exception in body() or restore() is a FAILED step, so an aborted test can never
    leave a PASSED report; a report without a single step is an error, not a pass.
    """
    report_path, _log_path = create_report_and_logging(test_case_file, **report_kwargs)
    try:
        body()
    except Exception as error:
        RESULT.LogCustomAction("Test ran to the end", "no exception",
                               f"{type(error).__name__}: {error}\n{traceback.format_exc()}", False)
    finally:
        try:
            restore()
        except Exception as error:
            RESULT.LogCustomAction("Bench restored", "no exception",
                                   f"{type(error).__name__}: {error}", False)
        aria_reports.write_to_file()
    verdict, steps = read_report_verdict(report_path)
    if verdict == "PASSED" and steps > 0:
        sys.exit(EXIT_PASSED)
    sys.exit(EXIT_FAILED if verdict == "FAILED" else EXIT_ERROR)
```

Script side (generator template):

```python
def body():
    for did in EDR_RECORD_DIDS:
        ...

def restore():
    # Undo only what this script changed; the next script runs the full fault-free profile.
    CAN.PeriodicEnableFrame(fault_frame)
    CAN.ReloadDefaultPeriodicFrame(frame)

if __name__ == "__main__":
    run_bench_test(Path(__file__).stem, body, restore,
                   can_ids=resolve_can_log_ids([signal]), tc_desc=tc_desc)
```

Also make `create_report_and_logging` return the log id (or keep it in a module variable), so `run_bench_test` can stop the log in `finally`. Add `#Framework revision:` (output of `git rev-parse --short HEAD` plus a dirty flag) to the report info for traceability.

### R-2 — One shared runner: verdict + step count + timeout + safe state (C-01, H-03, M-10)

**Before** (`run_master.py:422-435`):

```python
    completed = subprocess.run([sys.executable, str(path)], cwd=str(SCRIPT_DIR), env=env,
                               capture_output=True, text=True)
    ...
    status = "PASSED" if completed.returncode == 0 else "FAILED"
```

**After** (`shared_libraries/suite_runner.py`, built from the CANC runner's `read_report`):

```python
def run_script(path: Path, env: dict[str, str], timeout_s: float, report_dir: Path) -> str:
    """PASSED only when the process exits 0 AND its report says PASSED with at least one step."""
    started = time.time()
    try:
        # No capture_output: operator instructions in semi-automatic scripts appear at once.
        completed = subprocess.run([sys.executable, "-u", str(path)], cwd=str(path.parent),
                                   env=env, timeout=timeout_s)
    except subprocess.TimeoutExpired:
        bench_safe_state()        # the script was killed before its own finally ran
        return "TIMEOUT"
    report, verdict, steps = read_report(path, started, report_dir)   # as in run_all_canc_automatic_scripts.py
    total = int(steps.split("/")[1]) if steps else 0
    if completed.returncode == 0 and verdict == "PASSED" and total > 0:
        return "PASSED"
    if completed.returncode != 0 or verdict is None or total == 0:
        bench_safe_state()
        return "ERROR"
    return "FAILED"


def build_environment(project: str) -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONPATH"] = str(FRAMEWORK_ROOT.parent) + os.pathsep + env.get("PYTHONPATH", "")
    env["IOEM_FRAMEWORK_PROJECT"] = project      # one O(1) project lookup instead of a stack walk (M-02)
    env["PYTHONIOENCODING"] = "utf-8"
    return env
```

`bench_safe_state()` is a short project-configured routine: restbus `PeriodicEnableAllFrames` on every channel, `RSU.ClearFault` on the configured channels, `PS.Clear*Leakage*`, nominal voltage, squib loops to "no fault". Each step is logged; none may raise.

### R-3 — Strict 19 02 parsing for `Read_DTC` (C-03, H-05)

**Before** (`core_functions.py:2590-2636`):

```python
        def dtcSplit(DTC: str):
            tokens = DTC.strip().split()
            if len(tokens) >= 3 and tokens[0] in ["0x59", "59"] and tokens[1] in ["0x02", "02"] and tokens[2] in ["0xCB", "CB"]:
                tokens = tokens[3:]
            return [" ".join(tokens[i:i+4]) for i in range(0, len(tokens), 4) if len(tokens[i:i+4]) == 4]
        ...
        if not obtained_DTC_list:
            RESULT.InterpretEqualResult("Check No DTC Number", obtained_DTC_list, expected_DTC_list[:14])  # "[]" == "[]"
```

**After:**

```python
def parse_dtcs_by_status_mask(response: Any, availability_mask: int | None = None) -> dict[int, int]:
    """{DTC: status} from a 19 02 answer (ISO 14229-1 reportDTCByStatusMask).

    Raises on anything that is not a complete positive answer: an NRC, an empty answer,
    a record that is not 4 bytes, or an availability mask other than the configured one.
    """
    if isinstance(response, Exception):
        raise RuntimeError(f"19 02 request failed: {response}") from response
    data = bytes(int(token, 16) for token in str(response).split())
    if len(data) >= 3 and data[0] == 0x7F:
        raise ValueError(f"19 02 rejected with NRC 0x{data[2]:02X}")
    if len(data) < 3 or data[:2] != b"\x59\x02" or (len(data) - 3) % 4:
        raise ValueError(f"Not a complete positive 19 02 answer: {response!r}")
    if availability_mask is not None and data[2] != availability_mask:
        raise ValueError(f"DTCStatusAvailabilityMask 0x{data[2]:02X}, configured 0x{availability_mask:02X}")
    return {int.from_bytes(data[i:i + 3], "big"): data[i + 3] for i in range(3, len(data), 4)}


def _format_dtcs(dtcs: Mapping[int, int]) -> str:
    return " | ".join(f"{dtc:06X} {status:02X}" for dtc, status in sorted(dtcs.items())) or "no DTC"


def Read_DTC(FaultName, FaultDTC, ReadDTC_Code):
    """Same signature as before; FaultDTC is the expected answer text (header + records)."""
    mask = _get_optional_project_config_symbol("DTC_STATUS_AVAILABILITY_MASK", ("project_config",), None)
    try:
        expected = parse_dtcs_by_status_mask(FaultDTC)
        obtained = parse_dtcs_by_status_mask(CAN.SendDiagByValues(ReadDTC_Code), mask)
    except (RuntimeError, ValueError) as error:
        RESULT.LogCustomAction(FaultName, "complete positive 19 02 answer", str(error), False)
        return False
    RESULT.InterpretEqualResult(FaultName, _format_dtcs(obtained), _format_dtcs(expected))
    return obtained == expected
```

`CAN.CheckSingleDTC` already parses this way (`jscript_translation.py:2139-2162`). Both should use the same function.

### R-4 — A strict action layer: raise and record when the bench refuses (H-01)

**Before** (`jscript_translation.py:1272-1283`): success and failure are both strings.

```python
    @staticmethod
    def PeriodicDisableFrame(channel_name: str | None = None, frame_name: str | None = None) -> str:
        try:
            ...
            Api.Simulation.Frame.disable(resolved_simulation_id, frame_name)
            return f"Simulation Stopped on {frame_name}"
        except Exception as ex:
            return str(ex)
```

**After** (new strict functions for generators and new scripts; the legacy wrappers stay as they are for old scripts):

```python
class BenchActionError(RuntimeError):
    """A bench action was refused, so the condition the test relies on was not created."""


def _bench_call(step: str, action: Callable[[], Any]) -> Any:
    """Run one ARIA action; on failure record a FAILED step and raise BenchActionError."""
    try:
        require_runtime()
        return action()
    except Exception as error:
        RESULT.LogCustomAction(step, "done", f"{type(error).__name__}: {error}", False)
        raise BenchActionError(f"{step}: {error}") from error


def stop_frame(frame_name: str, channel_name: str | None = None) -> None:
    _bench_call(f"Stop frame {frame_name}", lambda: Api.Simulation.Frame.disable(
        _resolve_simulation_channel_id(channel_name), frame_name))


def start_frame(frame_name: str, channel_name: str | None = None) -> None:
    _bench_call(f"Start frame {frame_name}", lambda: Api.Simulation.Frame.enable(
        _resolve_simulation_channel_id(channel_name), frame_name))


def set_signal(frame_name: str, signal_name: str, raw_value: Any,
               channel_name: str | None = None, pdu_name: str | None = None) -> None:
    _bench_call(f"{frame_name}.{signal_name} = {raw_value}", lambda: Api.Simulation.Signal.change_raw_value(
        _resolve_simulation_channel_id(channel_name), frame_name, pdu_name or f"{frame_name}Pdu",
        signal_name, raw_value))
```

The legacy `wake_ecu_over_can_nm` false pass (`core_functions.py:4139`), fixed in place:

```python
        if settings["srs_nm_frame"]:
            seen = CAN.ReceiveFrame(settings["srs_nm_frame"])
            answered = seen is not None and not isinstance(seen, (str, Exception))   # an error text is not a frame
```

### R-5 — Fault injection that is always removed (H-03)

```python
from contextlib import contextmanager

@contextmanager
def fault_held(name: str, inject: Callable[[], None], remove: Callable[[], None]):
    """Hold a fault for the with-block; it is removed even when the block raises."""
    inject()
    try:
        yield
    finally:
        try:
            remove()
        except Exception as error:
            RESULT.LogCustomAction(f"Fault removed: {name}", "removed",
                                   f"{type(error).__name__}: {error}", False)
```

Z121 CAND usage (replaces the in-`try` cleanup at `testCase_DIDList_Testcase129.py:96-149`):

```python
def inject_squib_fault():
    answer = SQUIB.SendRequest(device, fault_desc)
    RESULT.InterpretEqualResult(f"Set {device} to {fault_desc}", answer, f"{fault_desc} for {device} set OK.")
    PS.SetLeakageGNDBusLow()

def remove_squib_fault():
    SQUIB.SendRequest(device, no_fault_desc)
    PS.ClearLeakageGNDBusLow()

with fault_held(f"{device} {fault_desc}", inject_squib_fault, remove_squib_fault):
    ...  # qualification, DID reads in default and extended session
```

### R-6 — Deadline-based sampling for EDR loops (H-07)

**Before** (every simple script): the sleep comes after the work, so the error accumulates.

```python
            for index, raw in enumerate(values):
                ...
                CAN.ChangeSignalValue(frame, name, str(raw))
                if index == trigger_index:
                    Wait(trigger_wait_ms); TriggerCrash(); Wait(interval_ms - trigger_wait_ms)
                else:
                    Wait(interval_ms)
                on_bench = int(str(CAN.GetSignalFromFrame(frame, name)), 0)
                RESULT.InterpretEqualResult(...)
```

**After** (shared helper; the generator emits one call):

```python
def drive_on_grid(values: Sequence[Any], interval_ms: float,
                  on_window: Callable[[int, Any], None],
                  trigger_at: tuple[int, float] | None = None,
                  trigger: Callable[[], None] = TriggerCrash) -> None:
    """Start window k at t0 + k * interval on a monotonic clock, whatever on_window costs.

    trigger_at = (window index, ms into that window). A window whose work ran past its end
    is a FAILED step: the record would no longer line up with the expected samples.
    """
    start = time.monotonic()

    def sleep_until(deadline: float) -> float:
        late = time.monotonic() - deadline
        if late < 0:
            time.sleep(-late)
        return max(late, 0.0)

    for index, raw in enumerate(values):
        sleep_until(start + index * interval_ms / 1000.0)
        on_window(index, raw)                       # drive the value, check the previous one
        if trigger_at and trigger_at[0] == index:
            late = sleep_until(start + (index * interval_ms + trigger_at[1]) / 1000.0)
            trigger()
            RESULT.InterpretEqualResultRange("Crash trigger lateness (ms)", late * 1000.0, 0, 5)
    overrun = sleep_until(start + len(values) * interval_ms / 1000.0)
    if overrun > interval_ms / 1000.0:
        RESULT.LogCustomAction("Sampling grid held", f"each window <= {interval_ms} ms",
                               f"last window overran by {overrun * 1000:.1f} ms", False)
```

The 5 ms trigger tolerance is a placeholder. **Assumption:** set it from the EDR timing requirement.

### R-7 — Ordered power cycle with a readiness poll (H-02, H-04)

**Before** (`jscript_translation.py:3222-3233`):

```python
            RESULT.ExpectTestResult("Turn off BATT", Api.Chassis.Power.clear(G_Var.Pwr_Config.BATT), "", True)
            RESULT.ExpectTestResult("Turn off IGN", Api.Chassis.Power.clear(G_Var.Pwr_Config.IGN), "", True)
            Sleep(4)
            RESULT.ExpectTestResult("Turn ON BATT", Api.Chassis.Power.set(G_Var.Pwr_Config.BATT), "", True)
            RESULT.ExpectTestResult("Turn ON IGN", Api.Chassis.Power.set(G_Var.Pwr_Config.IGN), "", True)
```

**After:**

```python
def _power_setting(name: str, default: int) -> int:
    return int(_get_optional_project_config_symbol(name, ("power_config", "project_config"), default))


def _switch(line: str, on: bool) -> None:
    """Switch one line and read it back (apym Chassis.Power.is_set)."""
    (Api.Chassis.Power.set if on else Api.Chassis.Power.clear)(line)
    state = Api.Chassis.Power.is_set(line)
    RESULT.InterpretEqualResult(f"{line} {'ON' if on else 'OFF'}", str(state), str(on))


def power_cycle_ordered() -> bool:
    """IGN off, wait for ECU shutdown/NvM, BATT off; BATT on, IGN on; poll until the ECU answers.

    Returns True when the ECU answered Tester Present within ECU_READY_TIMEOUT_MS. DTC
    reads still wait PROVEOUT_COMPLETION_TIME after this; ready is not proveout.
    """
    require_runtime()
    _switch(G_Var.Pwr_Config.IGN, False)
    time.sleep(_power_setting("ECU_SHUTDOWN_TIME_MS", 4000) / 1000.0)     # value from the ECU spec
    _switch(G_Var.Pwr_Config.BATT, False)
    time.sleep(_power_setting("POWER_OFF_DWELL_MS", 1000) / 1000.0)
    _switch(G_Var.Pwr_Config.BATT, True)
    _switch(G_Var.Pwr_Config.IGN, True)
    started = time.monotonic()
    deadline = started + _power_setting("ECU_READY_TIMEOUT_MS", 5000) / 1000.0
    while time.monotonic() < deadline:
        answer = CAN.SendDiagByValuesNoLog("3E 00")
        if isinstance(answer, str) and answer.startswith("0x7E"):
            RESULT.LogCustomAction("ECU answers after power-on", "Tester Present answered",
                                   f"after {(time.monotonic() - started) * 1000:.0f} ms", True)
            return True
        time.sleep(0.05)
    RESULT.LogCustomAction("ECU answers after power-on", "Tester Present answered", "no answer", False)
    return False
```

### R-8 — Cache what cannot change within a process (M-02, M-03)

**Before** (`project_config_loader.py:59-75`): a stack walk on every lookup.

```python
def get_active_project() -> str:
    if _ACTIVE_PROJECT_OVERRIDE:
        return _ACTIVE_PROJECT_OVERRIDE
    env = os.environ.get(PROJECT_ENV_VAR)
    if env:
        return env
    detected = infer_project_name()
    ...
```

**After** (decide the `bootstrap-layer.md` §1 precedence first, then):

```python
_DETECTED_PROJECT: Optional[str] = None


def get_active_project() -> str:
    global _DETECTED_PROJECT
    if _ACTIVE_PROJECT_OVERRIDE:
        return _ACTIVE_PROJECT_OVERRIDE
    env = os.environ.get(PROJECT_ENV_VAR)
    if env:
        return env
    if _DETECTED_PROJECT is None:
        _DETECTED_PROJECT = infer_project_name() or ""      # one stack walk per process
    if _DETECTED_PROJECT:
        return _DETECTED_PROJECT
    raise RuntimeError(...)                                  # unchanged message


def set_active_project(name: Optional[str]) -> None:
    global _ACTIVE_PROJECT_OVERRIDE, _DETECTED_PROJECT
    _ACTIVE_PROJECT_OVERRIDE, _DETECTED_PROJECT = name, None
    reset_project_config_cache()
```

UDS channel ids in `jscript_translation`, fetched once per runtime instead of once per request:

```python
_uds_channel_ids: dict[str, Any] = {}          # cleared at the top of ensure_runtime()


def _uds_channel_id(name: str) -> Any:
    """ARIA's id for a UDS channel, asked once per runtime."""
    if name not in _uds_channel_ids:
        _uds_channel_ids[name] = Api.Configuration.get_uds_channel_id(name)
    return _uds_channel_ids[name]
```

Make the bus-capture fallback in `_request_diag_response` opt-in: on for interactive diagnosis, off in polling loops. That removes the fixed 20 ms and about 6 ARIA calls per request.

### R-9 — Report groups that always close (M-08)

**Before** (`core_functions.py:748-776`):

```python
def POWER_OFF(power_supply: str) -> None:
    rep.add_group("POWER_OFF")
    ...                          # an exception here leaves the group open
    rep.close_group()
```

**After:**

```python
from contextlib import contextmanager

@contextmanager
def report_group(name: str):
    """A report group that is closed even when the body raises."""
    aria_reports.add_group(name)
    try:
        yield
    finally:
        aria_reports.close_group()


def POWER_OFF(power_supply: str) -> None:
    with report_group("POWER_OFF"):
        if G_Var.Power_Type == G_Var.Pwr_Config.External:
            raise NotImplementedError("POWER_OFF: external supply is not implemented")   # no silent no-op
        ...
```

### R-10 — Import cost and import-time side effects (M-01)

**Before** (`core_functions.py:15-23`, `:305-319`):

```python
try:
    import numpy as np
except Exception:
    np = None
try:
    import pandas as pd
except Exception:
    pd = None
...
DTC_CODES: dict[str, Any] = {                     # evaluated at import: needs an active project
    "NODE_ABSENT": {f"DTC_{m}_NODE_ABSENT": d for m, d in CAN_NODE_ABSENT_DTC.items()},
    ...
}
message_frame_ids: set[str] = set(CAN_TX_MESSAGE_CONFIG)
```

**After:**

```python
def _require_numpy() -> Any:
    import numpy                                  # imported on first use only
    return numpy


def _require_pandas() -> Any:
    import pandas
    return pandas


def _build_dtc_codes() -> dict[str, Any]:
    return {
        "NODE_ABSENT": {f"DTC_{m}_NODE_ABSENT": d for m, d in CAN_NODE_ABSENT_DTC.items()},
        "MESSAGE_TIMEOUT": {f"DTC_{m}_MESSAGE_TIMEOUT": {"dtc": d, "messages": [m]}
                            for m, d in CAN_MESSAGE_TIMEOUT_DTC.items()},
    }


DTC_CODES: Mapping[str, Any] = _LazyMappingProxy(_build_dtc_codes)


def _message_frame_ids() -> set[str]:
    return set(CAN_TX_MESSAGE_CONFIG)
```

Do the same for `openpyxl` in `excel_handler.py`. Expected gain: about 0.5 s per script process, plus importable tooling outside `projects/`.

### R-11 — Flashing that never cuts power mid-programming (C-04, M-10)

**Before** (`winidea.py:421-438`):

```python
    if FlashingTool == "MEMTOOL":
        WriteDefaultCalibration()
        p = subprocess.Popen([G_Var.IMTMemtool, mtb])
        Wait(3000)
        POWER_CYCLE(POWERSOURCE)
```

**After:**

```python
def flash_with_memtool(mtb_path: str, timeout_s: float) -> None:
    """Run Memtool to completion. The ECU is power-cycled only after a clean exit.

    On a timeout the flasher is left running and power is left ON: the suite stops and an
    operator decides. Cutting power during programming is the hazard this function exists
    to prevent.
    """
    process = subprocess.Popen([G_Var.IMTMemtool, mtb_path])
    try:
        exit_code = process.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        RESULT.LogCustomAction("Memtool flashing", f"finished within {timeout_s:g} s",
                               "still running: power left ON, suite stopped", False)
        raise BenchActionError("Flashing did not finish; do not power-cycle the ECU") from None
    RESULT.InterpretEqualResult("Memtool exit code", str(exit_code), "0")
    if exit_code != 0:
        raise BenchActionError(f"Memtool exited with {exit_code}")
    power_cycle_ordered()
```

Remove the daemon-thread variant (`StartSoftwareFlashing`), or have it only start the process and *not* report from the thread. Take `mtb_path` from project config, not `C:\sura2`.

### R-12 — Replace the tautologies (H-08)

**Before** (`core_functions.py:1894-1904`):

```python
        uds_response = CAN.SendDiagByValues(uds_frame)
        RESULT.InterpretEqualResult(f"UDS Response for Request : {uds_frame}", uds_response, uds_response)
```

**After:**

```python
def send_uds_frame(uds_frame: str, expected_response: str | None = None) -> Any | None:
    """Send one request; check the full answer when given, else that it is positive (SID + 0x40)."""
    from .jscript_translation import _prepare_diag_payload
    with report_group("send uds frame"):
        response = CAN.SendDiagByValues(uds_frame)
        tokens = str(response).split()
        if expected_response is None:
            positive = f"0x{(_prepare_diag_payload(uds_frame)[0] + 0x40) & 0xFF:02X}"
            RESULT.InterpretEqualResult(f"Positive response to {uds_frame}",
                                        tokens[0] if tokens else str(response), positive)
        else:
            RESULT.InterpretEqualResult(f"Response to {uds_frame}", str(response), expected_response)
        return response
```

Apply the same rule to `DataIdentifier_Read_Write`: with no expected record, check the `0x62 <DID>` prefix, and record an NRC on read or write as a FAILED step. For `SteeringWheelPosition_Config`, compare the first token with `0x6E` / `0x62`.

### R-13 — Never return "response pending" as the answer (C-03)

**Before** (`jscript_translation.py:344-349`):

```python
    for message in reversed(messages):
        if len(message) >= 3 and message[0] == 0x7F and message[2] == 0x78:
            continue
        return message

    return messages[-1]
```

**After:**

```python
    for message in reversed(messages):
        if len(message) >= 3 and message[0] == 0x7F and message[2] == 0x78:
            continue
        return message

    return None   # only responsePending (NRC 0x78) seen: the request did not complete
```

---

## 5. Prioritized Action Checklist

Work top to bottom. Each item names the finding it closes and how to prove it is done. "Offline" means it can be verified without a bench.

### P0 — Verdict integrity (before the next regression whose results count as evidence)

- [ ] **P0-1 (C-01, C-02)** Add `shared_libraries/bench_test.py` (R-1); switch the EDR simple generator template to `run_bench_test`; regenerate U171, Z121 and M310 `scripts_simple`.
  *Verify offline:* fake `Api` (reuse `tools/check_jscript_wrappers_offline.py` fixtures). Case 1: a failing step → exit 1. Case 2: a raised exception → a FAILED step in the HTML and exit 1. Case 3: an empty body → exit 2.
- [ ] **P0-2 (C-01, H-03, M-10)** Create `shared_libraries/suite_runner.py` (R-2) and point all 92 exit-code runners plus the 12 in-process runners at it; add `timeout`, `bench_safe_state()` and the `IOEM_FRAMEWORK_PROJECT` env var.
  *Verify:* `grep -L "read_report" run_*.py` returns nothing. A dummy script that writes a FAILED report and exits 0 is shown as FAILED. A sleeping script is shown as TIMEOUT.
- [ ] **P0-3 (C-03, H-05)** Replace `dtcSplit` with `parse_dtcs_by_status_mask` (R-3). Add `DTC_STATUS_AVAILABILITY_MASK` to every `project_config.py`, with each value from that project's diagnostic spec. Make `CheckSingleDTC` use the same parser.
  *Verify offline:* the answers `0x7F 0x19 0x31`, `""`, `0x59 0x02 0xFF` (wrong mask) and `0x59 0x02 0xCB 0x90 0x61 0x96` (truncated) each give a FAILED step; `0x59 0x02 0xCB` with no DTC expected gives PASSED.
- [ ] **P0-4 (C-03)** Apply R-13 (no final 0x78).
  *Verify offline:* `_decode_logged_diag_response` with only `7F 19 78` frames returns `None`.
- [ ] **P0-5 (C-04)** Block `Software_Flashing` / `StartSoftwareFlashing` until R-11 is in: raise `NotImplementedError` with a pointer to this item.
  *Verify:* grep shows the 3 call sites; each fails fast instead of flashing.

### P1 — Bench safety and state

- [ ] **P1-1 (C-04, M-10)** Implement R-11 (Memtool to completion, no power cut on timeout); move `mtb` and the Memtool path into project config; add timeouts to Ascent, Saleae and Memtool calls.
- [ ] **P1-2 (H-03)** Wrap the fault injections in the Z121 CAND generator with `fault_held` (R-5); regenerate the 184 scripts. Do the same for every generated suite that injects squib, RSU, leakage or voltage faults.
  *Verify offline:* inject, raise, then check that the fake `Api` saw the matching remove calls.
- [ ] **P1-3 (H-03)** Make `create_report_and_logging` keep the log id; stop the log in `run_bench_test`'s `finally`.
  *Verify:* the fake `Api` sees `Log.stop_log(id)` once per test.
- [ ] **P1-4 (H-04)** Confirm the ECU's KL15→KL30 shutdown time and NvM write-back requirement (**Assumption** today). Then implement `power_cycle_ordered` (R-7) and route `PS.Power_Cycle`, `POWER_CYCLE` and `load_crash_curves` through it. Make `POWER_OFF`'s External branch raise; stop `POWER_ON` swallowing errors.
  *Verify on the bench:* one DTC-historic-after-power-cycle test passes 20 out of 20 runs.
- [ ] **P1-5 (H-05)** Move `AriaFileConfig`, platform DTCs, P2 bytes, SW versions and paths from `configuration_control.py` into `projects/<P>/config/`; delete the duplicate definitions; add `tools/check_configuration_control.py`, which fails on duplicate top-level names or any non-protocol value.
  *Verify:* `RSU.ResetRSU()` on U171 reads U171's loadbox (trace in the fake `Api`).
- [ ] **P1-6 (H-06)** Rework `init_aria` / `ensure_runtime`: one explicit init, connection proven by a real call, fail fast without a retry on every wrapper call.
  *Verify offline:* make the fake `Instance.init` fail its handshake, then raise "already initialized" on the second call. The framework must report "not connected".

### P2 — Determinism and timing of the checks

- [ ] **P2-1 (H-02)** Make the fault-free profile verify itself: security result → FAILED step plus abort; write NRCs → FAILED step (fix `DataIdentifier_Read_Write`, R-12); readiness poll after each power-on (R-7); a final strict DTC check (R-3) against the configured optional DTCs. Return a bool.
  *Verify offline:* each injected NRC fails the profile.
- [ ] **P2-2 (H-07)** Implement `drive_on_grid` (R-6) in the EDR simple generator; regenerate the 3,489 scripts.
  *Verify on the bench:* log `time.monotonic()` per window for one script; the drift stays below the R-6 tolerance across all samples.
- [ ] **P2-3 (M-04)** Let `faultTimeMeasurement` accept the injection timestamp (`t0=time.monotonic()` taken right after the injection call) and report its resolution (poll gap + request round trip) next to the measured time.
- [ ] **P2-4 (H-01)** Add the strict action layer (R-4) and use it in all generators; fix the legacy `wake_ecu_over_can_nm` check; make `perform_crash` / `load_crash_curves*` verify every curve upload before triggering.
  *Verify offline:* a refused `Frame.disable` gives a FAILED step and an exception.
- [ ] **P2-5 (H-08)** Fix the tautologies listed in H-08 (R-12).
  *Verify offline:* each function fed an NRC records a FAILED step.
- [ ] **P2-6 (H-09)** Fix the `IMUCalibration_Routine` typo and move its payloads to `imu_config`. Move the variant-code payloads, ENS and multi-event curve paths, `"GEN6_XY"` and the Saleae path to project config. Remove the unconditional UPP-only `PS.Power_Cycle()` from `NVM_Clear_L61`, or gate it on a project flag.
  *Verify:* `grep -n "V:\\\\IN01" shared_libraries/` returns nothing.

### P3 — Speed and structure

- [ ] **P3-1 (§3.12 A)** Remove the second `fault_free_profile()` from the generated `finally` blocks: restore only what the script changed; the runner runs `bench_safe_state()` plus the profile after a non-PASSED script. Expected saving: at least 8.7 h per full pass.
  *Verify:* the wall time of one suite before and after.
- [ ] **P3-2 (M-02, M-03)** Cache project detection (R-8, after deciding the `bootstrap-layer.md` precedence); cache UDS channel ids; make the bus capture opt-in.
  *Verify offline:* `bench_lookup.py` (scratchpad) below 0.01 ms per lookup without the env var.
- [ ] **P3-3 (M-01)** Make `DTC_CODES` lazy and the heavy imports lazy (R-10).
  *Verify offline:* `python -c "import Framework_IOEM_Py.shared_libraries.import_list"` succeeds with no project set; `-X importtime` total below 0.3 s.
- [ ] **P3-4 (§3.12 B)** Repository hygiene: `git rm -r --cached` all `*.pyc`; move `docs/processed_Documents/` and `graphify-out/` out of the code repo (or to LFS); delete the `* - v1.py`, `*.bak*` and `(2)` duplicates; add `test_results/` and `test_logs/` to `.gitignore`.
  *Verify:* tracked files fall from 102,761 to about 10,000; `git status` under 5 s.
- [ ] **P3-5 (§3.12 B)** Narrow `pyrightconfig.json` (exclude the generated suites, fix `extraPaths` to the real interpreter); switch the generated scripts from `import *` to explicit imports.
- [ ] **P3-6 (§3.10)** Retire the legacy U171 `EDR/scripts` (841 files, 437,720 lines) in favour of `scripts_simple`, or bring it under a generator. Extract the repeated CANC log-parsing block into one shared helper.
- [ ] **P3-7 (§3.5)** Split `core_functions.py` by concern (power, uds, dtc, preconditions, crash, can_wakeup, vin_variant), with a compatibility re-export. Move the W616-only and UPP-only helpers into `projects/<P>/lib/`.

### P4 — Hygiene and maintainability

- [ ] **P4-1 (M-05, M-06, M-07)** Delete or rewrite the latent broken helpers: `SecurityAccess` (route it to `Internal_Security_Access` with a config level map), `GetSWInfo` / `ReadPlatformSoftwareVersion` (use `read_software_version`), and `ExpectInternalErrors` / `DisplayInternalErrors` (fix the retry, remove the 1 s sleeps, take the error-list path from config).
- [ ] **P4-2 (M-08)** Introduce `report_group` (R-9) and replace bare `add_group` / `close_group` pairs in `core_functions`, `winidea` and `NVM_Clear_L61`.
- [ ] **P4-3 (M-09)** Stop exporting runtime globals (`Api`, `CurveData`, `simulation_id`, `diag_ch*`) from `jscript_translation.__all__`; expose accessor functions instead; fix the Z121 CAND `simulation_id` use.
- [ ] **P4-4 (M-11, M-13, M-14, M-15, M-16)**: copy the Ascent template per call; require an explicit variant-code base (no all-0xFF default); move the in-process runners to the shared subprocess runner; add the CAN-FD SF escape and 32-bit FF length handling; add `Power.is_set` readback to the PS wrappers.
- [ ] **P4-5 (M-12)** Add `requirements.txt` (numpy, pandas, openpyxl, psutil, pytest; apym pinned to the ARIA-shipped version), install `pytest` in the bench interpreter, and add a pre-commit or CI job that runs `tests/` plus `tools/check_jscript_wrappers_offline.py` and the generators' `--check`.
- [ ] **P4-6 (L-01 … L-14)** Low items in one cleanup pass: f-string, double voltage set, `"enable_frame"` literal, module-level `@staticmethod`, debug prints to `RESULT`, swapped Read_DTC arguments, `ReadEdrDataStructure`, `builtins` state, wake-up docstrings, `create_report_and_logging` env names, `ForceCloseAllExcel` (target only workbooks the framework opened), dead legacy config.

### Re-verify after each phase

1. `tools/check_jscript_wrappers_offline.py` → still 94/94, plus the new checks above.
2. Each generator's `--check` → no drift.
3. A smoke run on the bench: one script per family (EDR simple, CANC, CAND, Fault_List) through the shared runner. For each, the runner status must equal the HTML verdict, and the bench must be in the safe state afterwards.
