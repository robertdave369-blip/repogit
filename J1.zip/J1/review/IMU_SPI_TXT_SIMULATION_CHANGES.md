# Review guide: IMU and GEN6 SPI simulation with .txt files

Author: Kris. Written 2026-10-25 for a manual review of the work of 2026-10-24.

**Status: nothing is committed and nothing has run on the bench.** Every check so far was offline
(section 8).

Line numbers are as of 2026-10-25 and move if a file changes.

---

## 1. What this change does, in plain words

The ECU reads two sensors over SPI:
- the **Panasonic IMU**: gyro X/Y/Z, accel X/Y/Z, temperature;
- the **GEN6 central high-g sensor**.

On the ARIA bench an SPI card can answer the ECU instead of the real sensor. You asked for that to be
driven by **.txt files**, the way the bench's ARIA already does it: its crash folder is `IMU_Data_India\`,
which is full of per-axis `.txt` curves.

So now:

1. **Every sensor value and every fault is a .txt file**, one file per sensor axis, one line per sample
   (0.5 ms per line, an assumption, see section 6).
2. **A normal line is a number**, the sensor value. The card builds a valid SPI frame around it:

   ```
   2000        <- accel = 2000 counts = 1 g
   ```

3. **A fault line carries the exact SPI word** the card must send instead (ARIA's "blended" format). This is
   how every fault (SEV flag, wrong address, wrong CRC, GEN6 status) gets into a txt file:

   ```
   0#SPI_Panasonic:00006682      <- accel X answers with the SEV alarm flag set
   ```

4. **Polarity:** the negative stimulus is the same file sent with ARIA's `inverted` flag.
5. **Loading:** the scripts load the files with the ECU switched off, power it on, and start them with the
   crash trigger.
6. **Safety:** the crash trigger also replays any curve left on other sensors. So before every trigger the
   scripts remove all SPI curves and load a zero curve on every RSU channel.

The one thing a .txt curve cannot reach is the Panasonic **status register**. That fault is a direct
register write.

The full technical write-up (ARIA evidence, frame formats, fault table) is
`projects/M310_M314_M110/modules/CANC/IMU_SPI_SIMULATION.md`.

---

## 2. Suggested review order

- [ ] 1. Read section 1 above and `IMU_SPI_SIMULATION.md` sections 2, 4, 5 and 7 (about 15 minutes).
- [ ] 2. `projects/M310_M314_M110/config/imu_config.py` lines 52-217: every setting the new work uses
      (section 5 below explains each one).
- [ ] 3. `projects/M310_M314_M110/config/canc_config.py` lines 10638-10700: the CAN-C IMU block, now smaller.
- [ ] 4. The shared-library additions (section 3.2): `core_functions.py` lines 2162-2208 and
      `jscript_translation.py` lines 2708-2789 and 3039-3058.
- [ ] 5. One generated CAN-C script: `CANC_13C_TestCase_7.py` (steps 3, 7 and 8).
- [ ] 6. One generated Fault_List script: `Fault_List_IMU_SEV.py` (read top to bottom).
- [ ] 7. A few curve files: open `crash_data/m310_m314_m110/spi_curves/README.md` and one fault file.
- [ ] 8. The open points of section 6, which need your decision.

---

## 3. Every file added or changed

### 3.1 New files

| File | What it is | How to review it |
|---|---|---|
| `tools/build_imu_spi_curves.py` (202 lines) | Writes every .txt curve from the settings in `imu_config.py` (and the CAN-C stimulus in `canc_config.py`). It builds each fault word, including its CRC. `--check` compares without writing. | Read `fault_word()` and `build()`. Run it with `--check` (section 8). |
| `crash_data/m310_m314_m110/spi_curves/` (44 .txt files + README, 7.5 MB) | The curves the scripts load. The README lists every file with its sample count and content. | Open the README; open one fault file, e.g. `Panasonic_sev_axis4.txt` (5 s of `0#SPI_Panasonic:00006682`, then zeros). |
| `tests/test_imu_spi_curves.py` (170 lines, 6 tests) | Reads every curve the way ARIA reads it and decodes every SPI word. It also checks that the builder reproduces the fault words of the bench's own W610 EVTs. | Read `BENCH_WORDS` (the bench words) and run the tests. |
| `projects/M310_M314_M110/modules/Fault_List/scripts/Fault_List_IMU_SEV.py` | New test: SEV alarm on each of the 6 IMU directions. | Section 4 |
| `.../Fault_List_IMU_Wrong_Address.py` | New test: each IMU channel answers with another channel's frame. | Section 4 |
| `.../Fault_List_IMU_Out_Of_Range.py` | New test: each IMU channel out of range for 35 s. | Section 4 |
| `.../Fault_List_IMU_Status.py` | New test: each channel's bit set in the IMU status register. | Section 4 |
| `.../Fault_List_HighG_SPI.py` | New test: GEN6 SPI-fault answer, wrong CRC, wrong address. | Section 4 |
| `.../Fault_List_HighG_Status.py` | New test: GEN6 internal-error status answers. | Section 4 |
| `review/IMU_SPI_TXT_SIMULATION_CHANGES.md` | This file. | - |

### 3.2 Changed files

#### `projects/M310_M314_M110/config/imu_config.py`

**Added:** the block `IMU SPI CURVE SIMULATION SETTINGS`, lines 52-217, between its BEGIN / END markers.
Nothing above it was changed. Section 5 explains each setting.

#### `projects/M310_M314_M110/config/canc_config.py`

The block `CANC IMU SPI SIMULATION SETTINGS`, lines 10638-10700, was **made smaller**.

**Removed**, because the sensor details moved to `imu_config.py` and the curves replace them:

| Removed name | Where it went |
|---|---|
| `CANC_IMU_SPI_FUNCTION` | `IMU_SPI_SENSORS['Panasonic']['function']` |
| `CANC_IMU_SPI_EVT_PATH` | `IMU_SPI_SENSORS['Panasonic']['evt_path']` |
| `CANC_IMU_SPI_EVT_SEND_COUNT` | `IMU_SPI_SENSORS['Panasonic']['evt_send_count']` |
| `CANC_IMU_SPI_FRAME` | `IMU_SPI_SENSORS['Panasonic']['frame']` |
| `CANC_IMU_SPI_AXIS_WORD` | `IMU_SPI_SENSORS['Panasonic']['axis_word']` |
| `CANC_IMU_SPI_AXIS_REGISTER` | not needed: curves address axes, not registers |
| `CANC_IMU_SPI_REST_COUNTS` | not needed: rest is 0 in the curves |
| `CANC_IMU_SPI_CRC_ERROR_MASK` | `IMU_SPI_FAULT_CURVES['Panasonic']['crc']['crc_xor']` |

**Kept, values unchanged:**
- `CANC_IMU_STIMULUS`;
- `CANC_IMU_SPI_AXIS`, the axis map, now also used by the fault scripts;
- `CANC_IMU_SPI_COUNTS_PER_UNIT`, `CANC_IMU_SPI_POLARITY`, `CANC_IMU_SPI_STIMULUS`, `CANC_IMU_SPI_SETTLE_MS`;
- `CANC_IMU_SPI_FAULT_KEY`, `CANC_IMU_SPI_FAULT_STATUS_KEYS`.

The comment on the axis map now also says that the X/Y angular rates swap if M314 mounts the IMU as W610
does. No other script used the removed names; I searched the repository.

#### `shared_libraries/jscript_translation.py`

Your earlier rule was "don't edit shared_libraries". **Please confirm or reject these three changes:**
1. **`SPI.SendCrashData`** (line 2708): now returns `["0000", ""]` on success, or `[error code, message]`
   (line 2773). It used to return nothing, so a script could not check whether ARIA took the curves. The
   failure report it writes is the same text as before.
2. **`SPI.RemoveAllCrashCurves()`** (new, line 2776): calls apym `remove_all_crash_curves`, which clears the
   curves of every SPI function so a later crash trigger replays nothing old. Returns the ARIA codes.
3. **`RSU.SendAcceleration`** (line 3039): returns the ARIA codes the same way (line 3058).

No existing caller used the old return values, so existing scripts behave the same.

#### `shared_libraries/core_functions.py`

- Line 417: `"LoadSpiCurves"` added to `__all__`, so scripts get it through `import_list`.
- Lines 2162-2208: new **`LoadSpiCurves(function, curves, rsu_channels, rsu_zero_curve)`**. Called with the
  ECU off, it:
  1. checks every file exists;
  2. removes every SPI curve;
  3. loads the zero curve on each RSU channel;
  4. sends the curves.
  
  Each step is a graded line in the report. It returns `False` if ARIA refused anything, and the scripts
  then stop before the trigger.

#### `tools/generate_canc_scripts.py` (the CAN-C generator)

| Where | What changed |
|---|---|
| Line 55 | `imu_config` added to the config modules a script may import from |
| Lines 3560-3823 | IMU helpers rewritten for curves. Hand-over without drive data; new `imu_spi_setup`, `imu_spi_step_setup`, `imu_spi_load`, `imu_spi_trigger`, `imu_spi_wait`; `imu_spi_movement` now loads the step curve, triggers, checks, then repeats with the curve inverted; the cleanup removes all curves |
| Lines 4396-4449 | `imu_spi_crc_fault` (13C 131): loads the CRC-fault curves, triggers, reads the invalid IMU values while the fault lasts, then the DTC |
| Lines 4586-4646 | 13C 135: the movement before the calibration is one load with every axis on its step curve, then the same inverted (2 loads instead of 12) |
| Lines 5782-5814 | The IMU text written into `CANC_SCRIPT_GAPS.md` |

To see exactly what changed in this generator, compare it with the copy taken before the change (section 8).

#### `tools/generate_m310_fault_list_scripts.py` (the Fault_List generator)

| Where | What changed |
|---|---|
| Docstring (top of the file) | 51 scripts, the IMU / high-g faults on .txt curves |
| Line 41 | `imu_config` imported |
| Lines 46-74 | `CONFIG_IMPORTS`: `CANC_IMU_SPI_AXIS`, `HIGH_G_FAULTS`, `IMU_FAULTS` and the `imu_config` names |
| Lines 1824-2172 | **New section** that writes the 6 new scripts: `SPI_FAMILIES` (what each script tests), `spi_handover`, `spi_qualify`, `spi_recover`, `spi_short_time`, `spi_curve_fault`, `spi_status_fault` |
| Line 2256 | The runner gets two new groups: "IMU faults (Panasonic SPI simulation)" and "Central high-g sensor faults (GEN6 SPI simulation)" |
| Lines 2299-2301 | The 6 scripts added to the build; the count check is now 51 |
| From line 2317 | `validate()` checks every DTC key and curve family the new scripts look up |

The 45 existing Fault_List scripts came out byte-identical.

#### `tools/check_jscript_wrappers_offline.py` (the offline wrapper checker)

- Lines 313-315: the fake ARIA records `send_crash_curves` and `remove_all_crash_curves`.
- Lines 546-557: 3 new checks: the `SendCrashData` return codes (success and refusal) and
  `RemoveAllCrashCurves`.
- Lines 732-757: 2 new checks of `LoadSpiCurves`:
  - the call order (remove all, RSU zero, send);
  - a missing file is a FAILED step and nothing is loaded.
- Result: **99/99 pass**.

#### Documents

| File | Change |
|---|---|
| `projects/M310_M314_M110/modules/CANC/IMU_SPI_SIMULATION.md` | Rewritten for the .txt method and both sensors (318 lines) |
| `crash_data/README.md` | Line 14: one row for the new `spi_curves` folder |
| `docs/improvements/jscript-wrapper-review.md` | Lines 92-93: two rows for the wrapper changes |

### 3.3 Regenerated scripts

| Folder | Files | What changed |
|---|---|---|
| `projects/M310_M314_M110/modules/CANC/scripts` | `CANC_13C_TestCase_1` .. `_12`, `_131`, `_135` (14 scripts) | Now use the curves. The other 444 CAN-C outputs are byte-identical |
| same | `CANC_SCRIPT_GAPS.md` | IMU section text only |
| `projects/M310_M314_M110/modules/Fault_List/scripts` | the 6 new scripts and `run_fault_list_suite.py` | New scripts; the runner lists them |

Note: `git diff` on `canc_config.py`, `generate_canc_scripts.py` and the CAN-C scripts also shows the
earlier, still uncommitted CAN-C work from 2026-10-22/23. This file describes only the .txt change.

### 3.4 The curve files (44)

| Kind | Files | Content |
|---|---|---|
| CAN-C stimulus | `Panasonic_step_axis<1..6>_<counts>.txt` (6) | 2500 counts (50 deg/s) or 2000 counts (1 g) for 2 s, then 0 for 3 s |
| CRC fault (13C 131) | `Panasonic_crc_axis<1..7>.txt` (7) | The axis frame with the CRC nibble flipped for 3 s, then 0 for 3 s |
| SEV alarm | `Panasonic_sev_axis<1..6>.txt` (6) | Error flag 01b, CRC valid, for 4 s, then 0 for 3 s |
| Wrong address | `Panasonic_address_axis<1..6>.txt` (6) | Another channel's frame for 4 s, then 0 for 3 s |
| Out of range | `Panasonic_oor_axis<1..6>.txt` (6) | 31000 counts for 35 s, then 0 for 3 s |
| GEN6 faults | `GEN6_XY_spi_axis1/3`, `_crc_axis3`, `_address_axis3`, `_cce_axis3`, `_ie_axis3` (6) | GEN6 fault answer for 4 s, then 0 for 3 s |
| Rest (axes the case does not touch) | `Panasonic_rest_<10000/12000/14000/76000>.txt`, `GEN6_XY_rest_14000.txt` (5) | Zeros, as long as the curves they go with |
| RSU zero | `RSU_zero.txt` (1) | 600 zeros for every RSU channel before a trigger |

Every fault word is in the folder's README. The SEV, wrong-address, GEN6 SPI and GEN6 internal-error words
are the bench's own EVT words, matched exactly by the test.

### 3.5 Outside the repository

- **Claude memory** (`C:\Users\cpchr\.claude\projects\C--Framework-IOEM-Py\memory\`):
  - `aria-panasonic-spi-simulation.md` rewritten;
  - `m310-fault-list.md`, `canc-script-generator.md` and `MEMORY.md` updated.
- **Offline-check tools and backups**, in the session scratchpad
  `C:\Users\cpchr\AppData\Local\Temp\claude\C--Framework-IOEM-Py\50e23b00-918f-45de-9427-a8c7a18fe757\scratchpad\`:
  - `imu_dry_run.py`: the dry-run harness;
  - `run_mutants.py`, `show_dry.py`: run the mutants and print the failures;
  - `generate_canc_scripts.before_txt.py`, `generate_m310_fault_list_scripts.before.py`: the two generators
    before the change.

  This folder is temporary and may be cleaned up later.

---

## 4. What each new test does

All six Fault_List scripts follow the same pattern. Each target (one direction, channel or fault kind) gets
its own report:

1. Bench fault-free (the usual profile), no DTC.
2. **Hand-over:** IGN OFF; the sensor's EVT if one is configured; simulation on. Then BATT OFF; the target's
   fault curve on its axis and the rest curve on the others (`LoadSpiCurves`); BATT and IGN ON; no DTC.
3. **Crash trigger** (starts the fault). Then:
   - the time until the DTC is active;
   - the DTC is active (0x8B);
   - the warning lamp is ON.
4. **After the fault part of the curve:**
   - if the fault is latched: the DTC stays active and the lamp stays ON;
   - if not: the DTC heals (0x0A) in time and the lamp goes OFF.
5. **IGN cycle:** DTC historic (0x08), lamp OFF.
6. **Clear DTC:** no DTC.

Cleanup always runs: IGN OFF, every SPI curve removed, the Panasonic simulation stopped (GEN6 stays on),
power cycle.

| Script | Targets | Expected DTC | Latched |
|---|---|---|---|
| `Fault_List_IMU_SEV` | X, Y, Z, ROLL, PITCH, YAW | SEV DTC of that direction, 0x922500 .. 0x922A00 | no |
| `Fault_List_IMU_Wrong_Address` | same 6 | the same SEV DTCs (my inference) | no |
| `Fault_List_IMU_Out_Of_Range` | same 6; **ROLL and PITCH blocked** (see 6.6) | out-of-range DTC of that direction, 0x922C00 .. 0x923100 | no |
| `Fault_List_IMU_Status` | the 6 channel bits of the status register | 0x922200 (my inference) | yes |
| `Fault_List_HighG_SPI` | SPI fault on ACC 0 (Y) and ACC 2 (X), wrong CRC on ACC 2, wrong address on ACC 2 | 0x901349 | no |
| `Fault_List_HighG_Status` | internal error "CCE" and "IE" on ACC 2 | 0x901349 | yes |

**Timing.**
- The 30.03 s out-of-range time is graded ±10 %.
- All the other times are 3 to 600 ms, below what a DTC read can resolve. They are graded only against an
  upper limit of nominal + 1 s, which still catches a late or missing DTC.

**CAN-C changes (13C cases).**

- **13C 1-12** (IMU signal values):
  1. The rest value of every IMU signal.
  2. The step curve on the signal's axis, the trigger, then checks:
     - the change equals the stimulus;
     - every other IMU signal is unchanged;
     - the polarity sign is right;
     - the signal is back at rest after the step.
  3. The same with the curve inverted (the polarity reversed), then no DTC.
  
  Cases 7-12 redo the CAN wakeup after each load.
- **13C 131** (IMU fault):
  1. The CRC-fault curves on all 7 axes.
  2. Every IMU signal 0xFFFF while the fault lasts, then the IMU CRC DTC (0x921F00).
  3. After an IGN cycle the DTC is historic and the signals are valid again.
- **13C 135:** every axis on its step curve, then inverted, every signal following. Then the ECU's own IMU
  for the calibration.

---

## 5. The settings, in `imu_config.py` (block lines 52-217)

Each setting is labelled **FACT** (read from ARIA, the bench files or the configuration) or **ASSUMPTION**
(to confirm on the bench).

| Setting | Line | Value | Meaning | Label |
|---|---|---|---|---|
| `IMU_SPI_CURVE_DIR` | 70 | `crash_data/m310_m314_m110/spi_curves` | Folder of the curve files | - |
| `IMU_SPI_CURVE_SAMPLE_MS` | 76 | 0.5 | Time per line of a curve | **ASSUMPTION** |
| `IMU_SPI_RSU_CHANNELS` | 80 | RSU_CH1-18 | RSU channels zeroed before a trigger (the bench loadbox has exactly these) | FACT |
| `IMU_SPI_RSU_ZERO_CURVE` / `_SAMPLES` | 81-82 | `RSU_zero.txt`, 600 | The zero curve | - |
| `IMU_SPI_CURVE_NAMES` | 86 | file name patterns | Shared by the tool and the scripts | - |
| `IMU_SPI_SENSORS` | 111 | `Panasonic`, `GEN6_XY` | Per sensor: ARIA function name, EVT to send (`evt_path`, **None today**), whether to stop the simulation after a test, axis names, SPI frame and CRC, data-0 word per axis | FACT (frames verified against ARIA and the bench EVTs) |
| `IMU_SPI_STEP_CURVE` | 130 | 2000 ms step, 3000 ms rest | Shape of the CAN-C stimulus curve | - |
| `IMU_SPI_FAULT_CURVES` | 151 | per sensor and fault kind | Which axes, the fault recipe (bits to set / clear, CRC flip, other channel's word, or a data value), fault and valid-data lengths, the DTC's nominal times | Recipes: FACT (bench EVTs); times: FACT (fault list) |
| `IMU_SPI_GRADED_MIN_MS` | 175 | 1000 | Times from this up are graded ±10 %; shorter ones against nominal + 1 s | - |
| `IMU_SPI_FAULT_TIMING_TOLERANCE_PERCENT` | 176 | 10 | Timing tolerance | - |
| `IMU_SPI_DIRECTIONS` | 185 | X, Y, Z, ROLL, PITCH, YAW | Direction → CAN-C signal → (through the axis map) sensor channel, and its SEV / out-of-range DTC keys | **INFERENCE** (from the DTC names) |
| `IMU_SPI_DIRECTION_FAULT` | 193 | address → SEV | A wrong address is expected to set the SEV DTC | **INFERENCE** |
| `IMU_SPI_GEN6_FAULT_KEYS` | 194 | SPI / CRC / address → HIGH_G0_SPI; CCE / IE → HIGH_G0_INTERNAL | GEN6_XY taken as high-g instance 0 | **ASSUMPTION** |
| `IMU_SPI_RUN_ROLLOVER_RISK` | 200 | **False** | Blocks out of range on ROLL / PITCH | safety switch |
| `IMU_SPI_STATUS_FAULT` | 211 | register 0x16, normal 0x00102ECB, 6 fault words, DTC IMU0_INTERNAL | The status-register fault | Words: FACT (bench EVT); DTC: **INFERENCE** |

---

## 6. Open points that need you

1. **Axis map (canc_config `CANC_IMU_SPI_AXIS`, unchanged).** The W610 bench files show the IMU turned
   90 deg. If M314 mounts it the same way:
   - LONG_ACCEL / LATTERAL_ACCEL swap (5 / 4);
   - X_AXIS_ANGULAR / Y_AXIS_ANGULAR swap (2 / 1);
   - one accel and one gyro change sign.
   
   Change it now, or after 13C 1-6 run? A wrong map cannot pass: the stimulus moves another signal (CAN-C)
   or another direction's DTC appears (Fault_List).
2. **Which fault-free EVTs to use.** The M314 loadbox gives `Panasonic` and `GEN6_XY` no EVT, so
   `IMU_SPI_SENSORS[...]['evt_path']` must name one per sensor. Candidates are in
   `C:\AriaConfigFiles_Generic\AriaConfigFiles\Config_folder\SPI\XLS\`:
   - `P41_EVT_FaultFree_Panasonic_W610_SC3_2S_KG ECU Fault free.xlsx`;
   - `EVT_FaultFree_Gen6_1_inst0_W610_SC3_2S_ECU.xlsx`.
   
   Each EVT carries one ECU sample's sensor identity.
3. **Bench wiring.** In the bench loadbox both SPI functions have `Channel -1` and the SPI cards bind no
   function: they must be bound before anything runs (ARIA said "Card not present" on 2026-10-15).
4. **Time per curve sample (0.5 ms).** The first run of 13C 1 shows it: the signal must be back at rest
   2.5 s after the trigger. If the card plays slower, set `IMU_SPI_CURVE_SAMPLE_MS` from what you see.
5. **Expected DTCs I inferred:** wrong address → SEV DTC; status bit → 0x922200 (0x922300 the
   alternative); GEN6_XY = high-g instance 0; 0x8B with the lamp for all of them. The DTC read lists
   everything present, so a different DTC shows clearly.
6. **Rollover risk.** Out of range on ROLL or PITCH holds 620 deg/s for 35 s and may fire the rollover
   loads, storing a crash record. These two targets report "not run" until you set
   `IMU_SPI_RUN_ROLLOVER_RISK = True`, after the bench and ECU owners agree.
7. **The shared-library changes** of section 3.2: keep them, or have them moved into the generated scripts?
8. **Curve length.** The out-of-range curves are 76000 samples. The longest IMU curve the bench has used is
   20000, so it is not confirmed that the card takes 76000.

**Left out on purpose:**
- **GEN6 out of range / saturation:** a saturated central high-g sensor held for 0.5 s is a crash pulse and
  can deploy.
- **SEV for GEN6:** SEV is an IMU-only concept.
- **The Panasonic X2 / b13 / D0 frame-bit faults:** bench EVTs exist, but the DTC they should set is
  unclear.

---

## 7. What is a fact and what is not

| Fact, checked | Not yet known |
|---|---|
| ARIA's .txt format, including the blended fault lines (read from ARIA's code) | The time per sample on the card |
| The crash trigger starts the curves and also replays RSU curves | Whether `Simulate Sensor` off gives the ECU its own Panasonic back |
| Panasonic frame and CRC (matched ARIA on 408 words); GEN6 frame and CRC (matched 92 of 98 bench EVT words) | Which EVT fits the M314 ECU |
| Every fault word equals the bench's W610 EVT word | The M314 IMU mounting (axis map, signs) |
| The bench loadbox RSU channels (RSU_CH1-18) and the unbound SPI functions | The expected DTCs marked INFERENCE above |

---

## 8. How to re-check it yourself

Run from `C:\Framework_IOEM_Py`:

```powershell
# Curves match the settings (0 differ) and decode as ARIA reads them (6 tests OK)
py -3.14 tools/build_imu_spi_curves.py --check
py -3.14 -m unittest tests.test_imu_spi_curves -v

# Fault_List scripts match their generator (52 files, 0 differ)
py -3.14 tools/generate_m310_fault_list_scripts.py --check

# Shared-library wrappers, offline (99/99)
py -3.14 tools/check_jscript_wrappers_offline.py

# Existing crash-curve test still passes
py -3.14 -m unittest tests.test_crash_configuration

# Exact generator changes: compare with the copies taken before the change
git diff --no-index "C:\Users\cpchr\AppData\Local\Temp\claude\C--Framework-IOEM-Py\50e23b00-918f-45de-9427-a8c7a18fe757\scratchpad\generate_canc_scripts.before_txt.py" tools/generate_canc_scripts.py
git diff --no-index "C:\Users\cpchr\AppData\Local\Temp\claude\C--Framework-IOEM-Py\50e23b00-918f-45de-9427-a8c7a18fe757\scratchpad\generate_m310_fault_list_scripts.before.py" tools/generate_m310_fault_list_scripts.py

# Shared-library changes only (these files were clean before)
git diff shared_libraries/core_functions.py shared_libraries/jscript_translation.py
```

The CAN-C generator has no `--check`: running it rewrites all CAN-C scripts.

**Dry run (done 2026-10-24).** The 20 new and changed scripts ran against a modelled ECU on a virtual
clock; no hardware was touched.
- All checks passed except the two intended "ROLL / PITCH not run" lines.
- Deliberately broken ECU behaviours made the right scripts fail:
  - wrong polarity, wrong axis, LONG/LAT swapped;
  - the card ignoring the inversion flag, or playing at half speed;
  - the ECU ignoring CRC, SEV, wrong address, out of range, status or GEN6 faults;
  - a SEV that latches.

The model uses the same assumptions as the scripts. So it proves the scripts are consistent and their
checks catch faults, not that the real ECU behaves this way. Only the bench can show that.
