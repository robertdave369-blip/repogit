# Common test set-up for the M210 EDR black-box tests

Every bug document in `bugs/` refers to this set-up and lists only what it adds or changes.

## Device under test
- M210 SRS ECU (SC3-2S, airbag control unit) with the software release under test. Record the
  versions with `$22 F181 / F182 / F191 / F1B7 / F180` (the framework's `read_software_version()`
  compares them with `projects/M210/config/project_config.py`).
- Two event records: DID `0x0455` (EDR record 1) and `0x045B` (EDR record 2). Supplier data:
  `0x0456` / `0x045C`. Read with `$22`; the framework opens the extended session and security
  level 1 first (`edr_config.EDR_DECODER_CONFIG["read"]`).
- Record the build variant (APPRISE or VTA algorithm executable). Some findings apply to one
  variant only.

## Bench
| Item | Use |
|---|---|
| ARIA bench (ARIA 5.20) | squib loads, RSU and central sensor simulation, crash-curve playback, power supply |
| Vector VN1610 s/n 48714 | CH1 ARIA chassis, CH2 ECU CAN-FD (M210 FD DBC `SRS_FD_40250_22042026.dbc`) |
| HS-CAN | M210 HS DBC `SRS_HSCAN_40250_22042026.dbc` (SRS1_20 0x2C0) |
| Programmable power supply | nominal 12 V (`power_config.NOMINAL_VOLTAGE`), under/over voltage, battery cut-off |
| CAN trace | log every Rx frame the bench sends and every SRS Tx frame (SRS1_FD_10 0x13C 10 ms, SRS1_20 0x2C0 20 ms, SRS_CANNM 0x36D) for the whole test, with time stamps |

## Standard preconditions (unless a document says otherwise)
1. Supply at nominal voltage, all squib loads and RSUs connected, all Rx frames of the M210 DBC
   simulated with valid, non-default values (framework CAN simulation, `canc_config` values).
2. `fault_free_profile()` (EOL and variant code from `project_config`, NVM cleared): DTC read
   (`$19 02`) shows no active fault; warning lamp off.
3. Both EDR records read `FF ...` (customer rule: no event recorded -> all bytes `FF`, reserved
   bytes included). Save both responses as the baseline.
4. Ignition ON for at least the proveout time before any crash.

## Crash stimuli
- Single crashes: framework keys `front`, `left`, `right`, `rear`, `near` (M210 currently uses the
  M314 curve files, see `projects/M210/config/crash_curve_config.py`; replace them with M210
  curves when available). `load_crash_curves(<key>)` power-cycles the ECU with the curves loaded;
  `TriggerCrash()` starts playback.
- Multi-event sets: `crash_data/multi_event/multi_crash_<key>/` (see `crash_data/README.md`):
  parallel (100 ms), concatenated (400 ms), multi (2000 ms), single (6000 ms), boundary
  (500 / 501 / 800 / 801 / 4999 / 5000 / 5001 ms) and the three-event 000-111 near/deployment
  matrix.
- "Near crash" = algorithm wake-up without deployment (the `near` curve, or a deployable curve
  scaled below the deployment threshold).

## Evidence to collect in every test
- Full `$22` responses of `0x0455`, `0x045B`, `0x0456`, `0x045C` before and after each event
  (raw hex, time stamp).
- `$19 02` DTC response before and after.
- CAN trace (all Rx and Tx frames) from 10 s before the first trigger to the last read.
- ARIA log: crash-curve files, trigger instants, squib firing times.
- Supply voltage trace when a test changes the supply.
- Decoded record (framework `read_edr_parameters`, `edr_sample_records`) next to the raw bytes.

## Software check before any test
- The M210 release has two EDR records. `$22 04 5D` (a record-3 DID in the W610 layout) must not return a
  record; if it does, the ECU runs a 3-record build (as found under `Builds\SWBuild` in the M210 tree), not
  the M210 release (P31 map: 2 records).
- Note the algorithm variant: the M210 releases are APPRISE builds (`Application_APPRISe`).

## Reading the results
- Byte numbers in the bug documents are the customer sheet's `POS_IN_BYTES` from M312_M112_M210 SRS **V3.4**,
  sheet `EDR_0455_045B`: a 0-based offset into the DID data after `62 04 55` (byte 0 = first data byte, e.g.
  LifeTimeEventNb bytes 0-3, MultiEventNumber byte 21, crash type byte 22, CompletionStatus byte 216 bits 7/6).
- Bits are numbered 0 = LSB, 7 = MSB; multi-sample fields start at the MSB of their first byte.
- The framework's `projects/M210/config/edr_config.py` `data_start_byte` = V3.4 byte + 4 (it counts the three
  response header bytes and is 1-based). Its positions follow V3.4 since 2026-10-28 (README, test-side
  findings T1, T2, T5); T6 (byte 855 bit overlap) is fixed too; T7 (IMU sign) is still open.
- Sensor DIDs (0x045F ... 0x04A1): 521 data bytes, -10 ms at byte 0, 0 ms at byte 20, 250 ms at byte 520 (V3.4).
