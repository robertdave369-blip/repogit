# M210-EDR-13: First post-T0 sample of every CAN-C time series is discarded; 1-per-second elements jump 2 s from '0 s' to '+1 s'

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | High (1 s group), Medium (500 ms / 250 ms groups) |
| Area | EDR CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (post-index reset at T0, timer-tick capture, 65 formatters starting at read index 1). |
| Related | Reviewer findings CAN-02, SNS-07 (IMU 2/s series), TX-02 (STS_CRASH) |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
After T0 every CAN-C element is captured on the free-running 1 s / 500 ms / 250 ms timer ticks into a post buffer that starts at index 0. Every post-T0 formatter starts reading at index 1 ('T0 is collected from PreEvent Data'), so the first post-T0 sample is thrown away. For the 1 s group, which gets no T0 sample at all (see M210-EDR-14), the reported '0 s' and '+1 s' values are always two ticks apart and each post-T0 slot holds data one second late. For the 500 ms / 250 ms groups the same shift happens when T0 falls shortly after a tick (no extra T0 sample).

## Expected behaviour (requirement source)
- V3.4 EDR_0455_045B sample labels: e.g. Gear r313-r321 'Gear at -5 S' ... 'at 3 S' (1/s, bytes 347-351); Vehicle Speed r33-r49 -5 S ... 3 S (2/s, bytes 30-63); VCU_DRV_ADV_MODE r964-r969 (1/s, -3 S ... 2 S, bytes 845-847).
- A sample labelled '+k s' holds the CAN value at about T0 + k s (within one sampling period).

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1477-1483 post indices reset at T0 (rstedr_InitializeEventAdditional, called from RstEdr/Implementation/Source/RstEdr.c:2361)
- RstEdr/Implementation/Source/RstEdr.c:5160-5196 post capture only on 250 ms / 500 ms / 1 s timer expiry; timer chain reset only at init (RstEdr/Implementation/Source/RstEdr.c:1004)
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:8036-8060 rstedr_FormatGearDataPostTimeZero: `u8EventDataReadIndex = 1U;` (same pattern in 65 formatters)
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1691-1708 T0 refresh only for the 500 ms (if last tick >= 100 ms old) and 250 ms groups; none for the 1 s group

## Actual / suspected behaviour
1 s group (Gear, STS_HIGHBEAM/LOWBEAM, STS_TPMS_LED, STS_ABS/EBD/ESC/TCS, VCU_IGN_STS, EMERGENCY_BRAKING_REQ, ALERT_MESSAGE, VCU_DRV_ADV_MODE/_STS, RCW, LKA_HANDSOFF): '0 s' = value at T0 - d (d = 0..1 s), '+1 s' = value at T0 + 2 s - d, '+2 s' = T0 + 3 s - d, '+3 s' = T0 + 4 s - d; the value at T0 + 1 s - d is lost. 500 ms group: when d < 100 ms (about 1 crash in 5) all post values are one slot late.

**Observable at:** Gear bytes 347-351 (V3.4 r313-r321); VCU_DRV_ADV_MODE 845-847; Vehicle Speed 30-63; IMU 357-560

## Test set-up
- Common set-up.
- Frontal or near-crash curve (a near crash avoids squib wear; any recorded event works).

## Preconditions
- Standard preconditions.

## Input signals
- VCU2_FD_100 GEAR_ACTUAL (or the M210 gear signal configured in canc_config) stepped every 250 ms through a repeating pattern 1,2,3,...,7 so that every second has a distinct value; log the exact Tx times on the bus.
- Alternative: VCU_DRV_ADV_MODE stepped 0..14 every 250 ms.

## Triggering conditions
Any recorded event while the stepped signal is on the bus.

## Execution steps
1. Start the stepped signal 10 s before the crash and keep it running until T0 + 10 s.
2. TriggerCrash(); record the trigger instant on the same time base as the CAN trace.
3. Wait 10 s, read 0x0455.
4. Decode the 9 Gear nibbles and map each to the CAN value present at the labelled instant (T0 = trigger + RSU T0 offset).
5. Repeat 5 times with the trigger moved by 200 ms each time (different tick phase).

## Expected results
- Each nibble equals the CAN value at its labelled instant (+/- 1 s for 1/s data); consecutive post-T0 slots are 1 s apart.

## Actual / suspected results
- The '+1 s' nibble equals the CAN value about 2 s after the '0 s' nibble in every run; one value of the pattern never appears; post-T0 slots match the trace one second later than labelled.

## Pass / fail criterion
FAIL if post-T0 slots are systematically one period late or one sample is missing.

## Evidence to collect
- CAN trace with Tx time stamps of the stepped signal; trigger time; DID response; decoded table per run.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The designer assumed a T0 sample in the post buffer; that only holds for the 500 ms group when the last tick is >= 100 ms old.
- Our framework scripts drive one value per window and sample mid-window, so they may not reveal a one-slot shift; this test needs a changing signal.
