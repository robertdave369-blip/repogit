# M210-EDR-24: Deployment times are reported in 0.5 ms ticks in a field the customer defines in 1 ms (values doubled)

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | High |
| Area | Sensor / deployment recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (capture, Mahindra report, platform formatter); RstEdr_MainFunction period read from the ARXML. |
| Related | Reviewer finding SNS-01 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The event timer counts RstEdr main-function cycles of 0.5 ms. The Mahindra 'Deployment Time' element copies the raw tick count into the 2-byte field. The platform formatter for the same data halves it (`>> 1`); the Mahindra element does not.

## Expected behaviour (requirement source)
- V3.4 r153-r176 '<loop> - Deployment Time': 2 bytes, resolution 1, unit ms, range 0..255 (bytes 165-212).
- Framework M210 edr_config: scaling 1.0 ms for the deployment-time elements.

## Code evidence
- RstEdr/Config/Behaviour/RstEdr_Behvr.arxml:78 `<PERIOD>5.0E-4</PERIOD>`; AAUR_SW_RstEdr_201 'increment ... every 0.5 ms'
- RstEdr/Implementation/Source/RstEdr.c:3817 `au16TimetoSendCmdTab[u8indexTmp] = u16TimeFromTime0;`
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6704 `deployment_time = ...au16TimetoSendCmdTab[squib_position];` -> RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6719 `RSTEDR_UTI_SWAP_AND_COPY16` (no conversion)
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:18525-18527 platform formatter: 'Convert from raw ... * 0.0005', `u16ReportData = u16TimeToFire >> 1u;`

## Actual / suspected behaviour
A loop fired 15 ms after T0 is stored as 0x001E (30 ms); loops fired after 127.5 ms exceed the documented 255 ms range.

**Observable at:** Bytes 165-212 (24 deployment-time words) of 0x0455 / 0x045B

## Test set-up
- Common set-up; ARIA squib-firing time capture (or oscilloscope on a squib load) on the same time base as the trigger.

## Preconditions
- Standard preconditions.

## Input signals
- Vehicle speed 50 km/h; all Rx frames valid.

## Triggering conditions
Any deployment.

## Execution steps
1. load_crash_curves(`front`); TriggerCrash(); log the firing instant of every fired loop.
2. Compute T0 (trigger + RSU T0 offset, rsu_config) and the expected time per loop in ms.
3. Read 0x0455 after 10 s; decode bytes 165-212 big-endian.
4. Repeat with `left` (later side deployment).

## Expected results
- Each fired loop's word = (firing time - T0) in ms (+/- 1 ms); non-fired loops 0xFFFF.

## Actual / suspected results
- Each fired loop's word = about 2 x (firing time - T0).

## Pass / fail criterion
FAIL if the reported time is about twice the measured firing time.

## Evidence to collect
- Squib firing log with time stamps; trigger time; DID response.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Only DiagMgr (not in the tree) could still halve the value; the black-box test decides.
- TimeBtwEvents and TimeMaxDeltaV are specified in 0.5 ms and are reported raw correctly.
