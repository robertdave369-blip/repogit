# M210-EDR-15: STS_CRASH and PIB_ACTIVE samples from +5.5 s to +9 s are never captured and always read 0

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | High |
| Area | EDR CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (completion rule, after-end-of-event state machine, empty additional-completion hook, formatter padding). |
| Related | Reviewer findings EVT-03, CAN-04; multi-event open points AMB-09 / ICP-43 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The -1 s..+9 s series are sized for 21 samples, but the record is completed and written at about T0 + 5.1 s and capture stops then. The formatter fills the missing slots with 0.

## Expected behaviour (requirement source)
- V3.4 r995-r1015 'STS_CRASH at -1 S' ... 'at 9 S' (bytes 858-860); r1033-r1053 'PIB_ACTIVE at -1 S' ... 'at 9.0 S' (bytes 866-868).
- Conflict: customer EDR_Requirements r9 'CompletionStatus will be updated as 1 after 5 seconds from T0'.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:2209-2252 completion: all tables complete and > 10000 ticks; UNECE/NHTSA complete at 10200 ticks (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:184-197)
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1878-1887 rstedr_SetAdditionalCompleteFileRecorded is empty (nothing holds the record open for +9 s data)
- RstEdr/Implementation/Source/RstEdr.c:3287-3314 capture only in state CAPTURE; after the write the state is RECORD
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:2741-2758 0..9 s capture; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16728-16760 formatter pads uncaptured samples with `0U`

## Actual / suspected behaviour
With STS_CRASH or PIB_ACTIVE = 1 on CAN after +5 s, the record shows 0 for +5.5 s ... +9 s.

**Observable at:** Bytes 858-860 (STS_CRASH), 866-868 (PIB_ACTIVE)

## Test set-up
- Common set-up.
- Frontal deployment curve (PIB request expected) and the CAN trace of SRS1_FD_10.

## Preconditions
- Standard preconditions.

## Input signals
- PIB confirmation signal as used by RSTEDR_GET_PIB_CONFIRMATION held at 1 from T0 to T0 + 10 s (simulate it on CAN if it is an Rx signal).

## Triggering conditions
Any recorded event with the series' source = 1 after T0 + 5 s.

## Execution steps
1. TriggerCrash(); keep the PIB source at 1 for 10 s.
2. Read 0x0455 at T0 + 15 s.
3. Decode the 21 STS_CRASH bits (858.7 ... 860.3) and 21 PIB bits (866.7 ... 868.3); compare with the CAN trace.

## Expected results
- PIB_ACTIVE bits for +5.5 ... +9 s = 1 (as on CAN).

## Actual / suspected results
- The last 8 bits of both series are 0 (bytes 860 bits 7..3 and part of 859).

## Pass / fail criterion
FAIL against V3.4 rows if the +5.5 ... +9 s samples do not follow the CAN signal; record the customer decision on AMB-09.

## Evidence to collect
- DID response; CAN trace 0..10 s after T0.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Either the completion time must be extended for these elements or the customer must remove the +5.5 ... +9 s samples.
