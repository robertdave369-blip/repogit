# M210-EDR-11: RstEdr power-down is one-way: an aborted shutdown leaves EDR inactive until reset

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Other EDR (power handling) |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence; power-down latch re-read. |
| Related | Reviewer finding EVT-16 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
RstEdr_PowerDown latches a request that only Init clears; the running event is forced to end and written; new events are blocked. If the system mode manager requests power-down (e.g. on under-voltage or IGN OFF) and then returns to normal operation without a reset, EDR stays dead.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r9: CompletionStatus 1 after 5 s if battery available; events must be recorded whenever the ECU operates.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:2020-2024 request latched; RstEdr/Implementation/Source/RstEdr.c:960 cleared only in Init; RstEdr/Implementation/Source/RstEdr.c:2940 new events blocked; RstEdr/Implementation/Source/RstEdr.c:3090-3095 forced end of event

## Actual / suspected behaviour
After a brief under-voltage dip that triggers power-down but no reset, a following crash is not recorded.

**Observable at:** Both DIDs after the second crash

## Test set-up
- Common set-up; programmable supply able to dip below the shutdown threshold briefly.

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Power-down request without a following reset.

## Execution steps
1. Dip the supply to the shutdown threshold for the time the SysModMgr needs to request power-down, then restore (no reset).
2. Check the ECU keeps communicating (no reset: SW version DIDs answer, no start-up messages).
3. Trigger a near crash; read both DIDs.

## Expected results
- The crash is recorded.

## Actual / suspected results
- No record.

## Pass / fail criterion
FAIL if no record is created while the ECU is otherwise operating.

## Evidence to collect
- Supply trace; CAN trace (NM, startup frames); both DIDs.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on when SysModMgr calls RstEdr_PowerDown (not in the tree); it may always be followed by a reset.
