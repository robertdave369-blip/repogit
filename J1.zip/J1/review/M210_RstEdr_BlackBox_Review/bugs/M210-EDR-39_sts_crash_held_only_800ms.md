# M210-EDR-39: STS_CRASH / DOOR_UNLOCK / CRASH_LOCATION return to 0 about 800 ms after the deployment decision

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium (code) |
| Area | ECU Tx signals |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (EnsMgr output window). |
| Related | Reviewer finding TX-05; multi-event open point AMB-22 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
After 1600 x 0.5 ms EnsMgr clears the CAN crash status; nothing holds STS_CRASH until ignition OFF.

## Expected behaviour (requirement source)
- DBC gives no duration; the EDR series runs to +9 s (V3.4 r1015); EV multi-event spec r46 '+0.5..+9.0 s = 1 (held - AMB-22)'.

## Code evidence
- EnsMgr/Implementation/Source/EnsMgr.c:529-536 window end clears EcallStartedAtLeastOnce and EnsAlgoSevStatusForCAN; EnsMgr_PBCfg.h:64 1600U

## Actual / suspected behaviour
STS_CRASH = 1 for 800 ms +/- 25 ms.

**Observable at:** SRS1_FD_10 STS_CRASH, SCM counter; SRS1_20 DOOR_UNLOCK

## Test set-up
- Common set-up; CAN trace.

## Preconditions
- Standard preconditions.

## Input signals
- -

## Triggering conditions
Any deployment.

## Execution steps
1. Run a frontal deployment; measure the STS_CRASH and DOOR_UNLOCK high time and the SCM counter behaviour.

## Expected results
- Per customer (AMB-22 open).

## Actual / suspected results
- About 800 ms.

## Pass / fail criterion
Report the measured duration; get the requirement.

## Evidence to collect
- CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- 800 ms matches the ENS window and may be the agreed behaviour.
