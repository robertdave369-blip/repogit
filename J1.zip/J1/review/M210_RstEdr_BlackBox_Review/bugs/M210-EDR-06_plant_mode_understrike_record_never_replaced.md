# M210-EDR-06: Plant-mode understrike record (unlocked, priority 1) is never replaced by later near crashes

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | Other EDR (record management) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (understrike priority, slot search). |
| Related | Reviewer finding EVT-05; supplier bench test 12 (plant mode near crash 0x40) |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
In non-normal crash mode (plant mode) an understrike event is stored unlocked with priority level 1. Near crashes (level 7) can only replace empty or level-7 slots, so the plant-mode record stays in its slot until a deployment.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r8: a near crash is recorded but not locked, i.e. it can be overwritten; overwrite rows r23-r26: the oldest unlocked record is replaced.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1542-1555 understrike: normal mode -> LOCKED|LEV1, else `|= RSTEDR_EVENT_PRIO_LEV1` (unlocked)
- RstEdr/Implementation/Source/RstEdr.c:3458-3499 / :3404 LEV7 events search EMPTY and LEV7 only

## Actual / suspected behaviour
After leaving plant mode, owner-mode near crashes rotate only through the other record; the plant-mode record stays.

**Observable at:** DID 0x0455 / 0x045B bytes 0-3 (LifeTimeEventNb), 22

## Test set-up
- Common set-up; plant-mode entry/exit routine (bench test 12: $31 01 F1 06 02) and an understrike-type deployable curve.

## Preconditions
- Plant mode active as in supplier bench test 12.

## Input signals
- All Rx frames valid.

## Triggering conditions
Plant-mode understrike event, then two owner-mode near crashes > 5 s apart.

## Execution steps
1. Run bench test 12 (understrike in plant mode); read 0x0455 (byte 22 = 0x40 expected).
2. Exit plant mode (test 13 steps).
3. Run near crash A; wait 10 s; run near crash B (> 5 s later, new ignition cycle allowed).
4. Read both DIDs after each.

## Expected results
- After A and B both records hold owner-mode near crashes (the plant-mode record was the oldest unlocked).

## Actual / suspected results
- One record keeps the plant-mode event (lowest LifeTimeEventNb); A then B replace each other in the other slot.

## Pass / fail criterion
FAIL if the plant-mode record survives two later unlocked events.

## Evidence to collect
- Both DIDs after each step; mode routine responses; DTCs.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Keeping priority 1 for an understrike may be intended; confirm with the customer.
