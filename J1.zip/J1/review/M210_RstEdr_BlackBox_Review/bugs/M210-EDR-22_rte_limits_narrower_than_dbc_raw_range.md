# M210-EDR-22: RTE type limits are narrower than the DBC raw range; if CanMgr saturates to them, recorded values are wrong

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | OnFail-on-CAN / CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence (Rte_RstEdr_Type.h limits; W610 bench sheet). |
| Related | Reviewer finding CAN-13 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
MotorSpeed limits are +/-32760 while the DBC raw range is 0..65535 (offset -32767); ADAS steering angle, vehicle speed and steering limits also exclude DBC invalid/default codes. The W610 bench report recorded a motor speed of 0x95AB as 0x7FF8 (clamped).

## Expected behaviour (requirement source)
- Customer EDR_Requirements r7 (as per DBC, incl. on-fail); invalid codes consumed (on-fail matrix).

## Code evidence
- RstEdr/Implementation/Cfg/Rte_RstEdr_Type.h:137-138 MotorSpeed_LowerLimit / _UpperLimit; RstEdr passes .Data unchanged (RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6099)

## Actual / suspected behaviour
Raw values beyond the limits (forward motor speed, positive ADAS angles, invalid codes 0xFFFF / 0x7FFF) are clipped.

**Observable at:** Bytes 87-120 (motor speed), 625-646 (ADAS angle), 30-63 (vehicle speed), steering angle rows

## Test set-up
- Common set-up.

## Preconditions
- Standard preconditions.

## Input signals
- VCU_MCU_MOTOR_SPEED raw 0x95AB; ADAS_DES_STRWHL_ANGLE_CMD raw 9000; VEHICLE_SPEED raw 0xFFFF (invalid).

## Triggering conditions
Any recorded event.

## Execution steps
1. Set the raw values; trigger a near crash; read 0x0455; compare raw bytes.

## Expected results
- Raw values recorded unchanged (or per the on-fail rule for invalid codes).

## Actual / suspected results
- 0x7FF8 instead of 0x95AB, other values clipped.

## Pass / fail criterion
FAIL if a valid DBC raw value is altered.

## Evidence to collect
- DID response; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on CanMgr (not in the tree); the W610 evidence may not apply to M210.
