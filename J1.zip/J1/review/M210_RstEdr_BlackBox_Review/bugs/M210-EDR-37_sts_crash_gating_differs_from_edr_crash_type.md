# M210-EDR-37: STS_CRASH / DOOR_UNLOCK / ENS use different gating from the EDR crash type (front needs SEV2 and arming)

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium (pretensioner-only front), Low (arming cases) |
| Area | ECU Tx signals vs EDR |
| Build variant | APPRISE and VTA |
| Verification | Code re-read in EnsMgr (EDR bit at SEV1, CAN bit needs arming + SEV2 for front). |
| Related | Reviewer finding TX-03 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The EDR crash type is set at the severity-1 threshold ('any loop deployment'); the CAN/ENS crash status for a front crash additionally needs severity 2 ('any airbag deployment') and the arming state at that instant. A frontal event that fires only pretensioners is recorded as a locked front crash, but STS_CRASH / DOOR_UNLOCK stay 0; rear and side pretensioner-only events do send STS_CRASH.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r8 (only a near crash suppresses STS_CRASH/Door unlock) and r19-r20 (deployment event vs near crash); EV multi-event spec r906 (pretensioner-only deployment STS_CRASH = 1).

## Code evidence
- EnsMgr/Implementation/Source/EnsMgr.c:210-215 EDR crash type at SEV1 in normal mode
- EnsMgr/Implementation/Source/EnsMgr.c:220-225 CAN bit needs EcallStartedAtLeastOnce FALSE, arming != NOT_CLOSED and (front) SEV2
- EnsMgr/Implementation/Source/EnsMgr.c:589-598 STS_CRASH / unlock follow only the CAN bit; EnsMgr_PBCfg.h:123/126 thresholds 0x0002 / 0x0004

## Actual / suspected behaviour
Pretensioner-only frontal crash: byte 22 = 0x81 (front, locked) but STS_CRASH = 0, DOOR_UNLOCK = 0, no ENS deploy pulse.

**Observable at:** SRS1_FD_10 STS_CRASH / CRASH_LOCATION, SRS1_20 DOOR_UNLOCK, ENS GPO, byte 22

## Test set-up
- Common set-up; a frontal curve that fires pretensioners only (project calibration).

## Preconditions
- Standard preconditions.

## Input signals
- Driver and passenger buckled (pretensioner firing enabled).

## Triggering conditions
Pretensioner-only frontal deployment.

## Execution steps
1. Run the curve; record CAN and ENS; read 0x0455.
2. Repeat with a rear pretensioner-only curve for comparison.

## Expected results
- STS_CRASH = 1 (deployment event) for both, or as the customer defines.

## Actual / suspected results
- Front: STS_CRASH = 0 while the record is a locked front crash; rear: STS_CRASH = 1.

## Pass / fail criterion
FAIL if a recorded deployment event sends no STS_CRASH, unless the customer confirms airbag-only.

## Evidence to collect
- CAN trace (both buses); ENS line; DID; squib log.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The SEV2 rule for front is an explicit design choice (EnsMgr comment); Mahindra may want STS_CRASH only for airbag deployments.
