# M210-EDR-08: Record lock, priority, lifetime and multi-event data are saved only by an orderly power-down

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | Other EDR (record management) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (synthesis block handling, init, read-out decision). |
| Related | Reviewer finding EVT-08 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The event records are written to NvM when complete, but the synthesis block (per-slot priority/lock, lifetime numbers, multi-event numbers) is only flagged for writing in the power-down path. If the ECU resets without that path, the old synthesis is restored at start-up; read-out answers 'no record' for an EMPTY priority and the slot is treated as free.

## Expected behaviour (requirement source)
- Recorded and locked events survive any reset (customer EDR_Requirements locked rows r24-r30; multi-event spec).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:3309-3313 record write updates only the RAM synthesis
- RstEdr/Implementation/Source/RstEdr.c:1453-1470 / :1511-1514 NvM_SetRamBlockStatus only in power-down
- RstEdr/Implementation/Source/RstEdr.c:1007-1012 init restores priorities from the synthesis
- RstEdr/Implementation/Source/RstEdr.c:7380-7385 EMPTY priority -> RSTEDR_REQ_NO_RECORD

## Actual / suspected behaviour
After a deployment and an abrupt reset (e.g. $11 01 hard reset, or a supply cut without the shutdown sequence), the DIDs may read FF and the next event overwrites the slot.

**Observable at:** DID 0x0455 / 0x045B after the reset; next event's slot

## Test set-up
- Common set-up; diagnostic ECU reset ($11 01) and a fast supply cut (PSU output off, no energy-reserve shutdown).

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Reset without the RstEdr power-down sequence after a recorded event.

## Execution steps
1. Frontal deployment crash; wait 10 s (record written).
2. Send $11 01 (hard reset) immediately; read both DIDs after start-up.
3. Run a near crash; read both DIDs.
4. Repeat with an abrupt supply cut instead of $11 01.

## Expected results
- The locked frontal record is still reported and is not overwritten by the near crash.

## Actual / suspected results
- The record reads FF and/or is overwritten; LifeTimeEventNb repeats.

## Pass / fail criterion
FAIL if a recorded event disappears or is overwritten after a reset.

## Evidence to collect
- Both DIDs before/after the reset; DTCs; supply trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on EcuM/BswM/NvM WriteAll behaviour on every reset path (not in the tree). If WriteAll always runs, not a bug.
