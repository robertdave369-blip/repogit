# M210-EDR-29: 500 us sensor DIDs: the sample at byte 20 may be T0 + 0.5 ms instead of T0 (one-sample shift)

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence (pre-buffer captured before event detection in the T0 cycle); length 521 bytes confirmed against V3.4. |
| Related | Reviewer finding SNS-03 (length part withdrawn: V3.4 defines 521 bytes) |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Bytes 0-19 are the 20 newest of a 21-slot pre ring; post samples start at byte 20 from the cycle after T0. If the T0 sample lands in the pre ring (it is captured before the event is detected), byte 19 is T0 and byte 20 is T0 + 0.5 ms, i.e. the whole timeline is one sample earlier than labelled.

## Expected behaviour (requirement source)
- V3.4 EDR Sensor Data r49 'Sensor Data at -10ms' byte 0 ... r69 'at 0ms' byte 20 ... 250 ms byte 520.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:23545-23615 RstEdr_ReportSensorsDataMah / rstedr_FormatSensorDataPreTime ('skip the oldest pre event sample')
- RstEdr/Implementation/Source/RstEdr.c:2936-2947 pre capture before event detection in the T0 cycle (reviewer)

## Actual / suspected behaviour
A step applied at a known instant appears at byte 19 instead of byte 20.

**Observable at:** Sensor DIDs 0x045F (central lateral, record 1), 0x0460 (central longitudinal) and the RSU DIDs

## Test set-up
- Common set-up; a curve with a sharp step whose onset defines T0 (step larger than the T0 threshold).

## Preconditions
- Standard preconditions.

## Input signals
- Hard step on central X at a known sample.

## Triggering conditions
Any recorded event.

## Execution steps
1. Run the step curve; read 0x0460; find the first byte that shows the step.

## Expected results
- Step first visible at byte 20 (0 ms) or as the T0 definition implies.

## Actual / suspected results
- Step first visible at byte 19.

## Pass / fail criterion
Decide with the customer which sample is 'T0'.

## Evidence to collect
- Sensor DID; curve file.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on processing latency outside RstEdr.
