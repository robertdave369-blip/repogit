# M210-EDR-19: 1-bit multi-sample elements are OR-ed into the DID buffer without clearing it first

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | EDR CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (packers use |= without a prior assignment; dispatcher passes the caller's buffer). |
| Related | Reviewer finding CAN-08 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
STS_HIGHBEAM, STS_LOWBEAM, STS_ABS, STS_EBD, STS_TCS, VCU_IGN_STS, LKA, RCW, STS_CRASH, PIB_ACTIVE and ECALL_PWM_ACK packers only OR bits into Dst[]. If DiagMgr pre-fills the buffer (e.g. FF) or reuses it, zero samples read as 1.

## Expected behaviour (requirement source)
- V3.4 bit definitions for bytes 658, 756, 800, 801, 816, 817, 820, 827, 858-860, 866-869: 0 for a 0 sample.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:14077 (STS_LOWBEAM) `Dst[buffer_idx] |= ...` with no prior `Dst[buffer_idx] = 0`; same at 13915, 14549, 14711, 15043, 15372, 11568, 13431, 16635, 16964, 17130
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17590-17638 RstEdr_CopyGetAdditionalDataElement passes DstPtr through unchanged

## Actual / suspected behaviour
With all signals 0 and a near crash, these bytes may read non-zero (e.g. STS_CRASH bits set without a crash command).

**Observable at:** Bytes 658, 756, 800, 801, 816, 817, 820, 827, 858-860, 866-869

## Test set-up
- Common set-up.

## Preconditions
- Standard preconditions.

## Input signals
- All listed signals = 0; no deployment (near crash).

## Triggering conditions
Read-out of any record.

## Execution steps
1. Trigger a near crash with all listed signals at 0; read 0x0455 and then 0x045B.
2. Make record 2 differ (different values) and read 0x045B, then 0x0455, then 0x045B again.

## Expected results
- All listed bytes 0x00 (reserved bits 0) for a 0 input; repeated reads identical.

## Actual / suspected results
- Bits set where the input was 0, or bits carried from a previous read.

## Pass / fail criterion
FAIL if any bit is set for a 0 input or a read depends on the previous read.

## Evidence to collect
- Raw DID responses in read order.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on DiagMgr buffer handling (not in the tree); supplier bench tests used only value 1 for these elements, which cannot reveal it.
