# M210-EDR-16: If the record is written before the first post-T0 tick (battery cut-off), the '0 s' sample is overwritten with the not-captured value

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | EDR CAN-C recording / power loss |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (unsigned index arithmetic in the post-T0 formatters). |
| Related | Reviewer finding CAN-05 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Post-T0 formatters compute `u8DestMaxNb = N_pre + (index - 1U)`. With the post index still 0 the result is N_pre - 1, and the padding loop then overwrites the '0 s' slot. For vehicle speed this replaces the exact T0 value (written just before) with 0x7FFF.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r10 / r53-r57: in a battery cut-off crash the data up to 200 ms are valid (200 ms CompletionStatus); the T0 values must be kept.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5356 `VehSpdLgt_data[10] = ...VehSpdLgtAtTimeZero;`
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5459 `u8DestMaxNb = RSTEDR_NOF_SAMPLES_5SEC_TO_0SEC_2PERSEC + (pEventDataReadBuffer->u8Index0sTo3s2PerSec - 1U);` (index 0 -> 10); padding loop from index 10 (same pattern in about 60 formatters)
- RstEdr/Implementation/Source/RstEdr.c:3090-3095 power-down forces end of event; RstEdr/Implementation/Source/RstEdr.c:1350-1385 record written immediately

## Actual / suspected behaviour
Battery cut within one tick period after T0: VehSpd '0 s' (bytes 50-51) = 0x7FFF while VehSpd at T0 (bytes 4-5) is correct; Gear '0 s' = 0; other '0 s' slots = their not-captured value.

**Observable at:** Bytes 4-5 vs 50-51 (vehicle speed); 349 low nibble (Gear); byte 216 bit 6

## Test set-up
- Common set-up; supply switchable off at a defined time relative to the trigger (ECU then runs on energy reserve).

## Preconditions
- Standard preconditions.

## Input signals
- VEHICLE_SPEED 50 km/h (0x0C80) constant; Gear = 1.

## Triggering conditions
Supply off at T0 (+ 0..50 ms) during a deployment crash.

## Execution steps
1. load_crash_curves(`front`); set the signals; wait 5 s.
2. TriggerCrash() and switch the supply off 20 ms later.
3. Restore the supply after 10 s; read 0x0455.
4. Repeat 5 times with the cut at 20, 100, 200, 300 and 600 ms after T0.

## Expected results
- Bytes 50-51 = 0x0C80 (same as bytes 4-5) in every run; Gear '0 s' = 1.

## Actual / suspected results
- In runs where the record was written before the first post tick: bytes 50-51 = 0x7FFF; Gear '0 s' = 0.

## Pass / fail criterion
FAIL if a '0 s' slot loses its value when the record is written early.

## Evidence to collect
- Supply trace with the cut instant; DID response; byte 216.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Depends on when SysModMgr calls RstEdr_PowerDown after the supply loss (not in the tree).
