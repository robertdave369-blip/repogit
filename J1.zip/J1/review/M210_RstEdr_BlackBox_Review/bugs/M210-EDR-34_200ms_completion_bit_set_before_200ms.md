# M210-EDR-34: '200 ms CompletionStatus' is set at end of event + 30 ms, i.e. before 200 ms for short events

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | Other EDR (completion status, battery cut-off) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (delay initialisation 400 ticks, reassessment to Tend + 60 ticks, report bit 6). |
| Related | Reviewer finding EVT-04 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The bit reported as '200 ms CompletionStatus' is the OTHER-data completion flag. Its delay starts at 400 ticks (200 ms) but is reduced at end of event to Tend + 60 ticks (30 ms). For an event ending before 170 ms the bit is set before 200 ms of data exist.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r10: '200ms CompletionStatus will be updated as 1 after 200 mseconds. If this bit is set the data for 200ms from T0 is valid.'; r53-r55 (battery cut-off crash).
- V3.4 r202: byte 216 bit 6.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:2328 OTHER delay = 400 ticks (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:217-219); RstEdr/Implementation/Source/RstEdr.c:2893 + RstEdr/Implementation/Source/RstEdr.c:2786-2812 reassessed to min(400, Tend + 60)
- RstEdr/Implementation/Source/RstEdr.c:2180-2184 flag set when time > delay; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6814 bit 6 = OTHER_COMPLETE << 3

## Actual / suspected behaviour
Short near crash (Tend 60 ms) with battery cut at T0 + 150 ms: byte 216 = 0x40 although capture stopped at 150 ms.

**Observable at:** Byte 216 bit 6 (V3.4)

## Test set-up
- Common set-up; supply cut at a defined time after the trigger.

## Preconditions
- Standard preconditions.

## Input signals
- Short near-crash curve (event ends < 100 ms).

## Triggering conditions
Supply cut between Tend + 30 ms and T0 + 200 ms.

## Execution steps
1. Trigger the short near crash; cut the supply at T0 + 120 ms; restore after 10 s; read 0x0455.
2. Repeat with a frontal curve and cuts at 199 ms and 201 ms.

## Expected results
- Bit 6 = 0 for a cut before 200 ms; 1 for a cut after 200 ms.

## Actual / suspected results
- Bit 6 = 1 for the cut at 120 ms on the short event.

## Pass / fail criterion
FAIL if bit 6 is 1 while less than 200 ms of data were captured.

## Evidence to collect
- Supply trace; DID.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Part 563 treats Tend + 30 ms as complete; the customer's wording asks for 200 ms. Also needs RstEdr_PowerDown on the cut.
