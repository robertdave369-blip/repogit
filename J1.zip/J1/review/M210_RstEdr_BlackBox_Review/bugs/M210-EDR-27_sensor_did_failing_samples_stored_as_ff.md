# M210-EDR-27: 500 us sensor DIDs store 0xFF for samples with Qf 'Failing', while delta-V uses the same samples

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Low |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read. |
| Related | Reviewer finding SNS-06 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
rstedr_CaptureSensorData converts only Qf == Valid samples; Failing (data kept by OpsSgPoolMgr while a status flag matures) becomes 0xFF. Delta-V and the IMU elements accept Failing.

## Expected behaviour (requirement source)
- V3.4 EDR Sensor Data: no rule for degraded samples; '0xFF shall be stored default' only for NA channels.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:2318-2327 `if(sensor_port.Qf == QfAlv1_Valid) ... else *output_ptr = RSTEDR_DATA_NOT_CAPTURED;`
- OpsSgPoolMgr/Implementation/Source/OpsSgPoolMgr.c:1249-1250 Failing keeps the real data

## Actual / suspected behaviour
Isolated 0xFF holes in the crash part of the sensor DIDs when a non-fatal sensor flag is present.

**Observable at:** Sensor DIDs 0x045F-0x04A1 (521 data bytes each)

## Test set-up
- Common set-up; ARIA RSU simulation able to set a non-fatal status flag on single RSU frames during a crash.

## Preconditions
- Standard preconditions.

## Input signals
- Side crash curve; flagged frame every 10 ms on one RSU during 0..100 ms after T0.

## Triggering conditions
Qf Failing samples inside the capture window.

## Execution steps
1. Run the side crash with the flagged frames; read the sensor DID of that RSU and 0x0455.

## Expected results
- Customer to define; at minimum consistent with delta-V treatment.

## Actual / suspected results
- 0xFF at the flagged instants.

## Pass / fail criterion
Report; ask for the rule.

## Evidence to collect
- Sensor DID; RSU frame log.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Storing 0xFF for doubtful samples may be the intended conservative choice.
