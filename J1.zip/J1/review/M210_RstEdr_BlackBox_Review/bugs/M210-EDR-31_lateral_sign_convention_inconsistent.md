# M210-EDR-31: Lateral sign convention differs between delta-V (inverted) and lateral acceleration data (not inverted)

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (Mahindra delta-V conversion). |
| Related | Reviewer finding SNS-09 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Lateral delta-V and max delta-V are negated for non-longitudinal IDs; lateral acceleration bytes and IMU lateral acceleration are not.

## Expected behaviour (requirement source)
- No customer sign convention in the sources; framework rule: onboard data on the AUTOSAR axis (left Y-, right Y+).

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17829-17836 `temp_calc_offset_value = (uint8)((uint32)(-tmp_calc_deltav) ...)` for lateral IDs

## Actual / suspected behaviour
A left side impact gives positive DeltaVLat but negative lateral acceleration in the same record.

**Observable at:** Bytes 245-270 vs sensor DID 0x045F / IMU lateral acceleration

## Test set-up
- Common set-up; `left` crash curve.

## Preconditions
- Standard preconditions.

## Input signals
- -

## Triggering conditions
Any side impact.

## Execution steps
1. Run `left`; read 0x0455 and 0x045F; compare signs.

## Expected results
- Signs consistent with the customer convention.

## Actual / suspected results
- Opposite signs.

## Pass / fail criterion
Ask the customer for the convention.

## Evidence to collect
- Both DIDs.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- May be intended per element.
