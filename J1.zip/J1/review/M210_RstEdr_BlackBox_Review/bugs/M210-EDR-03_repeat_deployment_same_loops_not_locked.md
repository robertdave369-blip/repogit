# M210-EDR-03: A deployment that re-fires loops already fired in the same reset cycle is not locked

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | Medium |
| Area | EDR Multi-Event / record locking |
| Build variant | APPRISE and VTA |
| Verification | Code re-read; SW requirements AAUR_SW_RstEdr_239/240/241 read. |
| Related | Reviewer finding EVT-13 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Priority and lock are taken only when a loop is requested for the first time in the reset cycle. A second deployment event in the same ignition cycle that requests the same loops (e.g. two frontal crashes) gets no lock and, unless it exceeds the DV150 threshold, no record.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r20 / r39: '1: deployment event' and the multi-event table row 49 (1,1,1 < 5 s): both records locked (lock status 1 / 1).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:3797-3805 lock/priority only if `0U == (u32EventLoopsDeployedTab & mask)`; RstEdr/Implementation/Source/RstEdr.c:1001 table cleared only in Init
- RstEdr SW requirements AAUR_SW_RstEdr_239 / 240 / 241 (/item/4323111, 4322772, 4322921): 'for the first time in a Reset_Cycle'

## Actual / suspected behaviour
Second event: byte 22 bit 7 = 0 (unlocked); may be overwritten by later near crashes; if DV150 < 8 km/h no record at all.

**Observable at:** DID 0x0455 / 0x045B byte 22 (bit 7 lock), deployment time words 165-212

## Test set-up
- Common set-up.
- Crash set `multi_crash_boundary_front_front_800ms` or `_4999ms` (two identical frontal deployments); squib loads must allow a second firing (bench resistors).

## Preconditions
- Standard preconditions; no ignition cycle between the two crashes.

## Input signals
- All Rx frames valid; vehicle speed 50 km/h.

## Triggering conditions
Two deployments of the same loops within one reset cycle.

## Execution steps
1. load_crash_curves(`boundary_front_front_4999ms`); wait 5 s.
2. TriggerCrash(); wait 15 s.
3. Read 0x0455 and 0x045B and $19 02.
4. Repeat with an ignition cycle (power cycle) between two single front crashes: both records must then be locked.

## Expected results
- Both records byte 22 = 0x81 (front, locked).

## Actual / suspected results
- Second record byte 22 = 0x01 (front, unlocked) or no second record; the power-cycled variant gives two locked records.

## Pass / fail criterion
FAIL against the customer table if the second deployment record is not locked.

## Evidence to collect
- Both DID responses; squib firing log (both events must fire); CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The behaviour follows the RstEdr SW requirement, so this is a conflict between the SW requirement and the customer's expectation, not a coding slip. In a vehicle, already-deployed airbags cannot fire again, but pretensioner / other loops and bench tests can.
