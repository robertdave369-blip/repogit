# M210-EDR-01: Multi-event near crash -> deployment -> near crash: Event 3 is not recorded

| | |
|---|---|
| Classification | **Confirmed** |
| Confidence | High |
| Area | EDR Multi-Event |
| Build variant | APPRISE and VTA (common code) |
| Verification | Code re-read in the main review (priority raise, slot search, bit values, overwrite strategy). |
| Related | Reviewer finding EVT-01 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
When a deployment event is the second event of a multi-event (< 5 s T0 to T0), the code raises the previous near-crash event from priority level 7 to level 6 and stores that raise persistently. A later near crash (level 7) may only replace empty or level-7 slots, so it finds no slot and is discarded. The customer table requires Event 3 to replace Event 1 in EDR1.

## Expected behaviour (requirement source)
- Customer EDR_Requirements (V3.4 = V2.7), multi-event table row 44 (Event1 = 0, Event2 = 1, Event3 = 0, all < 5 s): at the end of Event 3, EDR1 = Event 3 (Multi Event Number 3, Lifetime 3, not locked) and EDR2 = Event 2 (Multi Event Number 2, Lifetime 2, locked).
- Multi-event spec Oracles (multievent__Oracles r27): an unlocked record is replaced by the next event.
- No RstEdr SW requirement asks for a level-6 raise of a preceding event.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:63 `#define AB_DEPLOYMENT_EVENT_PRIO_LEV RSTEDR_EVENT_PRIO_LEV1`
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1973-1974 raise only when current priority == LEV1 and MultiEventNumber != 1
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1986-1991 previous event LEV7 -> LEV6 (LEV3 -> LEV2); written to rstedr_InternalData (:2003), to RstEdr_GlobalEventInfo (persistent synthesis, :2009) or to the capture buffer (:2015)
- RstEdr/Implementation/Source/RstEdr.c:2531 lifetime counter incremented before the slot search; RstEdr/Implementation/Source/RstEdr.c:2539 raise; RstEdr/Implementation/Source/RstEdr.c:2541 search; RstEdr/Implementation/Source/RstEdr.c:2542-2546 no slot -> event dropped
- RstEdr/Implementation/Source/RstEdr.c:3458-3499 rstedr_SearchEvent: search limit = 1 + bit position of the event level; LEV7 = 0x01 (PRIO7_IDX 0, EnsMgr/Implementation/Cfg/Rte_EnsMgr_Type.h:509) -> only EMPTY and LEV7 slots are searched; RstEdr/Implementation/Source/RstEdr.c:3404 exact compare, so a 0x02 (LEV6) slot never matches
- RstEdr/Implementation/Cfg/RstEdr_PBCfg.h:64 u8EventOverwriteStrategy 0x00 = RSTEDR_OVERWRITE

## Actual / suspected behaviour
After Event 3 both DIDs still show Event 1 (EDR1) and Event 2 (EDR2). Event 3 is lost although its lifetime number was consumed, so the next recorded event skips a lifetime number. Because the raise is persistent, every later near crash (even > 5 s later, in later ignition cycles) is also discarded until a deployment overwrites EDR1.

**Observable at:** DID 0x0455 / 0x045B bytes 0-3 (LifeTimeEventNb), 21 (MultiEventNumber), 22 (crash type / near / lock), 217-218 (TimeBtwEvents)

## Test set-up
- Common set-up.
- Crash set `multi_crash_multi_near_left_near` (three events, 2000 ms apart: near crash, left deployment, near crash; crash_data/multi_event). If it is not available, play `near`, then `left`, then `near` with 2 s T0 spacing.
- Vehicle speed on IEB1_FD_10 different for each event (e.g. 40, 60, 80 km/h) so each record can be identified.

## Preconditions
- Standard preconditions; both DIDs read all FF.
- The `near` curve must exceed the record threshold (DV150 > 8 km/h, PBCfg u32DVXTrigThreshold 0x714E) so that a single near crash alone produces a record. Confirm with a separate single near-crash run first.

## Input signals
- VEHICLE_SPEED (IEB1_FD_10): 40 km/h before Event 1, 60 km/h before Event 2, 80 km/h before Event 3 (change each value at least 1 s before the next T0).
- All other Rx frames valid; supply 12 V.

## Triggering conditions
Three events with T0-to-T0 spacing < 5 s: near crash (not locked), deployment (locked), near crash.

## Execution steps
1. Run the single near-crash pre-check, read 0x0455, confirm a record exists (byte 22 = 0x40), then fault_free_profile().
2. load_crash_curves(`multi_near_left_near`), set VEHICLE_SPEED 40 km/h, wait 5 s.
3. TriggerCrash(); change VEHICLE_SPEED to 60 km/h 0.5 s after T0 of Event 1 and to 80 km/h 0.5 s after T0 of Event 2.
4. Wait at least 10 s after the last T0 (records complete at T0 + 5.1 s).
5. Read $22 04 55 and $22 04 5B; read $19 02.
6. Optional persistence check: run one more single near crash > 10 s later (same ignition cycle), read both DIDs again.

## Expected results
- EDR1 (0x0455): Event 3: LifeTimeEventNb 3, MultiEventNumber 3, byte 22 = 0x40 (near crash, unlocked), TimeBtwEvents about 2000 ms (0x0FA0 in 0.5 ms units), VehSpd at T0 = 80 km/h.
- EDR2 (0x045B): Event 2: LifeTimeEventNb 2, MultiEventNumber 2, byte 22 = 0x82 (left, locked), VehSpd 60 km/h.
- Persistence check: the 4th event replaces the oldest unlocked record (Event 3 slot).

## Actual / suspected results
- EDR1 still holds Event 1: LifeTimeEventNb 1, MultiEventNumber 1, TimeBtwEvents 0xFFFF, VehSpd 40 km/h.
- EDR2 holds Event 2 as expected.
- Persistence check: the 4th near crash is not recorded either; when a later event is recorded its LifeTimeEventNb skips the lost numbers.

## Pass / fail criterion
FAIL if EDR1 does not contain Event 3 after the sequence (VehSpd 80 km/h, MEN 3).

## Evidence to collect
- Both DID responses after each event (read at T0 + 10 s of each event in a second run).
- CAN trace incl. SRS1_FD_10 STS_CRASH / NEAR_CRASH.
- ARIA trigger instants and squib firing log (only Event 2 must fire).
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The raise looks like a deliberate scheme to protect the event that led into a deployment; it was never reconciled with the customer's multi-event table. Decide with the customer which behaviour is wanted.
- Single events > 5 s apart are not affected (no raise when MultiEventNumber = 1).
