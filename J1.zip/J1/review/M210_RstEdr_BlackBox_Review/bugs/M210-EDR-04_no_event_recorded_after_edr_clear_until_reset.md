# M210-EDR-04: After an EDR clear (NvM data reset) no event is recorded until the next ECU reset

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | High |
| Area | Other EDR (record management) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (NvM data reset state machine). |
| Related | Reviewer finding EVT-07 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
A successful EDR clear sets 'event detection suspended while NvM data reset' and 'locked after NvM data reset' and never clears them. Only a new RstEdr_Init (reset) re-enables event detection.

## Expected behaviour (requirement source)
- RstEdr SW requirements (rstedr_requirements: 'for the remaining of the Reset_Cycle') define this as intended; no customer requirement states it. Test procedures that clear the EDR and crash in the same power cycle are affected.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:19951-19953 `bRstEdrLockedAfterNvMDataReset = TRUE`, `u8EventWakeUpSuspended |= ..._WHILE_NVM_DATA_RESET`
- RstEdr/Implementation/Source/RstEdr.c:20056-20061 cleared only when the synthesis invalidation fails; never on success
- RstEdr/Implementation/Source/RstEdr.c:2938-2940 T0 gate requires no suspension

## Actual / suspected behaviour
A crash after the clear, before any reset, leaves both DIDs at FF and creates no record.

**Observable at:** DID 0x0455 / 0x045B (all FF after the crash)

## Test set-up
- Common set-up; the EDR clear service used by the project (DiagMgr routine that calls RstEdr_ResetNvmData).

## Preconditions
- One record present (run a near crash first).

## Input signals
- All Rx frames valid.

## Triggering conditions
Crash in the same reset cycle as the EDR clear.

## Execution steps
1. Run a near crash; read 0x0455 (record present).
2. Send the EDR clear request; poll until it reports complete.
3. Without any power cycle: TriggerCrash() with a frontal curve already loaded (load the curve before the clear, because load_crash_curves power-cycles the ECU).
4. Wait 10 s, read both DIDs.
5. Power-cycle, run the same crash again, read both DIDs.

## Expected results
- Customer expectation (if the clear is meant to make the ECU ready): the crash after the clear is recorded.

## Actual / suspected results
- Both DIDs FF after the first crash; recorded normally after the power cycle.

## Pass / fail criterion
Document the behaviour; FAIL only if the customer requires recording in the same cycle.

## Evidence to collect
- Clear request/response, both DID responses, $19 02, CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Deliberate design (protects the cleared NvM). Make sure bench procedures always power-cycle after a clear.
