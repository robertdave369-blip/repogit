# M210-EDR-05: A crash during an EDR read-out ($22 0455/045B in progress) is not recorded or gets a late T0

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | Other EDR (record management) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (read-out state machine, T0 gate). |
| Related | Reviewer finding EVT-06 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
When a read-out starts, RstEdr suspends event detection until DiagMgr reports the conversion finished, or for at most 32 s (64000 x 0.5 ms). A crash in that window is ignored while the suspension lasts.

## Expected behaviour (requirement source)
- No customer or RstEdr requirement allows ignoring a crash during a diagnostic read (the SW requirement only rejects read requests during capture).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:7328 `u8EventWakeUpSuspended |= RSTEDR_EVENT_DETECT_SUSPEND_WHILE_READ`
- RstEdr/Implementation/Source/RstEdr.c:7480-7536 cleared at conversion end or after RSTEDR_DIAGNOSTIC_TIME_LIMIT (64000U, RstEdr_Intl.h:103 '32 seconds')
- RstEdr/Implementation/Source/RstEdr.c:2938-2940 T0 only if no suspension

## Actual / suspected behaviour
The crash is lost, or captured late (T0 when the suspension ends, while the algorithm is still active).

**Observable at:** DID 0x0455 / 0x045B after the crash; NEAR_CRASH/STS_CRASH on CAN still behave normally

## Test set-up
- Common set-up; a script that sends $22 04 55 back-to-back (every 50 ms) while a crash curve plays.

## Preconditions
- One record present so that reads return data (a read of an empty slot may not start the NvM read).

## Input signals
- Frontal curve loaded; vehicle speed 50 km/h.

## Triggering conditions
TriggerCrash() while a $22 04 55 transfer is in progress.

## Execution steps
1. Create a near-crash record; power cycle (load_crash_curves(`front`)).
2. Start the $22 04 55 loop.
3. TriggerCrash() during the loop; stop the loop 1 s later.
4. Wait 15 s; read both DIDs and $19 02.

## Expected results
- A new locked frontal record exists with correct T0 data (VehSpd at T0 = 50 km/h, deployment times ~ the fired loops).

## Actual / suspected results
- No new record, or a record whose deployment times / delta-V start late (T0 shifted).

## Pass / fail criterion
FAIL if the crash is not recorded or its time base is shifted.

## Evidence to collect
- Timestamps of every $22 request/response vs the trigger instant; both DIDs; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The window may be very short if DiagMgr converts quickly (DiagMgr not in the tree); repeat the test 10 times.
