# M210-EDR-18: Occupant / e-call counts, seat position zone and OCS class at T0 are hard-coded FF although SRS1_FD_10 transmits them

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | High (code) |
| Area | EDR CAN-C recording / ECU Tx signals |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (report functions write constants). |
| Related | Reviewer findings TX-07, CAN-11 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The report functions for OCS passenger classification (byte 853), seat position zone (854), occupant/e-call counts (856-857) write 0xFF; the SRS operation-mode byte (855) keeps bit 0 only. The ECU itself transmits SRS_OCC_ODS_ADULT, SRS_BKL_CNT, SRS_ECALL_OCC_CNT, SRS_ECALL_OCC_BKL_CNT and STPS zones on SRS1_FD_10.

## Expected behaviour (requirement source)
- V3.4 r984 (853), r985 (854), r987-r990 (855), r991-r994 (856-857, ranges 0..7) 'at T0'.
- Customer EDR_Requirements r5: FF only when no event is recorded.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16451-16458 rstedr_ReportOCSPassengerTypeClassification -> 0xFF
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16493-16497 rstedr_ReportSeatPositionZone -> 0xFF
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16578-16586 rstedr_ReportEcallCNT -> 0xFF 0xFF
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16532-16546 SRS operation-mode byte: bit 0 only (DOMS, 1st crash type, OCS sub-seat bits always 0)

## Actual / suspected behaviour
In every recorded event: 853 = FF, 854 = FF, 856-857 = FF FF (4-bit fields 0xF, outside 0..7).

**Observable at:** Bytes 853-857 vs SRS1_FD_10 at T0

## Test set-up
- Common set-up; DCS buckle loads and ODS/STPS simulation as configured for M210 (dcs_config, ods_config, stps_config).

## Preconditions
- Standard preconditions.

## Input signals
- Driver and passenger buckled, passenger ODS occupied, STPS zone as configured.

## Triggering conditions
Any recorded event.

## Execution steps
1. Set the occupant inputs; check SRS1_FD_10 shows non-default SRS_BKL_CNT / SRS_OCC_ODS_ADULT / zones.
2. Trigger a near crash; read 0x0455; compare bytes 853-857 with the SRS1_FD_10 values at T0.

## Expected results
- Bytes 856-857 carry the same counts as SRS1_FD_10 at T0; 854 the seat zone.

## Actual / suspected results
- 853 = FF, 854 = FF, 856 = FF, 857 = FF.

## Pass / fail criterion
FAIL against V3.4 unless the customer confirms these elements are not applicable to M210.

## Evidence to collect
- SRS1_FD_10 trace around T0; DID response.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The code comments say 'not applicable for the project'; M210 STPS/OCS fitment is not confirmed (framework stps_config holds M314 values). Get the customer decision.
