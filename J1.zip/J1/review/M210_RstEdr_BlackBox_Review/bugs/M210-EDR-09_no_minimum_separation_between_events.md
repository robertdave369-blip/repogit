# M210-EDR-09: Two impacts closer than 500 ms are split into two records as soon as the first event ends

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | EDR Multi-Event |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence; end-of-event and T0 paths re-read. |
| Related | Reviewer finding EVT-10 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The end of an event is decided only by algorithm activity and the 20 ms delta-V criterion; a new T0 can start immediately after. There is no lower bound (the customer table is headed 'time between events > 500 ms').

## Expected behaviour (requirement source)
- Customer EDR_Requirements r32 'Multi Event Scenarios (time between events > 500 ms)'; behaviour for <= 500 ms is not written (multi-event open points AMB-01/06/07/13).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:3087-3095 end of event from activity; RstEdr/Implementation/Source/RstEdr.c:2938-2951 next T0; RstEdr/Implementation/Source/RstEdr.c:4357 only the 5 s upper bound

## Actual / suspected behaviour
Near crash + deployment 300-500 ms later gives two records (near crash unlocked and raised, deployment locked, MEN 2).

**Observable at:** Bytes 0-3, 21, 22, 217-218 of both records

## Test set-up
- Common set-up; `concatenated_near_front` (400 ms) and `boundary_front_front_500ms` / `_501ms`.

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Second T0 within 500 ms of the first.

## Execution steps
1. Run each set; read both DIDs after 15 s.

## Expected results
- To be defined by the customer (one record vs two records).

## Actual / suspected results
- Two records with MEN 1 / 2 and TimeBtwEvents < 500 ms.

## Pass / fail criterion
Report the observed allocation and ask the customer to define the rule.

## Evidence to collect
- Both DIDs; ARIA timing; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Part 563 splits events on end of event, so the ECU may be right; the customer must decide.
