# M210-EDR-26: A loop fired in the T0 cycle (time stamp 0) is reported 'not deployed' in the deployment-status bits

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium (code), Low (trigger) |
| Area | Sensor / deployment recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (status report condition, time-table init). |
| Related | Reviewer finding SNS-02 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Deployment stamps are taken in the T0 cycle with the timer at 0; the status report treats 0 as 'previously deployed' and leaves the bit at 0, although nothing ever writes 0 for 'previously deployed'.

## Expected behaviour (requirement source)
- V3.4 r177 '... Deployment Status' ENUM DEPLOY_NOT (1 = deployed), bytes 213-215; consistent with the time word.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:7875 `if ((deployment_time != 0U) && (deployment_time != RSTEDR_U16_INTERNAL_NOT_DEPLOYED))`
- RstEdr/Implementation/Source/RstEdr.c:2278-2283 times initialised to 0xFFFF ('0 can be a valid one'); RstEdr/Implementation/Source/RstEdr.c:4481-4482 stamps taken at T0

## Actual / suspected behaviour
Time word 0x0000 with status bit 0 for the same loop.

**Observable at:** Bytes 165-212 vs 213-215

## Test set-up
- Common set-up; two-pulse curve: first pulse below deployment that ends its event, second pulse > 100 ms later that fires immediately.

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
A deployment command in the same 0.5 ms cycle that opens the event.

## Execution steps
1. Run the two-pulse curve; read 0x0455; look for a 0x0000 time word.
2. Repeat several times (timing dependent).

## Expected results
- Any loop with a time word other than 0xFFFF has its status bit set.

## Actual / suspected results
- Time 0x0000, status bit 0.

## Pass / fail criterion
FAIL if time and status disagree.

## Evidence to collect
- DID; squib log.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- May be unreachable if the algorithm always opens the event earlier than the deployment manager.
