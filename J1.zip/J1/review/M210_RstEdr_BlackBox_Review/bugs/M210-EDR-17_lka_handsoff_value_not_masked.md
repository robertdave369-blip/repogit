# M210-EDR-17: LKA_HANDSOFF_DISPLAY_WARNING samples are not masked to 1 bit; raw 2 or 3 corrupts neighbouring samples

| | |
|---|---|
| Classification | **Potential** |
| Confidence | High (code), Medium (trigger) |
| Area | EDR CAN-C recording / OnFail-on-CAN (reserved values) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read. |
| Related | Reviewer finding CAN-07 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Every other 1-bit packer masks with RSTEDR_1BIT_MASKING and clears the reserved low bits; the LKA_HANDSOFF packer shifts the raw value in unmasked. The DBC signal is 2 bits wide.

## Expected behaviour (requirement source)
- V3.4 r629-r634: one bit per sample, 6 samples in byte 658 bits 7..2; reserved/out-of-range values: consume (on-fail matrix) - in any case the neighbouring samples must not change.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:11568 `Dst[buffer_idx] |= (uint8)((uint32) lkaHandsoffDispWarn_data[data_idx] << shift_bit_idx);` (no mask, no `&= 0xFC`)
- Compare RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:13915 / 13920 (STS_HIGHBEAM: masked, reserved bits cleared)

## Actual / suspected behaviour
Raw 2 in every sample -> byte 658 = 0xF8 (false 'warning' bits, shifted by one); raw 3 -> 0xFC.

**Observable at:** Byte 658 (V3.4)

## Test set-up
- Common set-up.

## Preconditions
- Standard preconditions.

## Input signals
- HPCAd_3_50 LKA_HANDSOFF_DISPLAY_WARNING = 2 (reserved raw value) held for 10 s before and after the crash.
- Second run: value 0 everywhere except raw 2 during the 1 s window around the -1 s sample.

## Triggering conditions
Any recorded event with the signal at raw 2 or 3.

## Execution steps
1. Set the signal; trigger a near crash; read 0x0455 after 10 s; decode byte 658.
2. Repeat with raw 3 and with the single-window variant.

## Expected results
- No sample bit set by a neighbouring sample; reserved bits 1..0 = 0.

## Actual / suspected results
- Raw 2: byte 658 = 0xF8; single-window variant: the bit appears one slot earlier than labelled.

## Pass / fail criterion
FAIL if any bit of byte 658 does not correspond to its own sample.

## Evidence to collect
- DID response; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The framework's scripts_simple series 35 (LKA_HANDSOFF_DISPLAY_WARNING) Reserved case drives exactly this input.
- RCW_WARN uses the same unmasked pattern (RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:13431) but is 1 bit in the DBC.
