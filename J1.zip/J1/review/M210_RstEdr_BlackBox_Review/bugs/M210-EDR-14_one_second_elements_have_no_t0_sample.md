# M210-EDR-14: 1-per-second CAN-C elements never get a T0 sample, so '0 s' can be up to 1 s old

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | EDR CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (T0 capture covers only the 500 ms and 250 ms groups). |
| Related | Reviewer finding CAN-03; see also M210-EDR-13 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
At T0 the 500 ms and 250 ms groups get an extra sample if their last tick is old enough; the 1 s group never does. Its '0 s' value is the last 1 s tick before T0.

## Expected behaviour (requirement source)
- V3.4 r318 'Gear at 0 S' (byte 349 bits 3..0), r867 'STS_HIGHBEAM at 0 S' etc.: the value at T0.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1691-1708 rstedr_GetTimeZeroAdditionalData refreshes only 500 ms and 250 ms groups
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3554-3690 rstedr_Capture1sPreEventAdditionalData (1 s tick only); snapshot values from the same capture

## Actual / suspected behaviour
A change in the last second before the crash is missed with probability d / 1 s.

**Observable at:** Gear byte 349 low nibble; STS_HIGHBEAM byte 800 bit 4; snapshot elements sourced from the 1 s capture

## Test set-up
- Common set-up.

## Preconditions
- Standard preconditions.

## Input signals
- GEAR_ACTUAL = 1 (Forward) held; switched to 2 (Reverse) 300 ms before the trigger.

## Triggering conditions
Signal change less than 1 s before T0.

## Execution steps
1. Hold Gear = 1 for 10 s.
2. Change Gear to 2; trigger the crash 300 ms later.
3. Read 0x0455 after 10 s; decode byte 349 low nibble.
4. Repeat 10 times (fault_free_profile between runs).

## Expected results
- 'Gear at 0 S' = 2 in every run.

## Actual / suspected results
- 'Gear at 0 S' = 1 in about 70 % of runs.

## Pass / fail criterion
FAIL if the T0 value is older than the most recent CAN value in a significant share of runs.

## Evidence to collect
- CAN trace with Tx time of the change; trigger time; DID responses.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- One-period jitter is common practice for 1 Hz data, but the 500 ms / 250 ms groups are refreshed at T0 and this group is not.
