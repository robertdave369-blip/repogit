# M210-EDR-32: Sensor-DID report ignores the requested record and has no read-request guard

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Sensor recording / read-out |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (unused RequestedEventID parameter). |
| Related | Reviewer finding SNS-10 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
RstEdr_ReportSensorsDataMah never uses RequestedEventID and reads whatever buffer the last RstEdr_RequestEdrDataRead loaded; the Mahindra element dispatcher checks the requested record, this one does not.

## Expected behaviour (requirement source)
- Record-1 and record-2 sensor DIDs (e.g. 0x045F / 0x0467) return their own record.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:23545-23568 RequestedEventID unused; reads u8ReadEventBufferIndex
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17609 the additional-element dispatcher checks `cRequestedEventId == RecordRequestedToRead`

## Actual / suspected behaviour
Reading 0x0467 right after 0x045F without a record-2 read returns record 1's data (or a reused buffer).

**Observable at:** 0x0467 vs 0x045F contents

## Test set-up
- Common set-up; two records with clearly different lateral pulses.

## Preconditions
- Two records.

## Input signals
- -

## Triggering conditions
Sensor-DID reads in different orders.

## Execution steps
1. Read 0x045F, 0x0467, 0x045F; then 0x0455, 0x045F, 0x045B, 0x0467; compare.

## Expected results
- Each DID returns its own record regardless of order.

## Actual / suspected results
- 0x0467 identical to 0x045F in some orders.

## Pass / fail criterion
FAIL if a DID's content depends on the previous read.

## Evidence to collect
- All responses in order.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- DiagMgr probably requests the read for each DID; the supplier bench passed.
