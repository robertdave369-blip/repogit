# M210-EDR-02: ADAS 4-per-second pre-crash series (-3 s..0 s) recorded as 0 when T0 follows a previous end of event by < 3.25 s

| | |
|---|---|
| Classification | **Confirmed** |
| Confidence | High |
| Area | EDR CAN-C recording / Multi-Event |
| Build variant | APPRISE and VTA |
| Verification | Code re-read in the main review (pre-event buffers, hand-over at end of event, report padding). |
| Related | Reviewer findings EVT-02 and CAN-01 (same defect, found independently); sibling of the 8D 'EDR report index issue' |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The 13 ADAS elements sampled every 250 ms are captured only into the active capture buffer. At every end of event (recorded or not) the active buffer's pre-event data is replaced by the permanent pre-event buffer, which never captures the 250 ms group. The 250 ms history therefore restarts from zero samples, and the report pads the missing leading samples with 0.

## Expected behaviour (requirement source)
- V3.4 EDR_0455_045B r458-r478 AEB_WARNING_MSG at -3 S ... at 2 S (bytes 566-576), and the same 4/s rows for AES_WARNING, AES_SYS_STS (600-610), ESA_SYS_STS, LDW_LKA_SYS_STATE, LCF_SYS_STATE, SPA_SYS_STATE, ACC_SYS_STATE, RMS_MODE_STATE, LC_PATH_STATE, ELK oncoming/side/overtaking.
- Customer EDR_Requirements r7: CAN signals stored as per the DBC.
- Each record of a multi-event carries its own pre-crash history (customer multi-event tables).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:4704-4864 permanent capture (rstedr_PreEventDataBuffer, power-on cleared RstEdr/Implementation/Source/RstEdr.c:634-639): 100 ms, 200 ms, x00 ms, 500 ms, 1 s, 10 ms, 1 ms groups - no 250 ms group
- RstEdr/Implementation/Source/RstEdr.c:5012-5016 -> RstEdr/Implementation/Source/RstEdr.c:4901-4909 the 250 ms capture runs only in the before-event state, into the active buffer
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3183-3258 rstedr_Capture250msPreEventAdditionalData (13 elements, index u8Index3sTo0s4PerSec, fill counter)
- RstEdr/Implementation/Source/RstEdr.c:3011-3025 every end of event calls rstedr_PrepareCaptureAndWriteForNextEvent; RstEdr/Implementation/Source/RstEdr.c:3205 `...PreEventData = rstedr_PreEventDataBuffer;` (whole struct incl. 250 ms data, index and fill count = 0)
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:9705-9726 report: fill count < 13 -> leading samples written `0U`

## Actual / suspected behaviour
If T0 of event N+1 comes less than 13 x 250 ms after the end of event N, only floor(dt / 0.25 s) (+1 at T0) samples exist; the older ones read 0. 0 is a valid code for these signals (no warning / system off), so the record shows a false history. The previous event can be any algorithm wake-up that reaches end of event, even one that is not recorded.

**Observable at:** Bytes 566-576 (AEB_WARNING_MSG), 600-610 (AES_SYS_STS) and the other 4/s ADAS rows; control: AEB_FCTA_WARN bytes 577-579 (2/s, not affected)

## Test set-up
- Common set-up.
- Crash set `multi_crash_multi_near_front` (near crash then frontal deployment 2000 ms later), or two single curves triggered 2 s apart.

## Preconditions
- Standard preconditions.

## Input signals
- HPCAd_3_50: AEB_WARNING_MSG = 2, ACC_SYS_STATE = 4 (non-zero, constant from 10 s before Event 1).
- HPCAd_2_50: AES_SYS_STS = 3 (constant).
- HPCAd_1_10: AEB_FCTA_WARN = 1 (2/s control element).
- Use non-zero values: 0 cannot be told apart from the padding.

## Triggering conditions
Second event T0 less than 3.25 s after the end of the first event.

## Execution steps
1. Reference run: single frontal crash (curve `front`); read 0x0455 after 10 s; confirm bytes 566-576 and 600-610 hold the constant values in every sample.
2. fault_free_profile(); load_crash_curves(`multi_near_front`); hold the signal values for 10 s.
3. TriggerCrash(); keep all signal values constant until 10 s after the second T0.
4. Read 0x0455 and 0x045B; identify the record of the second event (higher LifeTimeEventNb).
5. Repeat with a 6000 ms set (`single_near_front`): the second record must be complete.

## Expected results
- Second event record: AES_SYS_STS -3..0 s samples all 0x3 (bytes 600-603 = 0x33 0x33 0x33 0x33 ...), AEB_WARNING_MSG samples all 0x2, AEB_FCTA_WARN all 0x1.

## Actual / suspected results
- Second event record: the oldest about 13 - (gap / 250 ms) samples of every 4/s element read 0x0 (e.g. bytes 600-602 = 0x00 for a 2 s gap), while AEB_FCTA_WARN (2/s) shows 0x1 over the whole -3..0 s window.
- The 6000 ms run shows complete series.

## Pass / fail criterion
FAIL if any 4/s sample in -3..0 s of the second record differs from the constant CAN value.

## Evidence to collect
- Both DID responses; CAN trace of HPCAd_1_10/2_50/3_50; ARIA trigger instants (to compute the gap).
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The 2/s and 1/s groups are not affected (they are in the permanent buffer).
- The same wipe also happens at proveout completion (RstEdr/Implementation/Source/RstEdr.c:1079), so a crash within about 3 s of RstEdr start shows the same zeros.
