# M210-EDR-20: Pre-crash samples that were never captured are reported as valid-looking values (0, 0x7FFF, 0xFFFF) instead of a marked code

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | EDR CAN-C recording |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence; padding constants spot-checked (AEB 0U, VehSpd 0x7FFF). |
| Related | Reviewer finding CAN-09 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
When a pre-crash buffer is not full (crash < 5 s after EDR start, see also M210-EDR-02 and M210-EDR-16), the missing samples are filled per element: vehicle speed 0x7FFF (511.98 km/h), ADAS/status 0 (valid 'no warning'), ABS/ESC 0 ('inactive'), Gear 0 ('Neutral'), tyres 0xFF, zonal battery 0 V, IMU 0xFFFF.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r5 defines FF only for 'no event'; no rule exists for samples before EDR start. A reader must be able to tell missing samples from data.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5391 VehSpd 0x7FFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:9725 ADAS 0U; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6201 ABS 0; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:7069 tyres 0xFF (reviewer list of about 25 constants)

## Actual / suspected behaviour
A crash 2 s after start-up records 'no warning / inactive / 511.98 km/h' for the first 3 s.

**Observable at:** Leading pre-crash samples of every element

## Test set-up
- Common set-up.

## Preconditions
- CAN values held constant from power-on.

## Input signals
- Non-zero constant values for all CAN-C signals.

## Triggering conditions
Crash less than 5 s after RstEdr proveout.

## Execution steps
1. Power-cycle; trigger a near crash 2 s after proveout completes; read 0x0455.

## Expected results
- Missing samples marked consistently (customer to define, e.g. FF).

## Actual / suspected results
- VehSpd -5..-3 s = 0x7FFF; ADAS/ABS leading samples 0.

## Pass / fail criterion
Report and ask the customer for a rule.

## Evidence to collect
- DID response; time of proveout and trigger.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Spec gap rather than a coding error.
