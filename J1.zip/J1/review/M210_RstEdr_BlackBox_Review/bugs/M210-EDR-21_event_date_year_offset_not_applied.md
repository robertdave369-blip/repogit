# M210-EDR-21: Event date: year copied raw from CAN although the code comment says a +20 offset is needed

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Other EDR (date/time) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read. |
| Related | Reviewer finding CAN-12 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The comment says the CAN year has a 2020 base and needs +20; the code copies the raw year into the 6-bit field.

## Expected behaviour (requirement source)
- V3.4 r11 Event Date CUSTOM_DATE_FORMAT_2 'DDMMYYYY' (year base not stated in the extract); DBC CLOCK_YEAR (1, 2020).

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:4831-4835 comment 'factor of 20U is needed', then `year_data = pEventDataReadBuffer->aHpcc1Year;` and `<< 2`

## Actual / suspected behaviour
Year 2026 (raw 6) is recorded as 6; a decoder with a 2000 base shows 2006.

**Observable at:** Byte 16 bits 7..2

## Test set-up
- Common set-up.

## Preconditions
- Standard preconditions.

## Input signals
- HPCC_1_100 CLOCK_YEAR raw 6 (2026), month 10, date 28.

## Triggering conditions
Any recorded event.

## Execution steps
1. Trigger a near crash; read 0x0455; decode bytes 16-17.

## Expected results
- Year field per the customer's format definition (confirm whether 26 or 6 is expected).

## Actual / suspected results
- Year field = 6.

## Pass / fail criterion
Decide with the customer which base the format uses.

## Evidence to collect
- DID response; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Low priority until the date format base is confirmed.
