# M210-EDR-33: Delta-V is reported as valid although the central accelerometer was Failing/Failed during the event

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence (OpsSgPoolMgr substitution, unused invalid-sample count). |
| Related | Reviewer finding TX-08 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
OpsSgPoolMgr sets data to 0 while Qf is Failing/Failed; RstEdr integrates regardless of Qf, counts invalid samples, but the Mahindra formatter ignores the count and only checks Qf at the sample instant.

## Expected behaviour (requirement source)
- No explicit customer rule; an invalid code (0xFE) exists in the code base.

## Code evidence
- OpsSgPoolMgr/Implementation/Source/OpsSgPoolMgr.c:878-909 data 0 while Failing
- RstEdr/Implementation/Source/RstEdr.c:5420-5447 integration ignores Qf, invalid count kept; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17846-17869 formatter ignores the count

## Actual / suspected behaviour
A transient sensor fault inside the crash window gives a too-small delta-V reported as valid.

**Observable at:** Bytes 219-270

## Test set-up
- Common set-up; ARIA SPI raw-word fault segment (5-20 ms) on the central sensor inside a front curve.

## Preconditions
- Standard preconditions.

## Input signals
- -

## Triggering conditions
Central sensor Failing during the crash.

## Execution steps
1. Run the faulted front curve; compare the recorded delta-V with the unfaulted run.

## Expected results
- Affected samples marked invalid (or as the customer defines).

## Actual / suspected results
- Smaller delta-V, no invalid marking.

## Pass / fail criterion
Report; ask for the rule.

## Evidence to collect
- DID; curve files.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The platform may intend Failing to be usable.
