# M210-EDR-30: The u16 event timer never stops and wraps after 32.768 s, re-opening the max-delta-V window in very long events

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Reviewer evidence. |
| Related | Reviewer finding SNS-08 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
u16ElapsedTimeFromTime0 increments every 0.5 ms without limit; max delta-V and deployment stamps use it.

## Expected behaviour (requirement source)
- V3.4 r256-r259 time to max delta-V 0..300 ms; AAUR_SW_RstEdr_201 'for 5 s after the T0'.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:2982 and RstEdr/Implementation/Source/RstEdr.c:3291 unconditional increment; RstEdr/Implementation/Source/RstEdr.c:6070 max-delta-V window `<= u16MaxDeltaVCaptureCompleteDelay`

## Actual / suspected behaviour
If an event stays open > 32.8 s, max delta-V / time to max / late deployment stamps take wrapped values.

**Observable at:** Bytes 271-276; deployment times

## Test set-up
- Not practical without keeping an algorithm awake > 33 s.

## Preconditions
- -

## Input signals
- Long low-g excitation keeping the algorithm awake.

## Triggering conditions
Event open longer than 32.8 s.

## Execution steps
1. Keep the algorithm awake 35 s, then apply a small pulse; read the record.

## Expected results
- Max delta-V consistent with the delta-V series.

## Actual / suspected results
- Inconsistent max / time to max.

## Pass / fail criterion
Report only.

## Evidence to collect
- DID.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Algorithm activity timeouts probably make this unreachable.
