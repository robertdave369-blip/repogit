# M210-EDR-07: Time between events of exactly 5.000 s is classified as multi-event

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Low |
| Area | EDR Multi-Event |
| Build variant | APPRISE and VTA |
| Verification | Code re-read; requirement AAUR /item/4322953 read. |
| Related | Reviewer finding EVT-11 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The multi-event window uses `<= 10000` ticks (5.000 s inclusive); the SW requirement says the counter is reset at >= 5 s.

## Expected behaviour (requirement source)
- RstEdr SW requirement /item/4322953: 'greater than or equal to 5 s ... reset the Multiple_Event_Counter to 1'.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:4357 `if(u16PreviousMultiEventTimer <= RSTEDR_MULT_EVENT_MAX_TIME)`; RstEdr_Intl.h:92 10000U (0.5 ms ticks)

## Actual / suspected behaviour
dT = 5.000 s gives MultiEventNumber 2 and TimeBtwEvents 0x2710 instead of 1 and 0xFFFF.

**Observable at:** Bytes 21 and 217-218 of the second record

## Test set-up
- Common set-up; sets `boundary_front_front_4999ms`, `_5000ms`, `_5001ms` (crash_data/multi_event).

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Second T0 exactly 10000 ticks after the first.

## Execution steps
1. Run each boundary set (fault_free_profile between runs); read both DIDs after 15 s.
2. Compute the actual T0 spacing from TimeBtwEvents where reported.

## Expected results
- 4999 ms: MEN 2, TBE about 0x270E; 5000 ms and 5001 ms: MEN 1, TBE 0xFFFF.

## Actual / suspected results
- 5000 ms run may report MEN 2 / TBE 0x2710.

## Pass / fail criterion
FAIL if a 5.000 s spacing is reported as multi-event.

## Evidence to collect
- Both DIDs; ARIA trigger timing.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The ECU's T0 detection jitter (0.5 ms) makes the exact boundary hard to hit; repeat several times. Low impact.
