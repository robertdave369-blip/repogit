# M210-EDR-10: Crash byte can show 'near crash' and 'locked' together (0xC0) for a deployment EnsMgr does not classify

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Low |
| Area | Other EDR (crash type) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (crash byte report, final priority); EnsMgr inputs re-read. |
| Related | Reviewer finding EVT-15; TX review note on rollover |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The near-crash bit is set when the EnsMgr crash type is 0, the lock bit when the slot priority is 0xC0. EnsMgr does not read the rollover algorithm severity, so a rollover-only (or otherwise unclassified) deployment would be locked yet shown as near crash.

## Expected behaviour (requirement source)
- V3.4 r14-r21: bit 5 Rollover (reserved for now), bit 6 Near crash, bit 7 lock; a deployment is not a near crash.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5018-5031 near bit when `(location & 0x1F) == 0`, lock bit when priority == 0xC0
- EnsMgr/Implementation/Source/EnsMgr.c:262-266 severities read for LISA, ALIS L/R, RITA, understrike only

## Actual / suspected behaviour
Byte 22 = 0xC0 for a rollover deployment.

**Observable at:** Byte 22

## Test set-up
- Common set-up; a rollover deployment stimulus, if rollover is enabled for M210 (customer marks it reserved).

## Preconditions
- Standard preconditions.

## Input signals
- IMU/roll-rate stimulus as required by the roll algorithm.

## Triggering conditions
Deployment decided by an algorithm EnsMgr does not evaluate.

## Execution steps
1. Run the rollover deployment; read 0x0455.

## Expected results
- Byte 22 = 0xA0 (rollover, locked) or as the customer defines.

## Actual / suspected results
- Byte 22 = 0xC0.

## Pass / fail criterion
FAIL if near crash and lock are both set.

## Evidence to collect
- DID; squib log; CAN trace (STS_CRASH).
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Only relevant if rollover deployment is enabled in M210.
