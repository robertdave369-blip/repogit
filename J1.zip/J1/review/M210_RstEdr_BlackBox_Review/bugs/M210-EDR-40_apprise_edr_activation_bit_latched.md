# M210-EDR-40: APPRISE build: the EDR activation bit can stay set after an event ends, so the next record inherits the previous crash type

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium (path exists), Low (frequency) |
| Area | EDR inputs / Multi-Event |
| Build variant | APPRISE only (M210 release builds are APPRISE) |
| Verification | Code re-read (set/clear call site, APPRISE end mask, OpsCshMgr bit handling, EnsMgr reset condition). |
| Related | Reviewer finding TX-06 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
RstEdr writes its 20 ms delta-V activity into the crash manager's activation status only while the event is still open. In the APPRISE build the end-of-event mask ignores that bit, so the event can end with the bit = 1 and nothing clears it. EnsMgr resets the EDR crash type only on a 0 -> non-0 change of the activation status, so the next event keeps the previous direction bits.

## Expected behaviour (requirement source)
- Each record carries its own event's crash type (customer multi-event tables, EDR_Requirements r19-r20).

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:2684-2733 rstedr_ManageEndOfEvent20mSDVBuffer -> RstEdr/Implementation/Source/RstEdr.c:2731 RSTEDR_SET_OPSCSHMGR_EDR_ACTIVATION_ST (only call)
- RstEdr/Implementation/Source/RstEdr.c:3087-3101 called only in the 'event not ended' branch; RstEdr/Implementation/Cfg/RstEdr_Cfg.h:126-127 APPRISE T0/Tend mask without RSTEDR_EDR_ACTIVE_MASK
- OpsCrash/OpsCshMgr/Implementation/Source/OpsCshMgr.c:1900-1911 bit set/cleared only by this call
- EnsMgr/Implementation/Source/EnsMgr.c:189-198 EDR crash type reset only when the previous activation status was 0

## Actual / suspected behaviour
Front deployment, then a near crash later in the same ignition cycle: record 2 byte 22 = 0x01 (front) instead of 0x40; supplier DID 0x0456/0x045C shows the EDR activation bit at T0. Side effects outside EDR: crash-manager data hold and deployment-manager wake-up handling (reviewer note).

**Observable at:** Byte 22 of the later record; supplier DIDs 0x0456 / 0x045C activation bytes

## Test set-up
- Common set-up; APPRISE release software (M210_P31 or later).

## Preconditions
- Standard preconditions.

## Input signals
- -

## Triggering conditions
An event that ends while the RstEdr 20 ms delta-V window is still above threshold.

## Execution steps
1. Event 1: frontal deployment. Wait 10 s (same ignition cycle; do not use load_crash_curves in between because it power-cycles).
2. Event 2: near crash (pre-load a merged curve, e.g. `single_front_near` with 6000 ms spacing).
3. Read 0x0455, 0x045B, 0x0456, 0x045C.

## Expected results
- Record of event 2: byte 22 = 0x40 (near crash only).

## Actual / suspected results
- Record of event 2 carries the front bit (0x01 / 0x41).

## Pass / fail criterion
FAIL if event 2's crash type contains bits of event 1.

## Evidence to collect
- All four DIDs; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The APPRISE delta-V algorithm (library only) may end after RstEdr's flag is FALSE, which would make the latch unreachable.
