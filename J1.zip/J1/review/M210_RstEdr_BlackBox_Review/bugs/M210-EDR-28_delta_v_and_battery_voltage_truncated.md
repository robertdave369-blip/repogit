# M210-EDR-28: Delta-V and battery voltage are truncated instead of rounded (bias toward zero)

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Low |
| Area | Sensor recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read. |
| Related | Reviewer finding SNS-05 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Delta-V uses an integer divisor 113 (true factor about 113.3 counts per km/h) with truncation; battery voltage is divided by 4 with truncation.

## Expected behaviour (requirement source)
- V3.4 r204-r259 delta-V 1 km/h; r4 battery voltage 0.1 V. No rounding rule stated.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17789 / 17805 `/ RSTEDR_CONVERT_DELTA_V_DIVISOR` (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:1918 113U); RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:4487 battery `/ 4`

## Actual / suspected behaviour
Delta-V up to -1 km/h low in magnitude (+0.27 % gain error); battery voltage up to 0.1 V low.

**Observable at:** Bytes 219-276 (delta-V), byte 6 (battery voltage)

## Test set-up
- Common set-up; curve with analytically known delta-V; supply set to 12.38 V.

## Preconditions
- Standard preconditions.

## Input signals
- Supply 12.38 V.

## Triggering conditions
Any recorded event.

## Execution steps
1. Run the curve; read 0x0455; compare delta-V and byte 6 with the computed values.

## Expected results
- Byte 6 = 0x7C (12.4 V) if rounded.

## Actual / suspected results
- Byte 6 = 0x7B (12.3 V); delta-V 1 km/h low in some samples.

## Pass / fail criterion
Within tolerance unless the customer specifies rounding.

## Evidence to collect
- DID; supply log.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Low impact; include in the accuracy test.
