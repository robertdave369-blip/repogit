# M210-EDR-35: STS_CRASH sent for 800 ms on SRS1_FD_10 can be missing entirely from the EDR STS_CRASH series

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium |
| Area | ECU Tx signals vs EDR |
| Build variant | APPRISE and VTA |
| Verification | Mechanism re-read: post-T0 index 0 discarded (M210-EDR-13), 800 ms window in EnsMgr (M210-EDR-39). |
| Related | Reviewer finding TX-02; supplier bench test RSTEDR_SRS1_FD_10_Tx_MESSAGE |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
STS_CRASH is high for about 800 ms after the deployment decision. The EDR STS_CRASH series samples on the free-running 500 ms tick and drops the first post-T0 sample. The '+0.5 s' slot is therefore taken 0.5-1.0 s after T0 and can fall after the pulse; '0 s' and the pre-T0 samples are 0.

## Expected behaviour (requirement source)
- V3.4 r995-r1015 STS_CRASH -1 S ... 9 S (bytes 858-860).
- Supplier bench test 4: 'Values of CAN message shall match with EDR recorded value'.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16736-16744 STS_CRASH post-T0 formatter starts at read index 1
- RstEdr/Implementation/Source/RstEdr.c:5182-5185 post capture on the 500 ms tick only
- EnsMgr/Implementation/Source/EnsMgr.c:529-536 crash outputs cleared after 1600 x 0.5 ms

## Actual / suspected behaviour
In roughly a third of crashes (T0 phase dependent) all 21 STS_CRASH bits are 0 although STS_CRASH = 1 was transmitted.

**Observable at:** SRS1_FD_10 STS_CRASH (CAN trace) vs bytes 858-860

## Test set-up
- Common set-up; CAN trace of SRS1_FD_10 with time stamps.

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Any deployment.

## Execution steps
1. Run 10 identical frontal deployments, shifting the trigger by 50 ms each run (fault_free_profile between runs).
2. For each run read 0x0455 and decode the 21 STS_CRASH bits; overlay on the CAN STS_CRASH trace.

## Expected results
- At least one post-T0 STS_CRASH bit = 1 in every run (the Tx pulse spans 0.8 s).

## Actual / suspected results
- Some runs show all STS_CRASH bits 0.

## Pass / fail criterion
FAIL if a run with STS_CRASH = 1 on CAN shows no 1 in the EDR series.

## Evidence to collect
- CAN trace; DID per run; trigger times.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- Root causes: M210-EDR-13 (index 0 discarded) and the 800 ms hold (M210-EDR-39).
