# M210-EDR-23: On-fail recording depends entirely on CanMgr: RstEdr records raw port values (and 0 for a frame never received)

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | OnFail-on-CAN recording |
| Build variant | APPRISE and VTA |
| Verification | Code re-read for the Mahindra elements (no Qf use except motor speed and IMU); CanMgr not in the tree. |
| Related | Reviewer CAN 'could not check' items; framework scripts_simple on-fail suites |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
RstEdr does not implement node absent / message timeout / message content / invalid / signal-never-received / variant-code / UV-OV reactions for the CAN-C elements. It records whatever CanMgr writes into the RTE ports; the ports initialise to 0. Exceptions: motor speed becomes 0xFFFF when its Qf is NotAvailable/NotCaptured, and IMU elements become 0xFFFF unless Qf is Valid/Failing. So every on-fail reaction must be verified end to end.

## Expected behaviour (requirement source)
- Customer on-fail rules (framework docs/project_documents/onfail_documents): NA / MTO / MCF / UV-OV -> last valid value; invalid -> consume; SNR / VC -> default value. Customer EDR_Requirements r7.

## Code evidence
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3183-3690 (captures store the raw port value); RstEdr/Implementation/Cfg/Rte_RstEdr.h:397-470 init values 0
- RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6086-6100 motor speed: Qf NotCaptured/NotAvailable -> 0xFFFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:8424-8432 IMU Qf handling

## Actual / suspected behaviour
If CanMgr does not substitute (or uses a different value), the record differs from the on-fail rules. A frame that never arrives after power-up is recorded as 0 (e.g. VEHICLE_SPEED 0x0000 instead of the DBC default 0xFFFE).

**Observable at:** Every CAN-C element of 0x0455 / 0x045B

## Test set-up
- Framework M210 on-fail suites: projects/M210/modules/EDR_CANC/scripts_simple runners run_NA_*, run_MTO_*, run_MCF_*, run_SCF_*, run_SNR_Full, run_VC_Full, run_UV_*, run_OV_* (and the COMBINED scripts).

## Preconditions
- Standard preconditions; ECU on the M210 release software.

## Input signals
- As defined per case in canc_config (node absent = stop all frames of the node, MTO = stop the signal frame, MCF = disable CRC, SCF = DBC invalid code, SNR/VC = variant code, UV/OV = supply).

## Triggering conditions
Each on-fail class before, during and after T0.

## Execution steps
1. Run the on-fail runners (Full, Pre, Post) and the COMBINED scripts.
2. Additional case: power up with IEB1_FD_10 never sent; trigger a near crash; read bytes 4-5 and 30-63.
3. Additional case: stop VCU11_FD_10 (motor speed) before the crash; check bytes 87-120 for 0xFFFF vs last valid value.

## Expected results
- Each record follows the on-fail rule for its class.

## Actual / suspected results
- Unknown until run: RstEdr itself applies no rule, so any deviation comes from CanMgr.

## Pass / fail criterion
FAIL per element where the record does not follow the on-fail rule.

## Evidence to collect
- Framework HTML reports; raw DID responses; CAN trace.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- This is the main black-box test gap for OnFail-on-CAN: the reviewed code cannot show the on-fail behaviour.
