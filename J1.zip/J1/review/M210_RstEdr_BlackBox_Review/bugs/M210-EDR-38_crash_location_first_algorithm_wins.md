# M210-EDR-38: CRASH_LOCATION reports the first algorithm to reach its threshold, not the highest-priority direction

| | |
|---|---|
| Classification | **Potential** |
| Confidence | Medium (code), Low (requirement) |
| Area | ECU Tx signals |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (only one CAN direction bit per 800 ms window). |
| Related | Reviewer finding TX-04 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
Only the first algorithm that meets its CAN condition sets the CAN crash bit; later directions in the 800 ms window are ignored. The EDR byte 22 ORs all directions.

## Expected behaviour (requirement source)
- Project knowledge base (.github/agents/agent_sc3.md): priority Front > Left > Right > Rollover > Rear > Understrike. Not in the customer files provided.

## Code evidence
- EnsMgr/Implementation/Source/EnsMgr.c:220-225 CAN bit only while EcallStartedAtLeastOnce == FALSE; EnsMgr/Implementation/Source/EnsMgr.c:262-266 evaluation order; EnsMgr/Implementation/Source/EnsMgr.c:214 EDR byte is an OR

## Actual / suspected behaviour
Oblique crash where the side algorithm decides first: CRASH_LOCATION = 3 (left) although front airbags fire.

**Observable at:** SRS1_FD_10 CRASH_LOCATION vs byte 22

## Test set-up
- Common set-up; merged set with a left pulse starting about 10 ms before a frontal deployment pulse (parallel class).

## Preconditions
- Standard preconditions.

## Input signals
- -

## Triggering conditions
Two directions within one 800 ms window.

## Execution steps
1. Run `parallel_front_left`; record CRASH_LOCATION; read 0x0455.

## Expected results
- CRASH_LOCATION = 1 (front) per the priority rule.

## Actual / suspected results
- CRASH_LOCATION = 3 (left).

## Pass / fail criterion
Report; confirm the priority rule with the customer.

## Evidence to collect
- CAN trace; DID.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- CanMgr receives one bit only, so it cannot apply a priority rule itself.
