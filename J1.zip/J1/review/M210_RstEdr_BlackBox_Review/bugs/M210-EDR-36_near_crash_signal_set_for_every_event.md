# M210-EDR-36: NEAR_CRASH (SRS1_FD_10) is set at the start of every EDR event, including deployments and wake-ups that are never recorded

| | |
|---|---|
| Classification | **Needs investigation** |
| Confidence | Medium |
| Area | ECU Tx signals |
| Build variant | APPRISE and VTA |
| Verification | Code re-read in EnsMgr (near-crash logic, CAN update). |
| Related | Reviewer findings TX-01 and EVT-14 (same issue) |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
EnsMgr sets NearCrashStatus as soon as RstEdr reports an active event and no E-call/STS_CRASH has started; this is true at algorithm wake-up for every crash, including one that deploys later, and for wake-ups below the EDR record threshold (DV150 8 km/h). The status is held 800 ms.

## Expected behaviour (requirement source)
- Customer EDR_Requirements r8 (near crash: below deployable threshold, STS_CRASH/Door_UNLOCK not sent). The semantics of NEAR_CRASH itself are not written; the DBC labels 1 'Crash', 0 'No Near Crash'.
- EV multi-event test spec (multievent__Export r41/r906): deployment event NEAR_CRASH = 0.

## Code evidence
- EnsMgr/Implementation/Source/EnsMgr.c:287-298 NearCrashStatus = TRUE when the EDR event is active and EcallStartedAtLeastOnce == FALSE
- EnsMgr/Implementation/Source/EnsMgr.c:299-313 held until 1600 x 0.5 ms; EnsMgr/Implementation/Source/EnsMgr.c:601 `ENSMGR_UPDATE_NEAR_CRASH_STATUS(...)` to CAN
- RstEdr/Implementation/Source/RstEdr.c:1802-1808 RstEdr_GetEventStatus TRUE in the on-event sub-state, whatever the priority

## Actual / suspected behaviour
(a) Deployment: NEAR_CRASH = 1 from T0 for 800 ms together with STS_CRASH = 1. (b) Wake-up below 8 km/h: NEAR_CRASH = 1 for 800 ms, both DIDs stay FF.

**Observable at:** SRS1_FD_10 NEAR_CRASH and STS_CRASH; DID 0x0455

## Test set-up
- Common set-up; CAN trace.

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
(a) frontal deployment; (b) low-level pulse that wakes the algorithm but stays below 8 km/h DV150.

## Execution steps
1. Run (a); measure NEAR_CRASH and STS_CRASH intervals.
2. Run (b); measure NEAR_CRASH; read 0x0455.

## Expected results
- Per customer definition (to be confirmed): NEAR_CRASH = 0 for deployments; NEAR_CRASH = 1 only for recorded near crashes.

## Actual / suspected results
- (a) NEAR_CRASH = 1 overlapping STS_CRASH; (b) NEAR_CRASH = 1 with no EDR record.

## Pass / fail criterion
Report against the customer definition of NEAR_CRASH.

## Evidence to collect
- CAN trace; DID.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- CanMgr (not in the tree) might suppress NEAR_CRASH during a deployment. Ask Mahindra for the NEAR_CRASH definition.
