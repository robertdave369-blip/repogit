# M210-EDR-25: Delta-V 10 ms samples follow a free-running tick: the '0 ms' sample is taken 0.5-10 ms after T0

| | |
|---|---|
| Classification | **Reproducible** |
| Confidence | Medium |
| Area | Sensor recording (delta-V) |
| Build variant | APPRISE and VTA |
| Verification | Code re-read (10 ms capture, delta-V sample, T0 adjust, timer chain reset only at init). |
| Related | Reviewer finding SNS-04 |

Code paths are relative to `C:\Project_M210\SwEntities\Application\Ops`. DID byte numbers follow the customer sheet M312_M112_M210 SRS **V3.4**
`EDR_0455_045B` (0-based data offset after `62 04 55`); the framework's `edr_config.py` `data_start_byte` is that
number + 4 (see [COMMON_TEST_SETUP.md](../COMMON_TEST_SETUP.md)).

## Summary
The delta-V samples are taken on the free-running 10 ms tick. The first sample after T0 therefore lies 0.5..10 ms after T0, and every later sample keeps that random offset. The offset is captured internally but not reported in the M210 layout.

## Expected behaviour (requirement source)
- V3.4 r204-r229 'Delta Velocity, longitudinal at 0 mS' ... 'at 250 mS' (bytes 219-244), lateral r230-r255 (245-270), 1 km/h; AAUR_SW_RstEdr_262: every 10 ms relative to T0.

## Code evidence
- RstEdr/Implementation/Source/RstEdr.c:6386-6419 samples only when the 10 ms flag is set; RstEdr/Implementation/Source/RstEdr.c:6202-6206 sample = DeltaVel + adjust
- RstEdr/Implementation/Source/RstEdr.c:4563-4564 adjust taken at T0 (accel at T0 - DeltaVel at T0); timer chain reset only at init (RstEdr/Implementation/Source/RstEdr.c:1004)

## Actual / suspected behaviour
For identical crash curves the delta-V series varies run to run; '0 ms' is not 0 for a hard pulse (several km/h for a 20-30 g pulse).

**Observable at:** Bytes 219-270

## Test set-up
- Common set-up; a rectangular 30 g frontal pulse curve (or the standard `front` curve).

## Preconditions
- Standard preconditions.

## Input signals
- All Rx frames valid.

## Triggering conditions
Any recorded event.

## Execution steps
1. Run the same curve 10 times (fault_free_profile between runs).
2. Read bytes 219-244 each time; compute delta-V from the curve at T0 + 10k ms.

## Expected results
- '0 ms' = 0 km/h (offset 100 -> 0x64); samples repeat within 1 km/h between runs.

## Actual / suspected results
- '0 ms' up to several km/h and run-to-run spread of the whole series.

## Pass / fail criterion
FAIL if the series is not aligned to T0 within the customer's tolerance (to be confirmed).

## Evidence to collect
- DID responses of all runs; curve file; trigger times.
- The standard evidence list in COMMON_TEST_SETUP.md.

## Notes, open questions, why it might not be a bug
- The platform reports the offset for other regulations; the customer layout has no offset field. Tolerance not stated.
