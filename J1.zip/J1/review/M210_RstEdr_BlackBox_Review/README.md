# M210 RstEdr (EDR) source review - potential bugs testable by black-box test

Review date 2026-10-28. Source: `C:\Project_M210\SwEntities\Application\Ops\RstEdr\Implementation\Source` (RstEdr.c 20,141 lines, RstEdr_Intl.h),
reviewed together with `RstEdr\Implementation\Cfg` (RstEdr_Lcfg.c 24,100 lines: the Mahindra/India EDR elements,
RstEdr_Cfg.h, RTE headers) and the components that feed EDR or drive the crash Tx signals: EnsMgr, OpsCrash/OpsCshMgr,
OpsCrash/DplmtMgr, OpsSgPoolMgr. Nothing was modified in the M210 tree and nothing was run on a bench.

Test documents: one per bug in [bugs/](bugs/); shared bench set-up in [COMMON_TEST_SETUP.md](COMMON_TEST_SETUP.md).

## How the review was done
1. Architecture map of RstEdr (event detection, priority/lock, slot search, multi-event, capture buffers and timer chains,
   NvM records and synthesis block, read-out) and of its RTE inputs, against the M210 compile-time configuration
   (RstEdr_Cfg.h: 2 event records, 3 capture buffers; algorithm variant APPRISE / VTA; M210 releases ship APPRISE).
2. Four independent deep reviews (event / multi-event / storage, CAN-C and on-fail recording, sensor / delta-V /
   deployment data, inputs and ECU crash Tx signals), each citing file:line.
3. **Every finding re-verified in this review by re-reading the code** before classification; findings that did not
   survive were withdrawn (below). Requirement text checked against the customer documents.

### Requirement baseline
- Customer diagnostic specification **M312_M112_M210_SRS V3.4** (`docs/project_documents/EDR_Spec Common/EV`):
  sheets EDR_0455_045B, EDR_Requirements, EDR Sensor Data. The ECU code follows V3.4 where V3.4 differs from V2.7
  (completion-status bits 7/6, STS_LOWBEAM / STS_EBD / SEB_WARNING_RIGHT on their own bytes, SRS ECU Status at byte 69,
  521-byte sensor DIDs). EDR_Requirements is identical in V2.7 and V3.4.
- RstEdr software requirements (VectorCAST requirements DB, 796 items AAUR_SW_RstEdr_*), RstEdr design sheets.
- EV common EDR multi-event test spec, on-fail matrix (`docs/project_documents/onfail_documents`), M210 DBCs.
- Supplier bench report (RstEdr_Mahindra_Bench_Test_Report.xlsx) and the 8D "W610/M110 EDR report index issue".

## Classification used
| Class | Meaning |
|---|---|
| **Confirmed** | The code path is active in the shipped M210 build, the code reading proves the behaviour, and it contradicts an explicit written requirement, without depending on any component outside the reviewed tree. Confirmed by analysis, not yet by a bench run (each has a test document). |
| **Reproducible** | Deterministic behaviour that a black-box test will show and that deviates from the customer's expected behaviour, but either the requirement is disputed/open, the behaviour is by design (SW requirement vs customer spec), or the result assumes an outside component (e.g. DiagMgr passes bytes through) behaves as expected. |
| **Potential (inferred from code)** | A plausible defect whose appearance depends on timing, phase, calibration or a rare trigger; the test decides. |
| **Needs investigation** | Expected behaviour is undefined or ambiguous, or the outcome depends mainly on components not in the tree (CanMgr, DiagMgr/Dcm, NvM, SysModMgr, algorithm libraries). |

Totals: 2 Confirmed, 7 Reproducible, 14 Potential, 17 Needs investigation (40 items).

## Verification per functionality
**EDR Multi-Event.** Working as specified: slot search (empty first, then oldest unlocked of equal or lower priority),
locked records never overwritten, a new event dropped when both records are locked, Multi Event Number chained
(1, 2, 3) with TimeBtwEvents in 0.5 ms and 0xFFFF for a first event, lifetime counter, third event reusing the oldest
capture buffer, capture indices reset at every algorithm wake-up (the 8D defect stays fixed). Deviations:
[M210-EDR-01](bugs/M210-EDR-01_multi_event_near_deploy_near_event3_lost.md), [M210-EDR-02](bugs/M210-EDR-02_adas_4hz_precrash_series_zeroed_after_previous_event.md), [M210-EDR-03](bugs/M210-EDR-03_repeat_deployment_same_loops_not_locked.md), [M210-EDR-07](bugs/M210-EDR-07_exactly_5s_classified_as_multi_event.md), [M210-EDR-09](bugs/M210-EDR-09_no_minimum_separation_between_events.md), [M210-EDR-12](bugs/M210-EDR-12_multi_event_number_wraps_at_255.md), [M210-EDR-40](bugs/M210-EDR-40_apprise_edr_activation_bit_latched.md).

**EDR CAN-C recording.** Working: sample counts and recording windows of all Mahindra elements match V3.4; circular
pre-crash buffers unrolled oldest first without wrap errors; element lengths, nibble/2-bit packers and raw DBC
pass-through (big endian) correct; vehicle speed at T0 taken at the exact T0. Deviations:
[M210-EDR-02](bugs/M210-EDR-02_adas_4hz_precrash_series_zeroed_after_previous_event.md), [M210-EDR-13](bugs/M210-EDR-13_first_post_t0_sample_discarded_can_series.md), [M210-EDR-14](bugs/M210-EDR-14_one_second_elements_have_no_t0_sample.md), [M210-EDR-15](bugs/M210-EDR-15_sts_crash_pib_samples_after_5s_always_zero.md), [M210-EDR-16](bugs/M210-EDR-16_t0_sample_overwritten_when_record_written_before_first_tick.md), [M210-EDR-17](bugs/M210-EDR-17_lka_handsoff_value_not_masked.md), [M210-EDR-18](bugs/M210-EDR-18_occupant_ecall_counts_and_zone_hardcoded.md), [M210-EDR-19](bugs/M210-EDR-19_one_bit_packers_or_into_unzeroed_buffer.md), [M210-EDR-20](bugs/M210-EDR-20_not_captured_samples_look_like_valid_data.md), [M210-EDR-21](bugs/M210-EDR-21_event_date_year_offset_not_applied.md).

**OnFail-on-CAN recording.** RstEdr implements no on-fail reaction for the CAN-C elements; it records what CanMgr
writes into the RTE ports (CanMgr is not in the tree). The on-fail behaviour can only be proven by black-box test:
[M210-EDR-23](bugs/M210-EDR-23_onfail_values_depend_on_canmgr_rstedr_ignores_qf.md), [M210-EDR-17](bugs/M210-EDR-17_lka_handsoff_value_not_masked.md), [M210-EDR-22](bugs/M210-EDR-22_rte_limits_narrower_than_dbc_raw_range.md).

**Sensor recording (accelerations, delta-V, deployment times).** Working: delta-V integration every 0.5 ms with the
AUTOSAR longitudinal sign, sint16 overflow correction, max delta-V / time to max over 0-300 ms, clamp to +/-100 km/h,
0xFF for uncollected and 0xFE for failed samples, 500 us pre-crash ring, sensor conversion constants (APPRISE), IMU
formatters, battery voltage clamp. Deviations:
[M210-EDR-24](bugs/M210-EDR-24_deployment_time_reported_in_half_ms_ticks.md), [M210-EDR-25](bugs/M210-EDR-25_delta_v_samples_not_aligned_to_t0.md), [M210-EDR-26](bugs/M210-EDR-26_loop_fired_in_t0_cycle_reported_not_deployed.md), [M210-EDR-27](bugs/M210-EDR-27_sensor_did_failing_samples_stored_as_ff.md), [M210-EDR-28](bugs/M210-EDR-28_delta_v_and_battery_voltage_truncated.md), [M210-EDR-29](bugs/M210-EDR-29_sensor_did_sample_alignment_half_ms.md), [M210-EDR-30](bugs/M210-EDR-30_event_timer_wraps_after_32s.md), [M210-EDR-31](bugs/M210-EDR-31_lateral_sign_convention_inconsistent.md), [M210-EDR-32](bugs/M210-EDR-32_sensor_did_reporter_ignores_requested_event.md), [M210-EDR-33](bugs/M210-EDR-33_delta_v_valid_while_accel_failing.md).

**Other EDR functions (locking, completion status, clear, read-out, power, date).**
[M210-EDR-34](bugs/M210-EDR-34_200ms_completion_bit_set_before_200ms.md), [M210-EDR-15](bugs/M210-EDR-15_sts_crash_pib_samples_after_5s_always_zero.md), [M210-EDR-06](bugs/M210-EDR-06_plant_mode_understrike_record_never_replaced.md), [M210-EDR-10](bugs/M210-EDR-10_near_and_lock_bits_from_different_sources.md), [M210-EDR-04](bugs/M210-EDR-04_no_event_recorded_after_edr_clear_until_reset.md), [M210-EDR-05](bugs/M210-EDR-05_crash_during_edr_readout_not_recorded.md), [M210-EDR-08](bugs/M210-EDR-08_synthesis_saved_only_on_orderly_power_down.md), [M210-EDR-11](bugs/M210-EDR-11_power_down_request_is_one_way.md), [M210-EDR-16](bugs/M210-EDR-16_t0_sample_overwritten_when_record_written_before_first_tick.md), [M210-EDR-21](bugs/M210-EDR-21_event_date_year_offset_not_applied.md).

**CAN signals transmitted by the ECU (SRS1_FD_10 / SRS1_20) and other EDR inputs.** Working: no STS_CRASH /
DOOR_UNLOCK for a near crash, none in plant mode, STS_CRASH not carried across resets, crash-byte bit mapping.
Deviations: [M210-EDR-35](bugs/M210-EDR-35_sts_crash_pulse_missing_from_edr_series.md), [M210-EDR-36](bugs/M210-EDR-36_near_crash_signal_set_for_every_event.md), [M210-EDR-37](bugs/M210-EDR-37_sts_crash_gating_differs_from_edr_crash_type.md), [M210-EDR-38](bugs/M210-EDR-38_crash_location_first_algorithm_wins.md), [M210-EDR-39](bugs/M210-EDR-39_sts_crash_held_only_800ms.md), [M210-EDR-18](bugs/M210-EDR-18_occupant_ecall_counts_and_zone_hardcoded.md), [M210-EDR-40](bugs/M210-EDR-40_apprise_edr_activation_bit_latched.md).

## Bug list
| ID | Title | Class | Confidence | Area | Observable at |
|---|---|---|---|---|---|
| [M210-EDR-01](bugs/M210-EDR-01_multi_event_near_deploy_near_event3_lost.md) | Multi-event near crash -> deployment -> near crash: Event 3 is not recorded | Confirmed | High | EDR Multi-Event | DID 0x0455 / 0x045B bytes 0-3 (LifeTimeEventNb), 21 (MultiEventNumber), 22 (crash type / near / lock), 217-218 (TimeBtwEvents) |
| [M210-EDR-02](bugs/M210-EDR-02_adas_4hz_precrash_series_zeroed_after_previous_event.md) | ADAS 4-per-second pre-crash series (-3 s..0 s) recorded as 0 when T0 follows a previous end of event by < 3.25 s | Confirmed | High | EDR CAN-C recording / Multi-Event | Bytes 566-576 (AEB_WARNING_MSG), 600-610 (AES_SYS_STS) and the other 4/s ADAS rows; control: AEB_FCTA_WARN bytes 577-579 (2/s, not affected) |
| [M210-EDR-03](bugs/M210-EDR-03_repeat_deployment_same_loops_not_locked.md) | A deployment that re-fires loops already fired in the same reset cycle is not locked | Reproducible | Medium | EDR Multi-Event / record locking | DID 0x0455 / 0x045B byte 22 (bit 7 lock), deployment time words 165-212 |
| [M210-EDR-04](bugs/M210-EDR-04_no_event_recorded_after_edr_clear_until_reset.md) | After an EDR clear (NvM data reset) no event is recorded until the next ECU reset | Reproducible | High | Other EDR (record management) | DID 0x0455 / 0x045B (all FF after the crash) |
| [M210-EDR-13](bugs/M210-EDR-13_first_post_t0_sample_discarded_can_series.md) | First post-T0 sample of every CAN-C time series is discarded; 1-per-second elements jump 2 s from '0 s' to '+1 s' | Reproducible | High (1 s group), Medium (500 ms / 250 ms groups) | EDR CAN-C recording | Gear bytes 347-351 (V3.4 r313-r321); VCU_DRV_ADV_MODE 845-847; Vehicle Speed 30-63; IMU 357-560 |
| [M210-EDR-15](bugs/M210-EDR-15_sts_crash_pib_samples_after_5s_always_zero.md) | STS_CRASH and PIB_ACTIVE samples from +5.5 s to +9 s are never captured and always read 0 | Reproducible | High | EDR CAN-C recording | Bytes 858-860 (STS_CRASH), 866-868 (PIB_ACTIVE) |
| [M210-EDR-18](bugs/M210-EDR-18_occupant_ecall_counts_and_zone_hardcoded.md) | Occupant / e-call counts, seat position zone and OCS class at T0 are hard-coded FF although SRS1_FD_10 transmits them | Reproducible | High (code) | EDR CAN-C recording / ECU Tx signals | Bytes 853-857 vs SRS1_FD_10 at T0 |
| [M210-EDR-24](bugs/M210-EDR-24_deployment_time_reported_in_half_ms_ticks.md) | Deployment times are reported in 0.5 ms ticks in a field the customer defines in 1 ms (values doubled) | Reproducible | High | Sensor / deployment recording | Bytes 165-212 (24 deployment-time words) of 0x0455 / 0x045B |
| [M210-EDR-25](bugs/M210-EDR-25_delta_v_samples_not_aligned_to_t0.md) | Delta-V 10 ms samples follow a free-running tick: the '0 ms' sample is taken 0.5-10 ms after T0 | Reproducible | Medium | Sensor recording (delta-V) | Bytes 219-270 |
| [M210-EDR-05](bugs/M210-EDR-05_crash_during_edr_readout_not_recorded.md) | A crash during an EDR read-out ($22 0455/045B in progress) is not recorded or gets a late T0 | Potential | Medium | Other EDR (record management) | DID 0x0455 / 0x045B after the crash; NEAR_CRASH/STS_CRASH on CAN still behave normally |
| [M210-EDR-06](bugs/M210-EDR-06_plant_mode_understrike_record_never_replaced.md) | Plant-mode understrike record (unlocked, priority 1) is never replaced by later near crashes | Potential | Medium | Other EDR (record management) | DID 0x0455 / 0x045B bytes 0-3 (LifeTimeEventNb), 22 |
| [M210-EDR-07](bugs/M210-EDR-07_exactly_5s_classified_as_multi_event.md) | Time between events of exactly 5.000 s is classified as multi-event | Potential | Low | EDR Multi-Event | Bytes 21 and 217-218 of the second record |
| [M210-EDR-12](bugs/M210-EDR-12_multi_event_number_wraps_at_255.md) | MultiEventNumber wraps from 255 to 0 in very long event chains | Potential | Low | EDR Multi-Event | Byte 21 |
| [M210-EDR-14](bugs/M210-EDR-14_one_second_elements_have_no_t0_sample.md) | 1-per-second CAN-C elements never get a T0 sample, so '0 s' can be up to 1 s old | Potential | Medium | EDR CAN-C recording | Gear byte 349 low nibble; STS_HIGHBEAM byte 800 bit 4; snapshot elements sourced from the 1 s capture |
| [M210-EDR-16](bugs/M210-EDR-16_t0_sample_overwritten_when_record_written_before_first_tick.md) | If the record is written before the first post-T0 tick (battery cut-off), the '0 s' sample is overwritten with the not-captured value | Potential | Medium | EDR CAN-C recording / power loss | Bytes 4-5 vs 50-51 (vehicle speed); 349 low nibble (Gear); byte 216 bit 6 |
| [M210-EDR-17](bugs/M210-EDR-17_lka_handsoff_value_not_masked.md) | LKA_HANDSOFF_DISPLAY_WARNING samples are not masked to 1 bit; raw 2 or 3 corrupts neighbouring samples | Potential | High (code), Medium (trigger) | EDR CAN-C recording / OnFail-on-CAN (reserved values) | Byte 658 (V3.4) |
| [M210-EDR-26](bugs/M210-EDR-26_loop_fired_in_t0_cycle_reported_not_deployed.md) | A loop fired in the T0 cycle (time stamp 0) is reported 'not deployed' in the deployment-status bits | Potential | Medium (code), Low (trigger) | Sensor / deployment recording | Bytes 165-212 vs 213-215 |
| [M210-EDR-27](bugs/M210-EDR-27_sensor_did_failing_samples_stored_as_ff.md) | 500 us sensor DIDs store 0xFF for samples with Qf 'Failing', while delta-V uses the same samples | Potential | Low | Sensor recording | Sensor DIDs 0x045F-0x04A1 (521 data bytes each) |
| [M210-EDR-28](bugs/M210-EDR-28_delta_v_and_battery_voltage_truncated.md) | Delta-V and battery voltage are truncated instead of rounded (bias toward zero) | Potential | Low | Sensor recording | Bytes 219-276 (delta-V), byte 6 (battery voltage) |
| [M210-EDR-34](bugs/M210-EDR-34_200ms_completion_bit_set_before_200ms.md) | '200 ms CompletionStatus' is set at end of event + 30 ms, i.e. before 200 ms for short events | Potential | Medium | Other EDR (completion status, battery cut-off) | Byte 216 bit 6 (V3.4) |
| [M210-EDR-35](bugs/M210-EDR-35_sts_crash_pulse_missing_from_edr_series.md) | STS_CRASH sent for 800 ms on SRS1_FD_10 can be missing entirely from the EDR STS_CRASH series | Potential | Medium | ECU Tx signals vs EDR | SRS1_FD_10 STS_CRASH (CAN trace) vs bytes 858-860 |
| [M210-EDR-37](bugs/M210-EDR-37_sts_crash_gating_differs_from_edr_crash_type.md) | STS_CRASH / DOOR_UNLOCK / ENS use different gating from the EDR crash type (front needs SEV2 and arming) | Potential | Medium (pretensioner-only front), Low (arming cases) | ECU Tx signals vs EDR | SRS1_FD_10 STS_CRASH / CRASH_LOCATION, SRS1_20 DOOR_UNLOCK, ENS GPO, byte 22 |
| [M210-EDR-38](bugs/M210-EDR-38_crash_location_first_algorithm_wins.md) | CRASH_LOCATION reports the first algorithm to reach its threshold, not the highest-priority direction | Potential | Medium (code), Low (requirement) | ECU Tx signals | SRS1_FD_10 CRASH_LOCATION vs byte 22 |
| [M210-EDR-08](bugs/M210-EDR-08_synthesis_saved_only_on_orderly_power_down.md) | Record lock, priority, lifetime and multi-event data are saved only by an orderly power-down | Needs investigation | Medium | Other EDR (record management) | DID 0x0455 / 0x045B after the reset; next event's slot |
| [M210-EDR-09](bugs/M210-EDR-09_no_minimum_separation_between_events.md) | Two impacts closer than 500 ms are split into two records as soon as the first event ends | Needs investigation | Medium | EDR Multi-Event | Bytes 0-3, 21, 22, 217-218 of both records |
| [M210-EDR-10](bugs/M210-EDR-10_near_and_lock_bits_from_different_sources.md) | Crash byte can show 'near crash' and 'locked' together (0xC0) for a deployment EnsMgr does not classify | Needs investigation | Low | Other EDR (crash type) | Byte 22 |
| [M210-EDR-11](bugs/M210-EDR-11_power_down_request_is_one_way.md) | RstEdr power-down is one-way: an aborted shutdown leaves EDR inactive until reset | Needs investigation | Low | Other EDR (power handling) | Both DIDs after the second crash |
| [M210-EDR-19](bugs/M210-EDR-19_one_bit_packers_or_into_unzeroed_buffer.md) | 1-bit multi-sample elements are OR-ed into the DID buffer without clearing it first | Needs investigation | Medium | EDR CAN-C recording | Bytes 658, 756, 800, 801, 816, 817, 820, 827, 858-860, 866-869 |
| [M210-EDR-20](bugs/M210-EDR-20_not_captured_samples_look_like_valid_data.md) | Pre-crash samples that were never captured are reported as valid-looking values (0, 0x7FFF, 0xFFFF) instead of a marked code | Needs investigation | Medium | EDR CAN-C recording | Leading pre-crash samples of every element |
| [M210-EDR-21](bugs/M210-EDR-21_event_date_year_offset_not_applied.md) | Event date: year copied raw from CAN although the code comment says a +20 offset is needed | Needs investigation | Low | Other EDR (date/time) | Byte 16 bits 7..2 |
| [M210-EDR-22](bugs/M210-EDR-22_rte_limits_narrower_than_dbc_raw_range.md) | RTE type limits are narrower than the DBC raw range; if CanMgr saturates to them, recorded values are wrong | Needs investigation | Low | OnFail-on-CAN / CAN-C recording | Bytes 87-120 (motor speed), 625-646 (ADAS angle), 30-63 (vehicle speed), steering angle rows |
| [M210-EDR-23](bugs/M210-EDR-23_onfail_values_depend_on_canmgr_rstedr_ignores_qf.md) | On-fail recording depends entirely on CanMgr: RstEdr records raw port values (and 0 for a frame never received) | Needs investigation | Medium | OnFail-on-CAN recording | Every CAN-C element of 0x0455 / 0x045B |
| [M210-EDR-29](bugs/M210-EDR-29_sensor_did_sample_alignment_half_ms.md) | 500 us sensor DIDs: the sample at byte 20 may be T0 + 0.5 ms instead of T0 (one-sample shift) | Needs investigation | Medium | Sensor recording | Sensor DIDs 0x045F (central lateral, record 1), 0x0460 (central longitudinal) and the RSU DIDs |
| [M210-EDR-30](bugs/M210-EDR-30_event_timer_wraps_after_32s.md) | The u16 event timer never stops and wraps after 32.768 s, re-opening the max-delta-V window in very long events | Needs investigation | Low | Sensor recording | Bytes 271-276; deployment times |
| [M210-EDR-31](bugs/M210-EDR-31_lateral_sign_convention_inconsistent.md) | Lateral sign convention differs between delta-V (inverted) and lateral acceleration data (not inverted) | Needs investigation | Low | Sensor recording | Bytes 245-270 vs sensor DID 0x045F / IMU lateral acceleration |
| [M210-EDR-32](bugs/M210-EDR-32_sensor_did_reporter_ignores_requested_event.md) | Sensor-DID report ignores the requested record and has no read-request guard | Needs investigation | Low | Sensor recording / read-out | 0x0467 vs 0x045F contents |
| [M210-EDR-33](bugs/M210-EDR-33_delta_v_valid_while_accel_failing.md) | Delta-V is reported as valid although the central accelerometer was Failing/Failed during the event | Needs investigation | Low | Sensor recording | Bytes 219-270 |
| [M210-EDR-36](bugs/M210-EDR-36_near_crash_signal_set_for_every_event.md) | NEAR_CRASH (SRS1_FD_10) is set at the start of every EDR event, including deployments and wake-ups that are never recorded | Needs investigation | Medium | ECU Tx signals | SRS1_FD_10 NEAR_CRASH and STS_CRASH; DID 0x0455 |
| [M210-EDR-39](bugs/M210-EDR-39_sts_crash_held_only_800ms.md) | STS_CRASH / DOOR_UNLOCK / CRASH_LOCATION return to 0 about 800 ms after the deployment decision | Needs investigation | Medium (code) | ECU Tx signals | SRS1_FD_10 STS_CRASH, SCM counter; SRS1_20 DOOR_UNLOCK |
| [M210-EDR-40](bugs/M210-EDR-40_apprise_edr_activation_bit_latched.md) | APPRISE build: the EDR activation bit can stay set after an event ends, so the next record inherits the previous crash type | Needs investigation | Medium (path exists), Low (frequency) | EDR inputs / Multi-Event | Byte 22 of the later record; supplier DIDs 0x0456 / 0x045C activation bytes |

## Bug details (symptom, trigger, expected, actual / suspected)

### Confirmed
#### [M210-EDR-01](bugs/M210-EDR-01_multi_event_near_deploy_near_event3_lost.md): Multi-event near crash -> deployment -> near crash: Event 3 is not recorded
- **Symptom (actual / suspected):** After Event 3 both DIDs still show Event 1 (EDR1) and Event 2 (EDR2). Event 3 is lost although its lifetime number was consumed, so the next recorded event skips a lifetime number. Because the raise is persistent, every later near crash (even > 5 s later, in later ignition cycles) is also discarded until a deployment overwrites EDR1.
- **Triggering conditions:** Three events with T0-to-T0 spacing < 5 s: near crash (not locked), deployment (locked), near crash.
- **Expected behaviour:** Customer EDR_Requirements (V3.4 = V2.7), multi-event table row 44 (Event1 = 0, Event2 = 1, Event3 = 0, all < 5 s): at the end of Event 3, EDR1 = Event 3 (Multi Event Number 3, Lifetime 3, not locked) and EDR2 = Event 2 (Multi Event Number 2, Lifetime 2, locked). Multi-event spec Oracles (multievent__Oracles r27): an unlocked record is replaced by the next event. No RstEdr SW requirement asks for a level-6 raise of a preceding event.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:63 `#define AB_DEPLOYMENT_EVENT_PRIO_LEV RSTEDR_EVENT_PRIO_LEV1`; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1973-1974 raise only when current priority == LEV1 and MultiEventNumber != 1; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1986-1991 previous event LEV7 -> LEV6 (LEV3 -> LEV2); written to rstedr_InternalData (:2003), to RstEdr_GlobalEventInfo (persistent synthesis, :2009) or to the capture buffer (:2015)
- **Confidence:** High. Code re-read in the main review (priority raise, slot search, bit values, overwrite strategy).
#### [M210-EDR-02](bugs/M210-EDR-02_adas_4hz_precrash_series_zeroed_after_previous_event.md): ADAS 4-per-second pre-crash series (-3 s..0 s) recorded as 0 when T0 follows a previous end of event by < 3.25 s
- **Symptom (actual / suspected):** If T0 of event N+1 comes less than 13 x 250 ms after the end of event N, only floor(dt / 0.25 s) (+1 at T0) samples exist; the older ones read 0. 0 is a valid code for these signals (no warning / system off), so the record shows a false history. The previous event can be any algorithm wake-up that reaches end of event, even one that is not recorded.
- **Triggering conditions:** Second event T0 less than 3.25 s after the end of the first event.
- **Expected behaviour:** V3.4 EDR_0455_045B r458-r478 AEB_WARNING_MSG at -3 S ... at 2 S (bytes 566-576), and the same 4/s rows for AES_WARNING, AES_SYS_STS (600-610), ESA_SYS_STS, LDW_LKA_SYS_STATE, LCF_SYS_STATE, SPA_SYS_STATE, ACC_SYS_STATE, RMS_MODE_STATE, LC_PATH_STATE, ELK oncoming/side/overtaking. Customer EDR_Requirements r7: CAN signals stored as per the DBC. Each record of a multi-event carries its own pre-crash history (customer multi-event tables).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:4704-4864 permanent capture (rstedr_PreEventDataBuffer, power-on cleared RstEdr/Implementation/Source/RstEdr.c:634-639): 100 ms, 200 ms, x00 ms, 500 ms, 1 s, 10 ms, 1 ms groups - no 250 ms group; RstEdr/Implementation/Source/RstEdr.c:5012-5016 -> RstEdr/Implementation/Source/RstEdr.c:4901-4909 the 250 ms capture runs only in the before-event state, into the active buffer; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3183-3258 rstedr_Capture250msPreEventAdditionalData (13 elements, index u8Index3sTo0s4PerSec, fill counter)
- **Confidence:** High. Code re-read in the main review (pre-event buffers, hand-over at end of event, report padding).

### Reproducible
#### [M210-EDR-03](bugs/M210-EDR-03_repeat_deployment_same_loops_not_locked.md): A deployment that re-fires loops already fired in the same reset cycle is not locked
- **Symptom (actual / suspected):** Second event: byte 22 bit 7 = 0 (unlocked); may be overwritten by later near crashes; if DV150 < 8 km/h no record at all.
- **Triggering conditions:** Two deployments of the same loops within one reset cycle.
- **Expected behaviour:** Customer EDR_Requirements r20 / r39: '1: deployment event' and the multi-event table row 49 (1,1,1 < 5 s): both records locked (lock status 1 / 1).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:3797-3805 lock/priority only if `0U == (u32EventLoopsDeployedTab & mask)`; RstEdr/Implementation/Source/RstEdr.c:1001 table cleared only in Init; RstEdr SW requirements AAUR_SW_RstEdr_239 / 240 / 241 (/item/4323111, 4322772, 4322921): 'for the first time in a Reset_Cycle'
- **Confidence:** Medium. Code re-read; SW requirements AAUR_SW_RstEdr_239/240/241 read.
#### [M210-EDR-04](bugs/M210-EDR-04_no_event_recorded_after_edr_clear_until_reset.md): After an EDR clear (NvM data reset) no event is recorded until the next ECU reset
- **Symptom (actual / suspected):** A crash after the clear, before any reset, leaves both DIDs at FF and creates no record.
- **Triggering conditions:** Crash in the same reset cycle as the EDR clear.
- **Expected behaviour:** RstEdr SW requirements (rstedr_requirements: 'for the remaining of the Reset_Cycle') define this as intended; no customer requirement states it. Test procedures that clear the EDR and crash in the same power cycle are affected.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:19951-19953 `bRstEdrLockedAfterNvMDataReset = TRUE`, `u8EventWakeUpSuspended |= ..._WHILE_NVM_DATA_RESET`; RstEdr/Implementation/Source/RstEdr.c:20056-20061 cleared only when the synthesis invalidation fails; never on success; RstEdr/Implementation/Source/RstEdr.c:2938-2940 T0 gate requires no suspension
- **Confidence:** High. Code re-read (NvM data reset state machine).
#### [M210-EDR-13](bugs/M210-EDR-13_first_post_t0_sample_discarded_can_series.md): First post-T0 sample of every CAN-C time series is discarded; 1-per-second elements jump 2 s from '0 s' to '+1 s'
- **Symptom (actual / suspected):** 1 s group (Gear, STS_HIGHBEAM/LOWBEAM, STS_TPMS_LED, STS_ABS/EBD/ESC/TCS, VCU_IGN_STS, EMERGENCY_BRAKING_REQ, ALERT_MESSAGE, VCU_DRV_ADV_MODE/_STS, RCW, LKA_HANDSOFF): '0 s' = value at T0 - d (d = 0..1 s), '+1 s' = value at T0 + 2 s - d, '+2 s' = T0 + 3 s - d, '+3 s' = T0 + 4 s - d; the value at T0 + 1 s - d is lost. 500 ms group: when d < 100 ms (about 1 crash in 5) all post values are one slot late.
- **Triggering conditions:** Any recorded event while the stepped signal is on the bus.
- **Expected behaviour:** V3.4 EDR_0455_045B sample labels: e.g. Gear r313-r321 'Gear at -5 S' ... 'at 3 S' (1/s, bytes 347-351); Vehicle Speed r33-r49 -5 S ... 3 S (2/s, bytes 30-63); VCU_DRV_ADV_MODE r964-r969 (1/s, -3 S ... 2 S, bytes 845-847). A sample labelled '+k s' holds the CAN value at about T0 + k s (within one sampling period).
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1477-1483 post indices reset at T0 (rstedr_InitializeEventAdditional, called from RstEdr/Implementation/Source/RstEdr.c:2361); RstEdr/Implementation/Source/RstEdr.c:5160-5196 post capture only on 250 ms / 500 ms / 1 s timer expiry; timer chain reset only at init (RstEdr/Implementation/Source/RstEdr.c:1004); RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:8036-8060 rstedr_FormatGearDataPostTimeZero: `u8EventDataReadIndex = 1U;` (same pattern in 65 formatters)
- **Confidence:** High (1 s group), Medium (500 ms / 250 ms groups). Code re-read (post-index reset at T0, timer-tick capture, 65 formatters starting at read index 1).
#### [M210-EDR-15](bugs/M210-EDR-15_sts_crash_pib_samples_after_5s_always_zero.md): STS_CRASH and PIB_ACTIVE samples from +5.5 s to +9 s are never captured and always read 0
- **Symptom (actual / suspected):** With STS_CRASH or PIB_ACTIVE = 1 on CAN after +5 s, the record shows 0 for +5.5 s ... +9 s.
- **Triggering conditions:** Any recorded event with the series' source = 1 after T0 + 5 s.
- **Expected behaviour:** V3.4 r995-r1015 'STS_CRASH at -1 S' ... 'at 9 S' (bytes 858-860); r1033-r1053 'PIB_ACTIVE at -1 S' ... 'at 9.0 S' (bytes 866-868). Conflict: customer EDR_Requirements r9 'CompletionStatus will be updated as 1 after 5 seconds from T0'.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:2209-2252 completion: all tables complete and > 10000 ticks; UNECE/NHTSA complete at 10200 ticks (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:184-197); RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1878-1887 rstedr_SetAdditionalCompleteFileRecorded is empty (nothing holds the record open for +9 s data); RstEdr/Implementation/Source/RstEdr.c:3287-3314 capture only in state CAPTURE; after the write the state is RECORD
- **Confidence:** High. Code re-read (completion rule, after-end-of-event state machine, empty additional-completion hook, formatter padding).
#### [M210-EDR-18](bugs/M210-EDR-18_occupant_ecall_counts_and_zone_hardcoded.md): Occupant / e-call counts, seat position zone and OCS class at T0 are hard-coded FF although SRS1_FD_10 transmits them
- **Symptom (actual / suspected):** In every recorded event: 853 = FF, 854 = FF, 856-857 = FF FF (4-bit fields 0xF, outside 0..7).
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** V3.4 r984 (853), r985 (854), r987-r990 (855), r991-r994 (856-857, ranges 0..7) 'at T0'. Customer EDR_Requirements r5: FF only when no event is recorded.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16451-16458 rstedr_ReportOCSPassengerTypeClassification -> 0xFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16493-16497 rstedr_ReportSeatPositionZone -> 0xFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16578-16586 rstedr_ReportEcallCNT -> 0xFF 0xFF
- **Confidence:** High (code). Code re-read (report functions write constants).
#### [M210-EDR-24](bugs/M210-EDR-24_deployment_time_reported_in_half_ms_ticks.md): Deployment times are reported in 0.5 ms ticks in a field the customer defines in 1 ms (values doubled)
- **Symptom (actual / suspected):** A loop fired 15 ms after T0 is stored as 0x001E (30 ms); loops fired after 127.5 ms exceed the documented 255 ms range.
- **Triggering conditions:** Any deployment.
- **Expected behaviour:** V3.4 r153-r176 '<loop> - Deployment Time': 2 bytes, resolution 1, unit ms, range 0..255 (bytes 165-212). Framework M210 edr_config: scaling 1.0 ms for the deployment-time elements.
- **Evidence:** RstEdr/Config/Behaviour/RstEdr_Behvr.arxml:78 `<PERIOD>5.0E-4</PERIOD>`; AAUR_SW_RstEdr_201 'increment ... every 0.5 ms'; RstEdr/Implementation/Source/RstEdr.c:3817 `au16TimetoSendCmdTab[u8indexTmp] = u16TimeFromTime0;`; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6704 `deployment_time = ...au16TimetoSendCmdTab[squib_position];` -> RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6719 `RSTEDR_UTI_SWAP_AND_COPY16` (no conversion)
- **Confidence:** High. Code re-read (capture, Mahindra report, platform formatter); RstEdr_MainFunction period read from the ARXML.
#### [M210-EDR-25](bugs/M210-EDR-25_delta_v_samples_not_aligned_to_t0.md): Delta-V 10 ms samples follow a free-running tick: the '0 ms' sample is taken 0.5-10 ms after T0
- **Symptom (actual / suspected):** For identical crash curves the delta-V series varies run to run; '0 ms' is not 0 for a hard pulse (several km/h for a 20-30 g pulse).
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** V3.4 r204-r229 'Delta Velocity, longitudinal at 0 mS' ... 'at 250 mS' (bytes 219-244), lateral r230-r255 (245-270), 1 km/h; AAUR_SW_RstEdr_262: every 10 ms relative to T0.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:6386-6419 samples only when the 10 ms flag is set; RstEdr/Implementation/Source/RstEdr.c:6202-6206 sample = DeltaVel + adjust; RstEdr/Implementation/Source/RstEdr.c:4563-4564 adjust taken at T0 (accel at T0 - DeltaVel at T0); timer chain reset only at init (RstEdr/Implementation/Source/RstEdr.c:1004)
- **Confidence:** Medium. Code re-read (10 ms capture, delta-V sample, T0 adjust, timer chain reset only at init).

### Potential
#### [M210-EDR-05](bugs/M210-EDR-05_crash_during_edr_readout_not_recorded.md): A crash during an EDR read-out ($22 0455/045B in progress) is not recorded or gets a late T0
- **Symptom (actual / suspected):** The crash is lost, or captured late (T0 when the suspension ends, while the algorithm is still active).
- **Triggering conditions:** TriggerCrash() while a $22 04 55 transfer is in progress.
- **Expected behaviour:** No customer or RstEdr requirement allows ignoring a crash during a diagnostic read (the SW requirement only rejects read requests during capture).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:7328 `u8EventWakeUpSuspended |= RSTEDR_EVENT_DETECT_SUSPEND_WHILE_READ`; RstEdr/Implementation/Source/RstEdr.c:7480-7536 cleared at conversion end or after RSTEDR_DIAGNOSTIC_TIME_LIMIT (64000U, RstEdr_Intl.h:103 '32 seconds'); RstEdr/Implementation/Source/RstEdr.c:2938-2940 T0 only if no suspension
- **Confidence:** Medium. Code re-read (read-out state machine, T0 gate).
#### [M210-EDR-06](bugs/M210-EDR-06_plant_mode_understrike_record_never_replaced.md): Plant-mode understrike record (unlocked, priority 1) is never replaced by later near crashes
- **Symptom (actual / suspected):** After leaving plant mode, owner-mode near crashes rotate only through the other record; the plant-mode record stays.
- **Triggering conditions:** Plant-mode understrike event, then two owner-mode near crashes > 5 s apart.
- **Expected behaviour:** Customer EDR_Requirements r8: a near crash is recorded but not locked, i.e. it can be overwritten; overwrite rows r23-r26: the oldest unlocked record is replaced.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1542-1555 understrike: normal mode -> LOCKED|LEV1, else `|= RSTEDR_EVENT_PRIO_LEV1` (unlocked); RstEdr/Implementation/Source/RstEdr.c:3458-3499 / :3404 LEV7 events search EMPTY and LEV7 only
- **Confidence:** Medium. Code re-read (understrike priority, slot search).
#### [M210-EDR-07](bugs/M210-EDR-07_exactly_5s_classified_as_multi_event.md): Time between events of exactly 5.000 s is classified as multi-event
- **Symptom (actual / suspected):** dT = 5.000 s gives MultiEventNumber 2 and TimeBtwEvents 0x2710 instead of 1 and 0xFFFF.
- **Triggering conditions:** Second T0 exactly 10000 ticks after the first.
- **Expected behaviour:** RstEdr SW requirement /item/4322953: 'greater than or equal to 5 s ... reset the Multiple_Event_Counter to 1'.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:4357 `if(u16PreviousMultiEventTimer <= RSTEDR_MULT_EVENT_MAX_TIME)`; RstEdr_Intl.h:92 10000U (0.5 ms ticks)
- **Confidence:** Low. Code re-read; requirement AAUR /item/4322953 read.
#### [M210-EDR-12](bugs/M210-EDR-12_multi_event_number_wraps_at_255.md): MultiEventNumber wraps from 255 to 0 in very long event chains
- **Symptom (actual / suspected):** The 256th chained event reports 0.
- **Triggering conditions:** 256 events, each within 5 s of the previous.
- **Expected behaviour:** V3.4 r13 MultiEventNumber range 0..255.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:4364 `u8PreviousMultiEventNumber + 1U` (no saturation)
- **Confidence:** Low. Code re-read.
#### [M210-EDR-14](bugs/M210-EDR-14_one_second_elements_have_no_t0_sample.md): 1-per-second CAN-C elements never get a T0 sample, so '0 s' can be up to 1 s old
- **Symptom (actual / suspected):** A change in the last second before the crash is missed with probability d / 1 s.
- **Triggering conditions:** Signal change less than 1 s before T0.
- **Expected behaviour:** V3.4 r318 'Gear at 0 S' (byte 349 bits 3..0), r867 'STS_HIGHBEAM at 0 S' etc.: the value at T0.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:1691-1708 rstedr_GetTimeZeroAdditionalData refreshes only 500 ms and 250 ms groups; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3554-3690 rstedr_Capture1sPreEventAdditionalData (1 s tick only); snapshot values from the same capture
- **Confidence:** Medium. Code re-read (T0 capture covers only the 500 ms and 250 ms groups).
#### [M210-EDR-16](bugs/M210-EDR-16_t0_sample_overwritten_when_record_written_before_first_tick.md): If the record is written before the first post-T0 tick (battery cut-off), the '0 s' sample is overwritten with the not-captured value
- **Symptom (actual / suspected):** Battery cut within one tick period after T0: VehSpd '0 s' (bytes 50-51) = 0x7FFF while VehSpd at T0 (bytes 4-5) is correct; Gear '0 s' = 0; other '0 s' slots = their not-captured value.
- **Triggering conditions:** Supply off at T0 (+ 0..50 ms) during a deployment crash.
- **Expected behaviour:** Customer EDR_Requirements r10 / r53-r57: in a battery cut-off crash the data up to 200 ms are valid (200 ms CompletionStatus); the T0 values must be kept.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5356 `VehSpdLgt_data[10] = ...VehSpdLgtAtTimeZero;`; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5459 `u8DestMaxNb = RSTEDR_NOF_SAMPLES_5SEC_TO_0SEC_2PERSEC + (pEventDataReadBuffer->u8Index0sTo3s2PerSec - 1U);` (index 0 -> 10); padding loop from index 10 (same pattern in about 60 formatters); RstEdr/Implementation/Source/RstEdr.c:3090-3095 power-down forces end of event; RstEdr/Implementation/Source/RstEdr.c:1350-1385 record written immediately
- **Confidence:** Medium. Code re-read (unsigned index arithmetic in the post-T0 formatters).
#### [M210-EDR-17](bugs/M210-EDR-17_lka_handsoff_value_not_masked.md): LKA_HANDSOFF_DISPLAY_WARNING samples are not masked to 1 bit; raw 2 or 3 corrupts neighbouring samples
- **Symptom (actual / suspected):** Raw 2 in every sample -> byte 658 = 0xF8 (false 'warning' bits, shifted by one); raw 3 -> 0xFC.
- **Triggering conditions:** Any recorded event with the signal at raw 2 or 3.
- **Expected behaviour:** V3.4 r629-r634: one bit per sample, 6 samples in byte 658 bits 7..2; reserved/out-of-range values: consume (on-fail matrix) - in any case the neighbouring samples must not change.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:11568 `Dst[buffer_idx] |= (uint8)((uint32) lkaHandsoffDispWarn_data[data_idx] << shift_bit_idx);` (no mask, no `&= 0xFC`); Compare RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:13915 / 13920 (STS_HIGHBEAM: masked, reserved bits cleared)
- **Confidence:** High (code), Medium (trigger). Code re-read.
#### [M210-EDR-26](bugs/M210-EDR-26_loop_fired_in_t0_cycle_reported_not_deployed.md): A loop fired in the T0 cycle (time stamp 0) is reported 'not deployed' in the deployment-status bits
- **Symptom (actual / suspected):** Time word 0x0000 with status bit 0 for the same loop.
- **Triggering conditions:** A deployment command in the same 0.5 ms cycle that opens the event.
- **Expected behaviour:** V3.4 r177 '... Deployment Status' ENUM DEPLOY_NOT (1 = deployed), bytes 213-215; consistent with the time word.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:7875 `if ((deployment_time != 0U) && (deployment_time != RSTEDR_U16_INTERNAL_NOT_DEPLOYED))`; RstEdr/Implementation/Source/RstEdr.c:2278-2283 times initialised to 0xFFFF ('0 can be a valid one'); RstEdr/Implementation/Source/RstEdr.c:4481-4482 stamps taken at T0
- **Confidence:** Medium (code), Low (trigger). Code re-read (status report condition, time-table init).
#### [M210-EDR-27](bugs/M210-EDR-27_sensor_did_failing_samples_stored_as_ff.md): 500 us sensor DIDs store 0xFF for samples with Qf 'Failing', while delta-V uses the same samples
- **Symptom (actual / suspected):** Isolated 0xFF holes in the crash part of the sensor DIDs when a non-fatal sensor flag is present.
- **Triggering conditions:** Qf Failing samples inside the capture window.
- **Expected behaviour:** V3.4 EDR Sensor Data: no rule for degraded samples; '0xFF shall be stored default' only for NA channels.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:2318-2327 `if(sensor_port.Qf == QfAlv1_Valid) ... else *output_ptr = RSTEDR_DATA_NOT_CAPTURED;`; OpsSgPoolMgr/Implementation/Source/OpsSgPoolMgr.c:1249-1250 Failing keeps the real data
- **Confidence:** Low. Code re-read.
#### [M210-EDR-28](bugs/M210-EDR-28_delta_v_and_battery_voltage_truncated.md): Delta-V and battery voltage are truncated instead of rounded (bias toward zero)
- **Symptom (actual / suspected):** Delta-V up to -1 km/h low in magnitude (+0.27 % gain error); battery voltage up to 0.1 V low.
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** V3.4 r204-r259 delta-V 1 km/h; r4 battery voltage 0.1 V. No rounding rule stated.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17789 / 17805 `/ RSTEDR_CONVERT_DELTA_V_DIVISOR` (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:1918 113U); RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:4487 battery `/ 4`
- **Confidence:** Low. Code re-read.
#### [M210-EDR-34](bugs/M210-EDR-34_200ms_completion_bit_set_before_200ms.md): '200 ms CompletionStatus' is set at end of event + 30 ms, i.e. before 200 ms for short events
- **Symptom (actual / suspected):** Short near crash (Tend 60 ms) with battery cut at T0 + 150 ms: byte 216 = 0x40 although capture stopped at 150 ms.
- **Triggering conditions:** Supply cut between Tend + 30 ms and T0 + 200 ms.
- **Expected behaviour:** Customer EDR_Requirements r10: '200ms CompletionStatus will be updated as 1 after 200 mseconds. If this bit is set the data for 200ms from T0 is valid.'; r53-r55 (battery cut-off crash). V3.4 r202: byte 216 bit 6.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:2328 OTHER delay = 400 ticks (RstEdr/Implementation/Cfg/RstEdr_Cfg.h:217-219); RstEdr/Implementation/Source/RstEdr.c:2893 + RstEdr/Implementation/Source/RstEdr.c:2786-2812 reassessed to min(400, Tend + 60); RstEdr/Implementation/Source/RstEdr.c:2180-2184 flag set when time > delay; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6814 bit 6 = OTHER_COMPLETE << 3
- **Confidence:** Medium. Code re-read (delay initialisation 400 ticks, reassessment to Tend + 60 ticks, report bit 6).
#### [M210-EDR-35](bugs/M210-EDR-35_sts_crash_pulse_missing_from_edr_series.md): STS_CRASH sent for 800 ms on SRS1_FD_10 can be missing entirely from the EDR STS_CRASH series
- **Symptom (actual / suspected):** In roughly a third of crashes (T0 phase dependent) all 21 STS_CRASH bits are 0 although STS_CRASH = 1 was transmitted.
- **Triggering conditions:** Any deployment.
- **Expected behaviour:** V3.4 r995-r1015 STS_CRASH -1 S ... 9 S (bytes 858-860). Supplier bench test 4: 'Values of CAN message shall match with EDR recorded value'.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:16736-16744 STS_CRASH post-T0 formatter starts at read index 1; RstEdr/Implementation/Source/RstEdr.c:5182-5185 post capture on the 500 ms tick only; EnsMgr/Implementation/Source/EnsMgr.c:529-536 crash outputs cleared after 1600 x 0.5 ms
- **Confidence:** Medium. Mechanism re-read: post-T0 index 0 discarded (M210-EDR-13), 800 ms window in EnsMgr (M210-EDR-39).
#### [M210-EDR-37](bugs/M210-EDR-37_sts_crash_gating_differs_from_edr_crash_type.md): STS_CRASH / DOOR_UNLOCK / ENS use different gating from the EDR crash type (front needs SEV2 and arming)
- **Symptom (actual / suspected):** Pretensioner-only frontal crash: byte 22 = 0x81 (front, locked) but STS_CRASH = 0, DOOR_UNLOCK = 0, no ENS deploy pulse.
- **Triggering conditions:** Pretensioner-only frontal deployment.
- **Expected behaviour:** Customer EDR_Requirements r8 (only a near crash suppresses STS_CRASH/Door unlock) and r19-r20 (deployment event vs near crash); EV multi-event spec r906 (pretensioner-only deployment STS_CRASH = 1).
- **Evidence:** EnsMgr/Implementation/Source/EnsMgr.c:210-215 EDR crash type at SEV1 in normal mode; EnsMgr/Implementation/Source/EnsMgr.c:220-225 CAN bit needs EcallStartedAtLeastOnce FALSE, arming != NOT_CLOSED and (front) SEV2; EnsMgr/Implementation/Source/EnsMgr.c:589-598 STS_CRASH / unlock follow only the CAN bit; EnsMgr_PBCfg.h:123/126 thresholds 0x0002 / 0x0004
- **Confidence:** Medium (pretensioner-only front), Low (arming cases). Code re-read in EnsMgr (EDR bit at SEV1, CAN bit needs arming + SEV2 for front).
#### [M210-EDR-38](bugs/M210-EDR-38_crash_location_first_algorithm_wins.md): CRASH_LOCATION reports the first algorithm to reach its threshold, not the highest-priority direction
- **Symptom (actual / suspected):** Oblique crash where the side algorithm decides first: CRASH_LOCATION = 3 (left) although front airbags fire.
- **Triggering conditions:** Two directions within one 800 ms window.
- **Expected behaviour:** Project knowledge base (.github/agents/agent_sc3.md): priority Front > Left > Right > Rollover > Rear > Understrike. Not in the customer files provided.
- **Evidence:** EnsMgr/Implementation/Source/EnsMgr.c:220-225 CAN bit only while EcallStartedAtLeastOnce == FALSE; EnsMgr/Implementation/Source/EnsMgr.c:262-266 evaluation order; EnsMgr/Implementation/Source/EnsMgr.c:214 EDR byte is an OR
- **Confidence:** Medium (code), Low (requirement). Code re-read (only one CAN direction bit per 800 ms window).

### Needs investigation
#### [M210-EDR-08](bugs/M210-EDR-08_synthesis_saved_only_on_orderly_power_down.md): Record lock, priority, lifetime and multi-event data are saved only by an orderly power-down
- **Symptom (actual / suspected):** After a deployment and an abrupt reset (e.g. $11 01 hard reset, or a supply cut without the shutdown sequence), the DIDs may read FF and the next event overwrites the slot.
- **Triggering conditions:** Reset without the RstEdr power-down sequence after a recorded event.
- **Expected behaviour:** Recorded and locked events survive any reset (customer EDR_Requirements locked rows r24-r30; multi-event spec).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:3309-3313 record write updates only the RAM synthesis; RstEdr/Implementation/Source/RstEdr.c:1453-1470 / :1511-1514 NvM_SetRamBlockStatus only in power-down; RstEdr/Implementation/Source/RstEdr.c:1007-1012 init restores priorities from the synthesis
- **Confidence:** Medium. Code re-read (synthesis block handling, init, read-out decision).
#### [M210-EDR-09](bugs/M210-EDR-09_no_minimum_separation_between_events.md): Two impacts closer than 500 ms are split into two records as soon as the first event ends
- **Symptom (actual / suspected):** Near crash + deployment 300-500 ms later gives two records (near crash unlocked and raised, deployment locked, MEN 2).
- **Triggering conditions:** Second T0 within 500 ms of the first.
- **Expected behaviour:** Customer EDR_Requirements r32 'Multi Event Scenarios (time between events > 500 ms)'; behaviour for <= 500 ms is not written (multi-event open points AMB-01/06/07/13).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:3087-3095 end of event from activity; RstEdr/Implementation/Source/RstEdr.c:2938-2951 next T0; RstEdr/Implementation/Source/RstEdr.c:4357 only the 5 s upper bound
- **Confidence:** Medium. Reviewer evidence; end-of-event and T0 paths re-read.
#### [M210-EDR-10](bugs/M210-EDR-10_near_and_lock_bits_from_different_sources.md): Crash byte can show 'near crash' and 'locked' together (0xC0) for a deployment EnsMgr does not classify
- **Symptom (actual / suspected):** Byte 22 = 0xC0 for a rollover deployment.
- **Triggering conditions:** Deployment decided by an algorithm EnsMgr does not evaluate.
- **Expected behaviour:** V3.4 r14-r21: bit 5 Rollover (reserved for now), bit 6 Near crash, bit 7 lock; a deployment is not a near crash.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5018-5031 near bit when `(location & 0x1F) == 0`, lock bit when priority == 0xC0; EnsMgr/Implementation/Source/EnsMgr.c:262-266 severities read for LISA, ALIS L/R, RITA, understrike only
- **Confidence:** Low. Code re-read (crash byte report, final priority); EnsMgr inputs re-read.
#### [M210-EDR-11](bugs/M210-EDR-11_power_down_request_is_one_way.md): RstEdr power-down is one-way: an aborted shutdown leaves EDR inactive until reset
- **Symptom (actual / suspected):** After a brief under-voltage dip that triggers power-down but no reset, a following crash is not recorded.
- **Triggering conditions:** Power-down request without a following reset.
- **Expected behaviour:** Customer EDR_Requirements r9: CompletionStatus 1 after 5 s if battery available; events must be recorded whenever the ECU operates.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:2020-2024 request latched; RstEdr/Implementation/Source/RstEdr.c:960 cleared only in Init; RstEdr/Implementation/Source/RstEdr.c:2940 new events blocked; RstEdr/Implementation/Source/RstEdr.c:3090-3095 forced end of event
- **Confidence:** Low. Reviewer evidence; power-down latch re-read.
#### [M210-EDR-19](bugs/M210-EDR-19_one_bit_packers_or_into_unzeroed_buffer.md): 1-bit multi-sample elements are OR-ed into the DID buffer without clearing it first
- **Symptom (actual / suspected):** With all signals 0 and a near crash, these bytes may read non-zero (e.g. STS_CRASH bits set without a crash command).
- **Triggering conditions:** Read-out of any record.
- **Expected behaviour:** V3.4 bit definitions for bytes 658, 756, 800, 801, 816, 817, 820, 827, 858-860, 866-869: 0 for a 0 sample.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:14077 (STS_LOWBEAM) `Dst[buffer_idx] |= ...` with no prior `Dst[buffer_idx] = 0`; same at 13915, 14549, 14711, 15043, 15372, 11568, 13431, 16635, 16964, 17130; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17590-17638 RstEdr_CopyGetAdditionalDataElement passes DstPtr through unchanged
- **Confidence:** Medium. Code re-read (packers use |= without a prior assignment; dispatcher passes the caller's buffer).
#### [M210-EDR-20](bugs/M210-EDR-20_not_captured_samples_look_like_valid_data.md): Pre-crash samples that were never captured are reported as valid-looking values (0, 0x7FFF, 0xFFFF) instead of a marked code
- **Symptom (actual / suspected):** A crash 2 s after start-up records 'no warning / inactive / 511.98 km/h' for the first 3 s.
- **Triggering conditions:** Crash less than 5 s after RstEdr proveout.
- **Expected behaviour:** Customer EDR_Requirements r5 defines FF only for 'no event'; no rule exists for samples before EDR start. A reader must be able to tell missing samples from data.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:5391 VehSpd 0x7FFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:9725 ADAS 0U; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6201 ABS 0; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:7069 tyres 0xFF (reviewer list of about 25 constants)
- **Confidence:** Medium. Reviewer evidence; padding constants spot-checked (AEB 0U, VehSpd 0x7FFF).
#### [M210-EDR-21](bugs/M210-EDR-21_event_date_year_offset_not_applied.md): Event date: year copied raw from CAN although the code comment says a +20 offset is needed
- **Symptom (actual / suspected):** Year 2026 (raw 6) is recorded as 6; a decoder with a 2000 base shows 2006.
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** V3.4 r11 Event Date CUSTOM_DATE_FORMAT_2 'DDMMYYYY' (year base not stated in the extract); DBC CLOCK_YEAR (1, 2020).
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:4831-4835 comment 'factor of 20U is needed', then `year_data = pEventDataReadBuffer->aHpcc1Year;` and `<< 2`
- **Confidence:** Low. Code re-read.
#### [M210-EDR-22](bugs/M210-EDR-22_rte_limits_narrower_than_dbc_raw_range.md): RTE type limits are narrower than the DBC raw range; if CanMgr saturates to them, recorded values are wrong
- **Symptom (actual / suspected):** Raw values beyond the limits (forward motor speed, positive ADAS angles, invalid codes 0xFFFF / 0x7FFF) are clipped.
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** Customer EDR_Requirements r7 (as per DBC, incl. on-fail); invalid codes consumed (on-fail matrix).
- **Evidence:** RstEdr/Implementation/Cfg/Rte_RstEdr_Type.h:137-138 MotorSpeed_LowerLimit / _UpperLimit; RstEdr passes .Data unchanged (RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6099)
- **Confidence:** Low. Reviewer evidence (Rte_RstEdr_Type.h limits; W610 bench sheet).
#### [M210-EDR-23](bugs/M210-EDR-23_onfail_values_depend_on_canmgr_rstedr_ignores_qf.md): On-fail recording depends entirely on CanMgr: RstEdr records raw port values (and 0 for a frame never received)
- **Symptom (actual / suspected):** If CanMgr does not substitute (or uses a different value), the record differs from the on-fail rules. A frame that never arrives after power-up is recorded as 0 (e.g. VEHICLE_SPEED 0x0000 instead of the DBC default 0xFFFE).
- **Triggering conditions:** Each on-fail class before, during and after T0.
- **Expected behaviour:** Customer on-fail rules (framework docs/project_documents/onfail_documents): NA / MTO / MCF / UV-OV -> last valid value; invalid -> consume; SNR / VC -> default value. Customer EDR_Requirements r7.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:3183-3690 (captures store the raw port value); RstEdr/Implementation/Cfg/Rte_RstEdr.h:397-470 init values 0; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:6086-6100 motor speed: Qf NotCaptured/NotAvailable -> 0xFFFF; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:8424-8432 IMU Qf handling
- **Confidence:** Medium. Code re-read for the Mahindra elements (no Qf use except motor speed and IMU); CanMgr not in the tree.
#### [M210-EDR-29](bugs/M210-EDR-29_sensor_did_sample_alignment_half_ms.md): 500 us sensor DIDs: the sample at byte 20 may be T0 + 0.5 ms instead of T0 (one-sample shift)
- **Symptom (actual / suspected):** A step applied at a known instant appears at byte 19 instead of byte 20.
- **Triggering conditions:** Any recorded event.
- **Expected behaviour:** V3.4 EDR Sensor Data r49 'Sensor Data at -10ms' byte 0 ... r69 'at 0ms' byte 20 ... 250 ms byte 520.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:23545-23615 RstEdr_ReportSensorsDataMah / rstedr_FormatSensorDataPreTime ('skip the oldest pre event sample'); RstEdr/Implementation/Source/RstEdr.c:2936-2947 pre capture before event detection in the T0 cycle (reviewer)
- **Confidence:** Medium. Reviewer evidence (pre-buffer captured before event detection in the T0 cycle); length 521 bytes confirmed against V3.4.
#### [M210-EDR-30](bugs/M210-EDR-30_event_timer_wraps_after_32s.md): The u16 event timer never stops and wraps after 32.768 s, re-opening the max-delta-V window in very long events
- **Symptom (actual / suspected):** If an event stays open > 32.8 s, max delta-V / time to max / late deployment stamps take wrapped values.
- **Triggering conditions:** Event open longer than 32.8 s.
- **Expected behaviour:** V3.4 r256-r259 time to max delta-V 0..300 ms; AAUR_SW_RstEdr_201 'for 5 s after the T0'.
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:2982 and RstEdr/Implementation/Source/RstEdr.c:3291 unconditional increment; RstEdr/Implementation/Source/RstEdr.c:6070 max-delta-V window `<= u16MaxDeltaVCaptureCompleteDelay`
- **Confidence:** Low. Reviewer evidence.
#### [M210-EDR-31](bugs/M210-EDR-31_lateral_sign_convention_inconsistent.md): Lateral sign convention differs between delta-V (inverted) and lateral acceleration data (not inverted)
- **Symptom (actual / suspected):** A left side impact gives positive DeltaVLat but negative lateral acceleration in the same record.
- **Triggering conditions:** Any side impact.
- **Expected behaviour:** No customer sign convention in the sources; framework rule: onboard data on the AUTOSAR axis (left Y-, right Y+).
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17829-17836 `temp_calc_offset_value = (uint8)((uint32)(-tmp_calc_deltav) ...)` for lateral IDs
- **Confidence:** Low. Code re-read (Mahindra delta-V conversion).
#### [M210-EDR-32](bugs/M210-EDR-32_sensor_did_reporter_ignores_requested_event.md): Sensor-DID report ignores the requested record and has no read-request guard
- **Symptom (actual / suspected):** Reading 0x0467 right after 0x045F without a record-2 read returns record 1's data (or a reused buffer).
- **Triggering conditions:** Sensor-DID reads in different orders.
- **Expected behaviour:** Record-1 and record-2 sensor DIDs (e.g. 0x045F / 0x0467) return their own record.
- **Evidence:** RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:23545-23568 RequestedEventID unused; reads u8ReadEventBufferIndex; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17609 the additional-element dispatcher checks `cRequestedEventId == RecordRequestedToRead`
- **Confidence:** Low. Code re-read (unused RequestedEventID parameter).
#### [M210-EDR-33](bugs/M210-EDR-33_delta_v_valid_while_accel_failing.md): Delta-V is reported as valid although the central accelerometer was Failing/Failed during the event
- **Symptom (actual / suspected):** A transient sensor fault inside the crash window gives a too-small delta-V reported as valid.
- **Triggering conditions:** Central sensor Failing during the crash.
- **Expected behaviour:** No explicit customer rule; an invalid code (0xFE) exists in the code base.
- **Evidence:** OpsSgPoolMgr/Implementation/Source/OpsSgPoolMgr.c:878-909 data 0 while Failing; RstEdr/Implementation/Source/RstEdr.c:5420-5447 integration ignores Qf, invalid count kept; RstEdr/Implementation/Cfg/RstEdr_Lcfg.c:17846-17869 formatter ignores the count
- **Confidence:** Low. Reviewer evidence (OpsSgPoolMgr substitution, unused invalid-sample count).
#### [M210-EDR-36](bugs/M210-EDR-36_near_crash_signal_set_for_every_event.md): NEAR_CRASH (SRS1_FD_10) is set at the start of every EDR event, including deployments and wake-ups that are never recorded
- **Symptom (actual / suspected):** (a) Deployment: NEAR_CRASH = 1 from T0 for 800 ms together with STS_CRASH = 1. (b) Wake-up below 8 km/h: NEAR_CRASH = 1 for 800 ms, both DIDs stay FF.
- **Triggering conditions:** (a) frontal deployment; (b) low-level pulse that wakes the algorithm but stays below 8 km/h DV150.
- **Expected behaviour:** Customer EDR_Requirements r8 (near crash: below deployable threshold, STS_CRASH/Door_UNLOCK not sent). The semantics of NEAR_CRASH itself are not written; the DBC labels 1 'Crash', 0 'No Near Crash'. EV multi-event test spec (multievent__Export r41/r906): deployment event NEAR_CRASH = 0.
- **Evidence:** EnsMgr/Implementation/Source/EnsMgr.c:287-298 NearCrashStatus = TRUE when the EDR event is active and EcallStartedAtLeastOnce == FALSE; EnsMgr/Implementation/Source/EnsMgr.c:299-313 held until 1600 x 0.5 ms; EnsMgr/Implementation/Source/EnsMgr.c:601 `ENSMGR_UPDATE_NEAR_CRASH_STATUS(...)` to CAN; RstEdr/Implementation/Source/RstEdr.c:1802-1808 RstEdr_GetEventStatus TRUE in the on-event sub-state, whatever the priority
- **Confidence:** Medium. Code re-read in EnsMgr (near-crash logic, CAN update).
#### [M210-EDR-39](bugs/M210-EDR-39_sts_crash_held_only_800ms.md): STS_CRASH / DOOR_UNLOCK / CRASH_LOCATION return to 0 about 800 ms after the deployment decision
- **Symptom (actual / suspected):** STS_CRASH = 1 for 800 ms +/- 25 ms.
- **Triggering conditions:** Any deployment.
- **Expected behaviour:** DBC gives no duration; the EDR series runs to +9 s (V3.4 r1015); EV multi-event spec r46 '+0.5..+9.0 s = 1 (held - AMB-22)'.
- **Evidence:** EnsMgr/Implementation/Source/EnsMgr.c:529-536 window end clears EcallStartedAtLeastOnce and EnsAlgoSevStatusForCAN; EnsMgr_PBCfg.h:64 1600U
- **Confidence:** Medium (code). Code re-read (EnsMgr output window).
#### [M210-EDR-40](bugs/M210-EDR-40_apprise_edr_activation_bit_latched.md): APPRISE build: the EDR activation bit can stay set after an event ends, so the next record inherits the previous crash type
- **Symptom (actual / suspected):** Front deployment, then a near crash later in the same ignition cycle: record 2 byte 22 = 0x01 (front) instead of 0x40; supplier DID 0x0456/0x045C shows the EDR activation bit at T0. Side effects outside EDR: crash-manager data hold and deployment-manager wake-up handling (reviewer note).
- **Triggering conditions:** An event that ends while the RstEdr 20 ms delta-V window is still above threshold.
- **Expected behaviour:** Each record carries its own event's crash type (customer multi-event tables, EDR_Requirements r19-r20).
- **Evidence:** RstEdr/Implementation/Source/RstEdr.c:2684-2733 rstedr_ManageEndOfEvent20mSDVBuffer -> RstEdr/Implementation/Source/RstEdr.c:2731 RSTEDR_SET_OPSCSHMGR_EDR_ACTIVATION_ST (only call); RstEdr/Implementation/Source/RstEdr.c:3087-3101 called only in the 'event not ended' branch; RstEdr/Implementation/Cfg/RstEdr_Cfg.h:126-127 APPRISE T0/Tend mask without RSTEDR_EDR_ACTIVE_MASK; OpsCrash/OpsCshMgr/Implementation/Source/OpsCshMgr.c:1900-1911 bit set/cleared only by this call
- **Confidence:** Medium (path exists), Low (frequency). Code re-read (set/clear call site, APPRISE end mask, OpsCshMgr bit handling, EnsMgr reset condition).


## Findings withdrawn after verification
| Finding | Why withdrawn |
|---|---|
| Delivered executables built with 3 EDR records | The `Builds\SWBuild` maps (dated 2026-10-28) show 3 record wrappers, but the M210 release P31 map (`ProjectInformation\Release\Mahindra_M210_P31\Build\Application_APPRISe.map`) has `rstedr_capEdrWriteReq` 8 bytes and `RstEdr_GlobalEventInfo` 36 bytes: 2 records, as in the source. Kept as a set-up check (COMMON_TEST_SETUP). |
| STS_LOWBEAM / STS_EBD packing differs from the customer layout | True against V2.7 only; V3.4 (V2.8 change) gives both their own byte, as the code does. |
| SRS ECU Status at byte 69 instead of 879 | V3.4 (V2.8 change) moved it to byte 69, matching the code. |
| Sensor DIDs 521 instead of 520 bytes | V3.4 change log: "250ms sample is added at the bottom and it increased the number of bytes to 521". The alignment question remains as M210-EDR-29. |
| CompletionStatus in bits 7/6 instead of 0/1 | True against V2.7 only; V3.4 defines bits 7 / 6, as the code does. |

## Test-side findings (framework, not ECU)
| # | Finding | Effect | Action / status |
|---|---|---|---|
| T1 | `projects/M210/config/edr_config.py` defined CompletionStatus / 200 ms CompletionStatus as bits 220.0 / 220.1 (V2.7). V3.4 and the ECU use bits 7 / 6. | Framework tests read the wrong bits and would fail a correct ECU. | **Fixed 2026-10-28:** 220.7 / 220.6. |
| T2 | The same file placed "SRS ECU Status at T0" at byte 883 (V2.7 879, shared with SRS_OCS_PASS_CLASS_FAULT_STS). V3.4: byte 69 (framework 73). | Wrong element decoded at 883; byte 69 not checked. | **Fixed 2026-10-28:** byte 73; SRS_OCS_PASS_CLASS_FAULT_STS (V3.4 byte 879, ECU element 1096) now also EV. |
| T3 | The framework holds M210 "Customer Diag Spec" V2.7 only; the common EV folder has V3.4, which the ECU follows. | Test design from V2.7 diverges from the implemented layout. | **Done 2026-10-28:** M210 edr_config checked sample by sample against V3.4; `tools/check_edr_config_common.py` now compares M210 with V3.4. |
| T4 | `Builds\SWBuild` artefacts in the M210 tree are a 3-record build. | A bench flashed from there would not be the M210 release. | Before testing, read `$22 04 5D`: an M210 release (2 records) must not return a record 3. |
| T5 | 14 two-bit fields sat one bit low: Seat Belt Status (6, bytes 31/32), ODS (6, bytes 854/855), Seat Position Zone (2, byte 858). The builder read V2.7's low-bit position as the high bit; the ECU shifts by 6 / 4 / 2 (RstEdr_Lcfg.c:5152-5234, 16353-16372), as V3.4 states. | Every belt / ODS check read the wrong bits. | **Fixed 2026-10-28:** one bit up (e.g. driver belt 31.6-31.7). |
| T6 | Spec byte 855 (framework 859) in every config: DOMS Seat Belt Identification 859.0-859.1 overlaps SRS_OPERATION_MODE 859.0, SRS_OCS_SUBSEAT_CLASSIFICATION 859.3-859.4 overlaps 1st crash Type 859.3. The sheet (V3.4 and ICE V1.4) gives these 2-bit fields by their low bit; the only overlap-free reading is DOMS 1-2, subseat 4-5. The ECU writes only bit 0 here (RstEdr_Lcfg.c:16540). | DOMS / subseat checks read a neighbour's bit. | **Fixed 2026-10-28** in U171, Z121, M310_M314_M110 and M210: DOMS 859.1-859.2, subseat 859.4-859.7 (4 bits, as EDR_COMMON_PARAMETERS.md); builder SHEET_CORRECTIONS carry the same. W616 not changed. |
| T7 | IMU (YAW_RATE, X/Y_AXIS_ANGULAR, LATERAL/LONG_ACCEL): framework two's complement, offset 0, as the ECU writes (RstEdr_Lcfg.c:8427, 9029); V3.4 gives offset -300 / -8 (unsigned), while Z_AXIS_ACCEL keeps offset 0. | One of ECU and V3.4 is wrong. | Open: customer to confirm. `check_edr_config_common.py` reports these 5 entries until then. |

## Limits of this review
- Not in the tree, therefore not reviewed: CanMgr (on-fail substitution of every CAN-C signal), DiagMgr / Dcm (DID
  assembly, buffer initialisation, any post-processing), NvM / EcuM / BswM (write-all on reset), SysModMgr (when
  RstEdr_PowerDown is called), the APPRISE algorithm libraries (.a files).
- Vehicle calibration values assumed equal to the PBCfg defaults (calibration sheet has no values).
- No test was run; no item is bench-confirmed. Run order recommended by impact and cost:
  [M210-EDR-01](bugs/M210-EDR-01_multi_event_near_deploy_near_event3_lost.md), [M210-EDR-02](bugs/M210-EDR-02_adas_4hz_precrash_series_zeroed_after_previous_event.md), [M210-EDR-24](bugs/M210-EDR-24_deployment_time_reported_in_half_ms_ticks.md), [M210-EDR-13](bugs/M210-EDR-13_first_post_t0_sample_discarded_can_series.md), [M210-EDR-15](bugs/M210-EDR-15_sts_crash_pib_samples_after_5s_always_zero.md), [M210-EDR-23](bugs/M210-EDR-23_onfail_values_depend_on_canmgr_rstedr_ignores_qf.md), [M210-EDR-35](bugs/M210-EDR-35_sts_crash_pulse_missing_from_edr_series.md), [M210-EDR-36](bugs/M210-EDR-36_near_crash_signal_set_for_every_event.md), [M210-EDR-37](bugs/M210-EDR-37_sts_crash_gating_differs_from_edr_crash_type.md), [M210-EDR-16](bugs/M210-EDR-16_t0_sample_overwritten_when_record_written_before_first_tick.md), [M210-EDR-34](bugs/M210-EDR-34_200ms_completion_bit_set_before_200ms.md), [M210-EDR-03](bugs/M210-EDR-03_repeat_deployment_same_loops_not_locked.md), [M210-EDR-05](bugs/M210-EDR-05_crash_during_edr_readout_not_recorded.md), [M210-EDR-08](bugs/M210-EDR-08_synthesis_saved_only_on_orderly_power_down.md), [M210-EDR-40](bugs/M210-EDR-40_apprise_edr_activation_bit_latched.md),
  then the rest.
